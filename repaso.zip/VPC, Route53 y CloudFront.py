"""#1. Introducción a las Redes On-Premises y Corporativas Básicas
#Simula la topología de una red y la comunicación entre dispositivos utilizando Python y librerías
#como networkx para modelar y visualizar las redes


import networkx as nx
import matplotlib.pyplot as plt

# Crear un grafo vacío
G = nx.Graph()

# Añadir nodos (dispositivos)
nodes = ["Router", "Switch 1", "Switch 2", "PC 1", "PC 2", "PC 3", "PC 4"]
G.add_nodes_from(nodes)

# Añadir enlaces (conexiones)
edges = [("Router", "Switch 1"), ("Router", "Switch 2"),
         ("Switch 1", "PC 1"), ("Switch 1", "PC 2"),
         ("Switch 2", "PC 3"), ("Switch 2", "PC 4")]
G.add_edges_from(edges)

# Dibujar el grafo
pos = nx.spring_layout(G)  # Calcular la disposición de los nodos
nx.draw(G, pos, with_labels=True, node_size=3000, node_color='skyblue', font_size=10, font_color='black', font_weight='bold', edge_color='black', linewidths=1, alpha=0.7, style='dotted')

# Mostrar el gráfico
plt.title('Topología de Red On-Premises')
plt.show()


#2. Direccionamiento IP y CIDR
#Podemos escribir un script en Python que calcule y muestre rangos de direcciones IP basados en CIDR.

from ipaddress import ip_network

# Rango CIDR
cidr = '192.168.1.0/24'

# Crear una red basada en el CIDR
network = ip_network(cidr)

# Mostrar todas las direcciones IP en la red
print(f"Rango de direcciones IP para {cidr}:")
for ip in network.hosts():
    print(ip)


#3. Redes privadas virtuales (VPCs) y subredes
#Podemos simular la creación de VPCs y subredes usando clases en Python para representar estos elementos

class VPC:
    def __init__(self, cidr):
        self.cidr = cidr
        self.subnets = []

    def add_subnet(self, cidr):
        subnet = Subnet(cidr)
        self.subnets.append(subnet)

class Subnet:
    def __init__(self, cidr):
        self.cidr = cidr

# Crear una VPC
vpc = VPC('10.0.0.0/16')

# Añadir subredes
vpc.add_subnet('10.0.1.0/24')
vpc.add_subnet('10.0.2.0/24')

# Mostrar la configuración de la VPC
print(f"VPC CIDR: {vpc.cidr}")
for subnet in vpc.subnets:
    print(f"Subred CIDR: {subnet.cidr}")

# Simulación de un DNS con registros A y CNAME
dns_records = {
    'example.com': '192.168.1.10',
    'www.example.com': 'example.com',
}


def resolve_dns(name):
    if name in dns_records:
        value = dns_records[name]

        # Resolver CNAME
        if value in dns_records:
            value = dns_records[value]

        return value

    return None


# Probar la resolución de DNS
print(f"IP de example.com: {resolve_dns('example.com')}")
print(f"IP de www.example.com: {resolve_dns('www.example.com')}")





#4. DNS y enrutamiento global con simulación básica de Route53
#Podemos simular la resolución de nombres y el enrutamiento básico utilizando diccionarios en Python.

# Simulación de un DNS con registros A y CNAME
dns_records = {
    'example.com': '192.168.1.10',
    'www.example.com': 'example.com',
}


def resolve_dns(name):
    if name in dns_records:
        value = dns_records[name]

        # Resolver CNAME
        if value in dns_records:
            value = dns_records[value]

        return value

    return None


# Probar la resolución de DNS
print(f"IP de example.com: {resolve_dns('example.com')}")
print(f"IP de www.example.com: {resolve_dns('www.example.com')}")







#5. Implementación de una CDN básica con Python
#Podemos simular una CDN que almacena en caché el contenido y responde a las solicitudes.

import time

class CDN:
    def __init__(self):
        self.cache = {}

    def get_content(self, url):
        if url in self.cache:
            print("Contenido servido desde la caché")
            return self.cache[url]
        else:
            content = self.fetch_from_origin(url)
            self.cache[url] = content
            return content

    def fetch_from_origin(self, url):
        print("Obteniendo contenido desde el servidor de origen...")
        time.sleep(2)  # Simular tiempo de respuesta del servidor de origen
        return f"Contenido de {url}"

# Crear una instancia de CDN
cdn = CDN()

# Solicitar contenido
print(cdn.get_content("https://example.com/image.png"))
print(cdn.get_content("https://example.com/image.png"))






'''Ejercicio 6: Simulación Completa de una Red Corporativa
Objetivo: Diseñar y simular una red corporativa completa utilizando Python. La red debe incluir
routers, switches, y dispositivos finales con direccionamiento IP. Se debe implementar el
enrutamiento estático y dinámico entre subredes, y mostrar la topología de la red. Instrucciones:
Diseñar la red:
• Crea clases para representar routers, switches y dispositivos finales (PCs, servidores, etc.).
• Establece conexiones entre estos dispositivos para formar la red.
Direccionamiento IP:
• Asigna direcciones IP a cada dispositivo según las subredes.
• Implementa una función para calcular y asignar subredes utilizando CIDR.
Enrutamiento:
• Implementa enrutamiento estático entre subredes.
• Simula el protocolo de enrutamiento OSPF para enrutamiento dinámico.
Visualización:
• Muestra la topología de la red utilizando networkx y matplotlib.
Simulación de tráfico:
• Implementar funciones para enviar paquetes de datos entre dispositivos y mostrar el camino que sigue el paquete a través de la red.
Código base:'''

import networkx as nx
import matplotlib.pyplot as plt
from ipaddress import ip_network, ip_address


class Device:
    def __init__(self, name, device_type):
        self.name = name
        self.device_type = device_type
        self.ip_address = None


class Router(Device):
    def __init__(self, name):
        super().__init__(name, 'Router')
        self.routing_table = {}

    def add_route(self, network, next_hop):
        self.routing_table[network] = next_hop

    def get_route(self, ip):
        for network, next_hop in self.routing_table.items():
            if ip in ip_network(network):
                return next_hop
        return None


class Switch(Device):
    def __init__(self, name):
        super().__init__(name, 'Switch')


class PC(Device):
    def __init__(self, name):
        super().__init__(name, 'PC')


class Network:
    def __init__(self):
        self.devices = []
        self.edges = []

    def add_device(self, device):
        self.devices.append(device)

    def connect(self, device1, device2):
        self.edges.append((device1, device2))

    def assign_ip_addresses(self, cidr):
        network = ip_network(cidr)
        hosts = network.hosts()
        for device in self.devices:
                device.ip_address = str(next(hosts))

    # Añadir rutas estáticas
    def add_static_routes(self):
        for device in self.devices:
            if isinstance(device, Router):
                for edge in self.edges:
                    if device == edge[0]:
                        if isinstance(edge[1], Switch) or isinstance(edge[1], PC):
                            if edge[1].ip_address is not None:
                                subnet_cidr = self._get_subnet_cidr(edge[1].ip_address)
                                device.add_route(subnet_cidr, edge[1].name)
                            else:
                                print(f"Error: No se asignó una dirección IP a {edge[1].name}")

    def _get_subnet_cidr(self, ip):
        ip_obj = ip_address(ip)
        network_addr = ip_network(ip_obj)
        return str(network_addr)

    def visualize(self):
        G = nx.Graph()
        for device in self.devices:
            G.add_node(device.name)
        for edge in self.edges:
            G.add_edge(edge[0].name, edge[1].name)
        nx.draw(G, with_labels=True, node_size=3000, node_color='skyblue', font_size=10, font_color='black')
        plt.title('Topología de la Red Corporativa')
        plt.show()

    def simulate_traffic(self, src, dst):
        path = nx.shortest_path(self._build_graph(), source=src.name, target=dst.name)
        print(f"Ruta desde {src.name} a {dst.name}: {' -> '.join(path)}")

    def _build_graph(self):
        G = nx.Graph()
        for device in self.devices:
            G.add_node(device.name)
        for edge in self.edges:
            G.add_edge(edge[0].name, edge[1].name)
        return G


# Crear la red y dispositivos
network = Network()

# Crear dispositivos
router1 = Router("Router1")
router2 = Router("Router2")
switch1 = Switch("Switch1")
switch2 = Switch("Switch2")
pc1 = PC("PC1")
pc2 = PC("PC2")
pc3 = PC("PC3")
pc4 = PC("PC4")

# Añadir dispositivos a la red
network.add_device(router1)
network.add_device(router2)
network.add_device(switch1)
network.add_device(switch2)
network.add_device(pc1)
network.add_device(pc2)
network.add_device(pc3)
network.add_device(pc4)

# Conectar dispositivos
network.connect(router1, switch1)
network.connect(router1, switch2)
network.connect(switch1, pc1)
network.connect(switch1, pc2)
network.connect(switch2, pc3)
network.connect(switch2, pc4)
network.connect(router1, router2)

# Asignar direcciones IP
network.assign_ip_addresses('192.168.1.0/24')

# Añadir rutas estáticas
network.add_static_routes()

# Visualizar la red
network.visualize()

# Simular tráfico
network.simulate_traffic(pc1, pc3)








'''Ejercicio 7: Implementación de un Servicio de DNS Dinámico
Objetivo: Implementa un servicio de DNS dinámico en Python que pueda gestionar múltiples
registros, incluyendo registros A, CNAME y MX, y simular resoluciones de nombres de dominio.
Instrucciones:
Define la clase DNS:
• Crea una clase DNS para gestionar registros DNS.
• Implementa métodos para agregar, eliminar y actualizar registros.
Simular resolución DNS:
• Implementa un método para resolver nombres de dominio a direcciones IP.
• Soporta registros A, CNAME y MX.
Interfaz de usuario:
• Implementa una interfaz de línea de comandos (CLI) para interactuar con el servicio DNS.
• Permite a los usuarios agregar, eliminar, actualizar y resolver registros DNS.
Código base:'''


class DNS:
    def __init__(self):
        self.records = {
            'A': {},
            'CNAME': {},
            'MX': {}
        }

    def add_record(self, record_type, name, value):
        if record_type in self.records:
            self.records[record_type][name] = value
            print(f"Added {record_type} record: {name} -> {value}")
        else:
            print(f"Record type {record_type} not supported")

    def delete_record(self, record_type, name):
        if record_type in self.records and name in self.records[record_type]:
            del self.records[record_type][name]
            print(f"Deleted {record_type} record: {name}")
        else:
            print(f"Record {name} not found in {record_type} records")

    def update_record(self, record_type, name, value):
        if record_type in self.records and name in self.records[record_type]:
            self.records[record_type][name] = value
            print(f"Updated {record_type} record: {name} -> {value}")
        else:
            print(f"Record {name} not found in {record_type} records")

    def resolve(self, name):
        if name in self.records['A']:
            return self.records['A'][name]
        elif name in self.records['CNAME']:
            cname = self.records['CNAME'][name]
            return self.resolve(cname)
        elif name in self.records['MX']:
            return self.records['MX'][name]
        else:
            return None

    def __str__(self):
        return str(self.records)


# Simulación de la CLI
def main():
    dns = DNS()
    while True:
        command = input("Enter command (add, delete, update, resolve, exit): ")
        if command == 'add':
            record_type = input("Enter record type (A, CNAME, MX): ")
            name = input("Enter name: ")
            value = input("Enter value: ")
            dns.add_record(record_type, name, value)
        elif command == 'delete':
            record_type = input("Enter record type (A, CNAME, MX): ")
            name = input("Enter name: ")
            dns.delete_record(record_type, name)
        elif command == 'update':
            record_type = input("Enter record type (A, CNAME, MX): ")
            name = input("Enter name: ")
            value = input("Enter new value: ")
            dns.update_record(record_type, name, value)
        elif command == 'resolve':
            name = input("Enter name to resolve: ")
            ip = dns.resolve(name)
            if ip:
                print(f"IP for {name} is {ip}")
            else:
                print(f"{name} not found")
        elif command == 'exit':
            break
        else:
            print("Invalid command")


if __name__ == "__main__":
    main()







'''Ejercicio 8: Simulación de un CDN con control de caché avanzado
Objetivo: Implementar una CDN que almacene en caché contenido y soporte políticas de caché
avanzadas como expiración basada en tiempo y tamaño máximo de caché.
Instrucciones:
Define la clase CDN:
• Crea una clase CDN para gestionar el contenido en caché.
• Implementa métodos para agregar contenido a la caché, recuperar contenido, y manejar la expiración de caché.
Políticas de caché:
• Implementa una política de caché basada en tiempo para expirar contenido después de un tiempo determinado.
• Implementa una política de tamaño máximo de caché y manejar la eliminación de contenido cuando se exceda el tamaño.
Simular solicitudes de contenido:
• Implementa un método para simular solicitudes de contenido que respete las políticas de caché.
Código base:
'''

import time


class CDN:
    def __init__(self, max_cache_size, cache_expiration):
        self.cache = {}
        self.max_cache_size = max_cache_size
        self.cache_expiration = cache_expiration

    def get_content(self, url):
        if url in self.cache:
            content, timestamp = self.cache[url]
            if time.time() - timestamp < self.cache_expiration:
                print("Content served from cache")
                return content
            else:
                print("Cache expired, fetching new content")
                self.cache.pop(url)

        content = self.fetch_from_origin(url)
        self.add_to_cache(url, content)
        return content

    def fetch_from_origin(self, url):
        print(f"Fetching content from origin server for {url}...")
        time.sleep(2)  # Simular tiempo de respuesta del servidor de origen
        return f"Content of {url}"

    def add_to_cache(self, url, content):
        if len(self.cache) >= self.max_cache_size:
            self.evict_cache()
        self.cache[url] = (content, time.time()+1000)

    def evict_cache(self):
        # Evict the oldest cache entry
        oldest_url = min(self.cache, key=lambda k: self.cache[k][1])
        print(f"Evicting cache for {oldest_url}")
        self.cache.pop(oldest_url)

    def __str__(self):
        return str(self.cache)


# Simulación de la CDN
def main():
    cdn = CDN(max_cache_size=3, cache_expiration=10)

    while True:
        command = input("Enter command (get, exit): ")

        if command == 'get':
            url = input("Enter URL to fetch: ")
            content = cdn.get_content(url)
            print(content)
        elif command == 'exit':
            break
        else:
            print("Invalid command")


if __name__ == "__main__":
    main()


"""






'''Ejercicio 9: Implementación de una API RESTful con Python
Objetivo: Implementar una API RESTful que gestione recursos utilizando un framework web ligero
como Flask. La API debe soportar operaciones CRUD y almacenar datos en una estructura de datos en memoria.
Instrucciones:
Define la API:
• Utiliza Flask para definir endpoints para las operaciones CRUD.
• Implementa métodos para crear, leer, actualizar y eliminar recursos.
Estructura de datos:
• Utiliza una estructura de datos en memoria (como un diccionario) para almacenar los recursos.
Simular solicitudes:
• Implementar una interfaz de línea de comandos (CLI) para enviar solicitudes a la API y mostrar los resultados.
Código base:
'''

from flask import Flask, request, jsonify

app = Flask(__name__)

# Estructura de datos en memoria
resources = {}

# Endpoint para crear un recurso
@app.route('/resources', methods=['POST'])
def create_resource():
    resource_id = request.json['id']
    resource_data = request.json['data']
    resources[resource_id] = resource_data
    return jsonify({"message": "Resource created"}), 201

# Endpoint para obtener un recurso por su ID
@app.route('/resources/<resource_id>', methods=['GET'])
def get_resource(resource_id):
    resource_data = resources.get(resource_id)
    if resource_data:
        return jsonify({"id": resource_id, "data": resource_data})
    return jsonify({"message": "Resource not found"}), 404

# Endpoint para actualizar un recurso por su ID
@app.route('/resources/<resource_id>', methods=['PUT'])
def update_resource(resource_id):
    resource_data = request.json['data']
    if resource_id in resources:
        resources[resource_id] = resource_data
        return jsonify({"message": "Resource updated"})
    return jsonify({"message": "Resource not found"}), 404

# Endpoint para eliminar un recurso por su ID
@app.route('/resources/<resource_id>', methods=['DELETE'])
def delete_resource(resource_id):
    if resource_id in resources:
        del resources[resource_id]
        return jsonify({"message": "Resource deleted"})
    return jsonify({"message": "Resource not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)


'''#!/usr/bin/env python
import json_manager
import click


@click.group()
def cli():
    pass


@cli.command()
@click.option('--name', required=True, help="user's name")
@click.option('--lastname', required=True, help="user's lastname")
@click.pass_context
def new(ctx, name, lastname):
    """Crear un nuevo registro."""
    if not name or not lastname:
        ctx.fail('the name and lastname are required')
    else:
        data = json_manager.read_json()
        new_id = len(data) + 1
        nuevo_registro = {'id': new_id, 'name': name, 'lastname': lastname}
        data.append(nuevo_registro)
        json_manager.write_json(data)
        print(f"new user created with id {new_id}")


@cli.command()
def users():
    data = json_manager.read_json()
    for user in data:
        print(
            f"{user['id']} - {user['name']} - {user['lastname']}")


@cli.command()
@click.argument('id', type=int)
def user(id):
    data = json_manager.read_json()
    user = next((x for x in data if x['id'] == id), None)
    if user is None:
        print('user does not exist')
    else:
        print(f"{user['id']} - {user['name']} - {user['lastname']}")


@cli.command()
@click.argument('id', type=int)
@click.option('--name', default=None)
@click.option('--lastname', default=None)
def update(id, name, lastname):
    data = json_manager.read_json()
    for user in data:
        if user['id'] == id:
            if name is not None:
                user['name'] = name
            if lastname is not None:
                user['lastname'] = lastname
            break
    json_manager.write_json(data)


@cli.command()
@click.argument('id', type=int)
def delete(id):
    data = json_manager.read_json()
    user = next((x for x in data if x['id'] == id), None)
    if user is None:
        print('user not found')
    else:
        data.remove(user)
        json_manager.write_json(data)


if __name__ == '__main__':
    cli()'''














