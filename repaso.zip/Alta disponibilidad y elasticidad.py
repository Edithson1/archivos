'''"""Ejercicio 1: Simulación de escalabilidad vertical y horizontal
Objetivo: Entender las diferencias y aplicaciones de la escalabilidad vertical y horizontal.
Instrucciones:
• Implementa una clase Server que represente un servidor con atributos como cpu_capacity,
memory_capacity, y current_load.
• Implementa un método scale_up para simular la escalabilidad vertical, aumentando la
capacidad del servidor.
• Implementa una clase ServerCluster para simular la escalabilidad horizontal, con métodos
para añadir o quitar servidores del clúster.
• Diseña un sistema que distribuya la carga entre los servidores de un clúster, simulando la
escalabilidad horizontal."""

# Clase Server que representa un servidor
class Server:
    def __init__(self, cpu_capacity, memory_capacity):
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity
        self.current_load = 0

    # Método para escalar verticalmente el servidor
    def scale_up(self, additional_cpu, additional_memory):
        self.cpu_capacity += additional_cpu
        self.memory_capacity += additional_memory

    # Método para determinar si el servidor puede aceptar más carga
    def can_accept_load(self, load):
        return self.current_load + load <= self.cpu_capacity

# Clase ServerCluster para representar un clúster de servidores
class ServerCluster:
    def __init__(self):
        self.servers = []

    # Método para añadir un servidor al clúster
    def add_server(self, server):
        self.servers.append(server)

    # Método para quitar un servidor del clúster
    def remove_server(self):
        if self.servers:
            self.servers.pop()

    # Método para distribuir la carga entre los servidores del clúster
    def distribute_load(self, load):
        if not self.servers:
            print("No servers available.")
            return

        for server in self.servers:
            if server.can_accept_load(load):
                server.current_load += load
                return

        print("No server can handle the additional load.")
        self.scale_out(load)

    # Método para escalar horizontalmente el clúster añadiendo más servidores
    def scale_out(self, load):
        print("Scaling out: Adding a new server to handle the load.")
        new_server = Server(cpu_capacity=load, memory_capacity=load * 2)
        self.add_server(new_server)
        new_server.current_load = load

# Ejemplo de uso
server1 = Server(cpu_capacity=4, memory_capacity=8)
server2 = Server(cpu_capacity=4, memory_capacity=8)
cluster = ServerCluster()
cluster.add_server(server1)
cluster.add_server(server2)

# Distribuir carga de manera equilibrada
cluster.distribute_load(2)  # Load fits in server1
cluster.distribute_load(3)  # Load fits in server2
cluster.distribute_load(5)  # No single server can handle this load, scaling out

# Escalar verticalmente server1
server1.scale_up(additional_cpu=2, additional_memory=4)

# Intentar distribuir carga nuevamente
cluster.distribute_load(5)  # Now server1 can handle this load






"""
Ejercicio 2: Resumen del modelo OSI
Objetivo: Comprender el modelo OSI y su aplicación en redes.
Instrucciones:
• Implementa una clase OSIModel que represente las siete capas del modelo OSI.
• Define métodos en cada capa para simular la transferencia de datos a través de la red.
• Implementa una función que muestre cómo un paquete de datos se mueve a través de las siete capas del modelo OSI.
"""

# Clase OSIModel que representa las siete capas del modelo OSI
class OSIModel:
    def __init__(self, data):
        self.data = data

    # Capa de Aplicación
    def application_layer(self):
        print("Application Layer: Processing data", self.data)
        self.data = "application_processed(" + self.data + ")"
        self.presentation_layer()

    # Capa de Presentación
    def presentation_layer(self):
        print("Presentation Layer: Formatting data", self.data)
        self.data = "presentation_processed(" + self.data + ")"
        self.session_layer()

    # Capa de Sesión
    def session_layer(self):
        print("Session Layer: Managing session for data", self.data)
        self.data = "session_processed(" + self.data + ")"
        self.transport_layer()

    # Capa de Transporte
    def transport_layer(self):
        print("Transport Layer: Segmenting data", self.data)
        self.data = "transport_processed(" + self.data + ")"
        self.network_layer()

    # Capa de Red
    def network_layer(self):
        print("Network Layer: Routing data", self.data)
        self.data = "network_processed(" + self.data + ")"
        self.data_link_layer()

    # Capa de Enlace de Datos
    def data_link_layer(self):
        print("Data Link Layer: Framing data", self.data)
        self.data = "datalink_processed(" + self.data + ")"
        self.physical_layer()

    # Capa Física
    def physical_layer(self):
        print("Physical Layer: Transmitting data", self.data)
        self.data = "physical_processed(" + self.data + ")"
        print("Final data transmitted:", self.data)

# Función para simular la transferencia de datos a través de las capas del modelo OSI
def transfer_data_through_osi(data):
    osi_model = OSIModel(data)
    osi_model.application_layer()

# Ejemplo de uso
transfer_data_through_osi(data="Hello World")






"""Ejercicio 3: Simulación de balanceadores de carga
Objetivo: Simular la distribución de tráfico web utilizando balanceadores de carga.
Instrucciones:
• Implementa una clase LoadBalancer que distribuya las solicitudes entre varios servidores.
• Crea métodos para simular la configuración de un Application Load Balancer (ALB) y un Network Load Balancer (NLB).
Implementa una función que distribuya solicitudes HTTP y TCP entre los servidores configurados."""

# Clase LoadBalancer que distribuye solicitudes entre varios servidores
class LoadBalancer:
    def __init__(self):
        self.servers = []
        self.alb_servers = []
        self.nlb_servers = []

    # Método para añadir un servidor al balanceador de carga
    def add_server(self, server, lb_type='general'):
        if lb_type == 'alb':
            self.alb_servers.append(server)
        elif lb_type == 'nlb':
            self.nlb_servers.append(server)
        else:
            self.servers.append(server)

    # Método para distribuir solicitudes HTTP entre los servidores configurados para ALB
    def distribute_http_requests(self, requests):
        print("Distributing HTTP requests...")
        for i, request in enumerate(requests):
            server = self.alb_servers[i % len(self.alb_servers)]
            server.handle_request(request)

    # Método para distribuir solicitudes TCP entre los servidores configurados para NLB
    def distribute_tcp_requests(self, requests):
        print("Distributing TCP requests...")
        for i, request in enumerate(requests):
            server = self.nlb_servers[i % len(self.nlb_servers)]
            server.handle_request(request)

    # Método para configurar un Application Load Balancer (ALB)
    def configure_alb(self, servers):
        print("Configuring Application Load Balancer (ALB)...")
        self.alb_servers = servers

    # Método para configurar un Network Load Balancer (NLB)
    def configure_nlb(self, servers):
        print("Configuring Network Load Balancer (NLB)...")
        self.nlb_servers = servers

# Clase Server que representa un servidor
class Server:
    def __init__(self, name):
        self.name = name

    # Método para manejar una solicitud
    def handle_request(self, request):
        print(f"Server {self.name} handling request: {request}")

# Ejemplo de uso
server1 = Server("Server 1")
server2 = Server("Server 2")
server3 = Server("Server 3")
server4 = Server("Server 4")

load_balancer = LoadBalancer()
load_balancer.add_server(server1, lb_type='alb')
load_balancer.add_server(server2, lb_type='alb')
load_balancer.add_server(server3, lb_type='nlb')
load_balancer.add_server(server4, lb_type='nlb')

# Configurar ALB y NLB
load_balancer.configure_alb([server1, server2])
load_balancer.configure_nlb([server3, server4])

# Distribuir solicitudes HTTP y TCP
load_balancer.distribute_http_requests(["HTTP Request 1", "HTTP Request 2", "HTTP Request 3"])
load_balancer.distribute_tcp_requests(["TCP Request 1", "TCP Request 2"])







"""Ejercicio 4: Simulación de elasticidad con auto scaling groups
Objetivo: Implementar la elasticidad mediante la simulación de grupos de Auto Scaling.
Instrucciones:
• Implementa una clase AutoScalingGroup que gestione un grupo de servidores.
• Define métodos para simular la creación de plantillas de configuración y las políticas de escalado.
• Implementa funciones que ajusten dinámicamente el número de servidores en el grupo
basado en métricas simuladas como uso de CPU o tráfico de red."""

# Clase Server que representa un servidor
class Server:
    def __init__(self):
        self.cpu_usage = 0

    def simulate_load(self, load):
        self.cpu_usage = load

# Clase ServerTemplate que se utiliza para crear nuevos servidores
class ServerTemplate:
    def create_server(self):
        return Server()

# Clase AutoScalingGroup que gestiona un grupo de servidores
class AutoScalingGroup:
    def __init__(self, template, min_size, max_size):
        self.template = template
        self.min_size = min_size
        self.max_size = max_size
        self.servers = [self.template.create_server() for _ in range(min_size)]
        self.cpu_usage_threshold = 70

    # Método para escalar hacia afuera (añadir servidores)
    def scale_out(self):
        if len(self.servers) < self.max_size:
            self.servers.append(self.template.create_server())
            print("Scaled out: Added a server")

    # Método para escalar hacia adentro (eliminar servidores)
    def scale_in(self):
        if len(self.servers) > self.min_size:
            self.servers.pop()
            print("Scaled in: Removed a server")

    # Método para ajustar la capacidad del grupo basado en el uso de CPU
    def adjust_capacity(self, cpu_usages):
        average_cpu_usage = sum(cpu_usages) / len(cpu_usages)
        print(f"Average CPU usage: {average_cpu_usage}%")
        if average_cpu_usage > self.cpu_usage_threshold:
            self.scale_out()
        elif average_cpu_usage < self.cpu_usage_threshold and len(self.servers) > self.min_size:
            self.scale_in()

    # Método para simular la métrica de uso de CPU para todos los servidores
    def simulate_cpu_usage(self):
        cpu_usages = [server.cpu_usage for server in self.servers]
        self.adjust_capacity(cpu_usages)

# Ejemplo de uso
template = ServerTemplate()
asg = AutoScalingGroup(template=template, min_size=2, max_size=5)

# Simular cargas de CPU y ajustar la capacidad
asg.servers[0].simulate_load(50)
asg.servers[1].simulate_load(60)
asg.simulate_cpu_usage()  # No debería escalar, el uso promedio es 55%

asg.servers[0].simulate_load(80)
asg.servers[1].simulate_load(75)
asg.simulate_cpu_usage()  # Debería escalar hacia afuera, el uso promedio es 77.5%

asg.servers[0].simulate_load(30)
asg.servers[1].simulate_load(35)
asg.simulate_cpu_usage()  # Debería escalar hacia adentro, el uso promedio es 32.5%







"""Ejercicio 5: Diseño de soluciones de alta disponibilidad Multi-Región
Objetivo: Diseñar una arquitectura de alta disponibilidad multi-región.
Instrucciones:
• Implementa una clase Region que simule una región con sus propios servidores y balanceadores de carga.
• Define métodos para replicar datos entre regiones y gestionar el tráfico utilizando DNS.
• Implementa una función que simule el enrutamiento de solicitudes entre múltiples regiones,
incluyendo la conmutación por error en caso de falla en una región."""

# Clase Server que representa un servidor
class Server:
    def __init__(self, name):
        self.name = name
        self.data = None

    def handle_request(self, request):
        print(f"Server {self.name} handling request: {request}")

# Clase LoadBalancer que distribuye solicitudes entre varios servidores
class LoadBalancer:
    def __init__(self):
        self.servers = []

    def add_server(self, server):
        self.servers.append(server)

    def distribute_http_requests(self, requests):
        if not self.servers:
            print("No servers available to handle the requests.")
            return
        for i, request in enumerate(requests):
            server = self.servers[i % len(self.servers)]
            server.handle_request(request)

# Clase Region que simula una región con sus propios servidores y balanceadores de carga
class Region:
    def __init__(self, name):
        self.name = name
        self.servers = []
        self.load_balancer = LoadBalancer()

    def add_server(self, server):
        self.servers.append(server)
        self.load_balancer.add_server(server)

    def handle_request(self, request):
        self.load_balancer.distribute_http_requests([request])

    def replicate_data(self, data, target_region):
        print(f"Replicating data '{data}' from {self.name} to {target_region.name}")
        for server in target_region.servers:
            server.data = data

# Clase MultiRegionHA que gestiona la alta disponibilidad entre múltiples regiones
class MultiRegionHA:
    def __init__(self):
        self.regions = []

    def add_region(self, region):
        self.regions.append(region)

    def route_request(self, request):
        for region in self.regions:
            try:
                region.handle_request(request)
                return
            except Exception as e:
                print(f"Region {region.name} failed: {e}")
        print("All regions failed to handle the request")

    def failover(self):
        if len(self.regions) > 1:
            print("Failover: Switching to secondary region")
            failed_region = self.regions.pop(0)
            self.regions.append(failed_region)

    def simulate_failover(self, region_name):
        print(f"Simulating failure in region: {region_name}")
        self.regions = [region for region in self.regions if region.name != region_name]
        print(f"Available regions after failover: {[region.name for region in self.regions]}")

# Ejemplo de uso
region1 = Region("us-east-1")
region2 = Region("us-west-1")
region3 = Region("eu-central-1")

server1 = Server("Server 1")
server2 = Server("Server 2")
server3 = Server("Server 3")
server4 = Server("Server 4")
server5 = Server("Server 5")

region1.add_server(server1)
region1.add_server(server2)
region2.add_server(server3)
region2.add_server(server4)
region3.add_server(server5)

# Replicar datos entre regiones
region1.replicate_data("User data", region2)
region2.replicate_data("User data", region3)

ha_system = MultiRegionHA()
ha_system.add_region(region1)
ha_system.add_region(region2)
ha_system.add_region(region3)

# Simular enrutamiento de solicitudes
print("Routing request to the best available region...")
ha_system.route_request("Request 1")

# Simular fallo en una región y conmutación por error
print("\nSimulating failover scenario...")
ha_system.simulate_failover("us-east-1")
ha_system.route_request("Request 2")

# Verificar la replicación de datos después del failover
print(f"Server in us-west-1 has data: {region2.servers[0].data}")
print(f"Server in eu-central-1 has data: {region3.servers[0].data}")






"""Ejercicio 6: Simulación de un sistema de firewall para aplicaciones Web (WAF)
Objetivo: Implementar un sistema de firewall para aplicaciones web.
Instrucciones:
• Implementa una clase WebApplicationFirewall que permita definir y aplicar reglas de protección.
• Define reglas para bloquear solicitudes basadas en IP, prevenir ataques de SQL injection y XSS.
• Implementa una función que aplique el WAF a un conjunto de servidores detrás de un
balanceador de carga."""

# Clase WebApplicationFirewall que permite definir y aplicar reglas de protección
class WebApplicationFirewall:
    def __init__(self):
        self.rules = []

    def add_rule(self, rule):
        self.rules.append(rule)

    def apply_rules(self, request):
        for rule in self.rules:
            if not rule(request):
                print(f"Request blocked by rule: {rule.__name__}")
                return False
        return True

# Funciones de reglas de firewall

def block_ip_rule(ip):
    blocked_ips = ["192.168.0.1"]
    return ip not in blocked_ips

def sql_injection_rule(query):
    sql_keywords = ["select", "drop", "insert", "delete"]
    return all(keyword not in query.lower() for keyword in sql_keywords)

def xss_rule(content):
    return "<script>" not in content.lower()

# Clase Server que representa un servidor
class Server:
    def __init__(self, name):
        self.name = name

    def handle_request(self, request):
        print(f"Server {self.name} handling request: {request}")

# Clase LoadBalancer que distribuye solicitudes entre varios servidores
class LoadBalancer:
    def __init__(self):
        self.servers = []

    def add_server(self, server):
        self.servers.append(server)

    def distribute_http_requests(self, requests, waf):
        if not self.servers:
            print("No servers available to handle the requests.")
            return
        for i, request in enumerate(requests):
            if waf.apply_rules(request):
                server = self.servers[i % len(self.servers)]
                server.handle_request(request)
            else:
                print(f"Request blocked: {request}")

# Ejemplo de uso
server1 = Server("Server 1")
server2 = Server("Server 2")

load_balancer = LoadBalancer()
load_balancer.add_server(server1)
load_balancer.add_server(server2)

# Configuración del WAF con reglas
waf = WebApplicationFirewall()
waf.add_rule(lambda req: block_ip_rule(req["ip"]))
waf.add_rule(lambda req: sql_injection_rule(req["query"]))
waf.add_rule(lambda req: xss_rule(req["content"]))

# Solicitudes de ejemplo
requests = [
    {"ip": "192.168.0.2", "query": "SELECT * FROM users", "content": "Hello World"},
    {"ip": "192.168.0.1", "query": "DROP TABLE users", "content": "<script>alert('XSS')</script>"},
    {"ip": "192.168.0.3", "query": "INSERT INTO users (name) VALUES ('John')", "content": "Normal content"},
    {"ip": "192.168.0.4", "query": "UPDATE users SET name='Jane'", "content": "<SCRIPT>XSS</SCRIPT>"},
]

# Distribuir solicitudes a través del balanceador de carga con WAF
load_balancer.distribute_http_requests(requests, waf)









"""Ejercicio 7: Simulación de Auto Scaling con políticas de escalado personalizadas
Objetivo: Configurar un sistema de Auto Scaling con políticas de escalado personalizadas.
Instrucciones:
• Implementa una clase CustomAutoScalingGroup que gestione un grupo de servidores.
• Define métodos para simular la creación de plantillas de configuración y las políticas de
escalado basadas en métricas personalizadas.
• Implementa funciones que ajusten dinámicamente el número de servidores en el grupo
basado en métricas simuladas como uso de memoria, tasa de solicitudes por segundo, etc."""


# Clase CustomAutoScalingGroup que gestiona un grupo de servidores con políticas de escalado personalizadas
class CustomAutoScalingGroup:
    def __init__(self, template, min_size, max_size, scaling_policy):
        self.template = template
        self.min_size = min_size
        self.max_size = max_size
        self.scaling_policy = scaling_policy
        self.servers = [self.template.create_server() for _ in range(min_size)]

    def scale_out(self):
        if len(self.servers) < self.max_size:
            self.servers.append(self.template.create_server())
            print("Scaled out: Added a server")

    def scale_in(self):
        if len(self.servers) > self.min_size:
            self.servers.pop()
            print("Scaled in: Removed a server")

    def adjust_capacity(self, metric_values):
        if self.scaling_policy(metric_values):
            self.scale_out()
        else:
            self.scale_in()

# Clase ServerTemplate para crear servidores
class ServerTemplate:
    def create_server(self):
        return Server()

# Clase Server que representa un servidor
class Server:
    pass

# Función de política de escalado personalizada
def custom_scaling_policy(metric_values):
    # Ejemplo de política de escalado personalizada: Escalar hacia fuera si el promedio de métricas supera 70
    return sum(metric_values) / len(metric_values) > 70

# Ejemplo de uso
template = ServerTemplate()
asg = CustomAutoScalingGroup(template=template, min_size=2, max_size=5, scaling_policy=custom_scaling_policy)
asg.adjust_capacity([50, 60, 80])






"""Ejercicio 8: Simulación de un sistema de escalabilidad vertical y horizontal completo
Objetivo: Desarrollar un sistema completo que soporte tanto la escalabilidad vertical como
horizontal, simulando un entorno de servidor con balanceo de carga y ajuste automático de capacidad.
Instrucciones:
• Diseña una clase Server que represente un servidor con atributos como cpu_capacity,
memory_capacity, y current_load.
Implementa métodos en la clase Server para simular la escalabilidad vertical (scale_up) y
para manejar solicitudes (handle_request).
• Crea una clase ServerCluster que administre un grupo de servidores, implementando
métodos para añadir y remover servidores, y para distribuir la carga entre ellos.
• Implementa un balanceador de carga dentro de la clase ServerCluster que distribuya las
solicitudes de manera eficiente entre los servidores disponibles.
• Diseña una clase AutoScaler que ajuste automáticamente la capacidad del clúster,
añadiendo o removiendo servidores según métricas de uso como la CPU y la memoria.
• Implementa un script que simule la llegada de solicitudes y el ajuste dinámico de la
capacidad del clúster, generando una carga de trabajo variable y observando cómo el
sistema escala vertical y horizontalmente"""

import time
import random

# Clase Server que representa un servidor con capacidad y carga actual
class Server:
    def __init__(self, name, cpu_capacity, memory_capacity):
        """
        Inicializa un servidor con capacidades de CPU y memoria.
        """
        self.name = name
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity
        self.current_load = 0

    def scale_up(self, additional_cpu, additional_memory):
        """
        Simula la escalabilidad vertical aumentando la capacidad del servidor.
        """
        self.cpu_capacity += additional_cpu
        self.memory_capacity += additional_memory
        print(f"Server {self.name} scaled up: CPU={self.cpu_capacity}, Memory={self.memory_capacity}")

    def handle_request(self, request):
        """
        Simula el manejo de solicitudes por parte del servidor.
        """
        print(f"Server {self.name} handling request: {request}")
        # Simulación de carga: Incrementa la carga del servidor
        self.current_load += 1

# Clase ServerCluster que administra un grupo de servidores con balanceo de carga
class ServerCluster:
    def __init__(self):
        """
        Inicializa un clúster de servidores y un balanceador de carga.
        """
        self.servers = []
        self.load_balancer = LoadBalancer()

    def add_server(self, server):
        """
        Añade un servidor al clúster y al balanceador de carga.
        """
        self.servers.append(server)
        self.load_balancer.add_server(server)

    def remove_server(self):
        """
        Remueve un servidor del clúster y del balanceador de carga.
        """
        if self.servers:
            server = self.servers.pop()
            print(f"Server {server.name} removed from cluster")
            self.load_balancer.remove_server()

    def distribute_load(self, request):
        """
        Distribuye la carga de trabajo entre los servidores del clúster utilizando el balanceador de carga.
        """
        self.load_balancer.distribute_request(request)

# Clase LoadBalancer para distribuir solicitudes entre servidores
class LoadBalancer:
    def __init__(self):
        """
        Inicializa un balanceador de carga vacío.
        """
        self.servers = []

    def add_server(self, server):
        """
        Añade un servidor al balanceador de carga.
        """
        self.servers.append(server)

    def remove_server(self):
        """
        Remueve un servidor del balanceador de carga.
        """
        if self.servers:
            self.servers.pop()

    def distribute_request(self, request):
        """
        Distribuye una solicitud al servidor con la carga mínima actual.
        """
        if not self.servers:
            print("No servers available to handle the request.")
            return

        # Simulación simple: Distribuye la solicitud al servidor con la carga mínima actual
        min_load_server = min(self.servers, key=lambda server: server.current_load)
        min_load_server.handle_request(request)

# Clase AutoScaler que ajusta automáticamente la capacidad del clúster
class AutoScaler:
    def __init__(self, cluster, cpu_threshold, memory_threshold):
        """
        Inicializa un AutoScaler con umbrales de CPU y memoria para monitorear y ajustar la capacidad del clúster.
        """
        self.cluster = cluster
        self.cpu_threshold = cpu_threshold
        self.memory_threshold = memory_threshold

    def monitor_and_adjust(self):
        """
        Monitorea continuamente la carga del clúster y ajusta dinámicamente el número de servidores según umbrales de CPU y memoria.
        """
        while True:
            time.sleep(5)  # Simula un intervalo de monitoreo
            cpu_usages = [server.cpu_capacity - server.current_load for server in self.cluster.servers]
            average_cpu_usage = sum(cpu_usages) / len(cpu_usages)
            if average_cpu_usage > self.cpu_threshold:
                self.cluster.add_server(Server(name=f"Server-{len(self.cluster.servers) + 1}", cpu_capacity=4, memory_capacity=8))
            elif average_cpu_usage < self.cpu_threshold - 10 and len(self.cluster.servers) > 1:
                self.cluster.remove_server()

# Función principal para simular la carga de trabajo y ajuste del clúster
def simulate_load_and_scaling(cluster, autoscaler):
    """
    Simula la llegada de solicitudes y el ajuste dinámico de la capacidad del clúster.
    """
    requests = ["Request 1", "Request 2", "Request 3", "Request 4", "Request 5"]
    while True:
        request = random.choice(requests)
        print(f"Incoming request: {request}")
        cluster.distribute_load(request)
        time.sleep(random.uniform(0.5, 1.5))
        autoscaler.monitor_and_adjust()

# Configuración inicial del clúster y el autoscaler
cluster = ServerCluster()
server1 = Server(name="Server-1", cpu_capacity=4, memory_capacity=8)
cluster.add_server(server1)

autoscaler = AutoScaler(cluster, cpu_threshold=7, memory_threshold=12)

# Iniciar la simulación de carga y ajuste del clúster
simulate_load_and_scaling(cluster, autoscaler)







"""Ejercicio 9: Implementación completa del modelo OSI con simulación de tráfico de red
Objetivo: Crear una simulación detallada del modelo OSI que incluya todas las capas y permita el
seguimiento de un paquete de datos a través de cada capa.
Instrucciones:
• Diseña una clase OSIModel que contenga métodos para cada una de las siete capas del
modelo OSI (Aplicación, Presentación, Sesión, Transporte, Red, Enlace de Datos y Física).
• Implementa métodos específicos en cada capa para procesar y transformar datos, simulando
tareas reales realizadas en esas capas (por ejemplo, segmentación en la capa de Transporte,
enrutamiento en la capa de Red, etc.).
• Crea una estructura de datos que represente un paquete de red y que pueda ser modificado
por cada capa del modelo OSI.
• Diseña un sistema de registro que documente el estado del paquete en cada etapa del
procesamiento, permitiendo rastrear cómo cambia el paquete a medida que pasa por las
diferentes capas.
• Implementa un script que genere paquetes de datos y los procese a través del modelo OSI,
simulando la transmisión de datos entre un cliente y un servidor, e imprimiendo los detalles
del procesamiento en cada capa"""

class OSIModel:
    def __init__(self, data):
        """
        Inicializa el modelo OSI con los datos iniciales del paquete.
        """
        self.data = data
        self.log = []

    def application_layer(self):
        """
        Capa de Aplicación: Procesa los datos en la capa de aplicación.
        """
        self.log.append("Application Layer: Processing data")
        self.data = f"application_processed({self.data})"
        self.presentation_layer()

    def presentation_layer(self):
        """
        Capa de Presentación: Formatea los datos en la capa de presentación.
        """
        self.log.append("Presentation Layer: Formatting data")
        self.data = f"presentation_processed({self.data})"
        self.session_layer()

    def session_layer(self):
        """
        Capa de Sesión: Maneja la sesión para los datos en la capa de sesión.
        """
        self.log.append("Session Layer: Managing session for data")
        self.data = f"session_processed({self.data})"
        self.transport_layer()

    def transport_layer(self):
        """
        Capa de Transporte: Segmenta los datos en la capa de transporte.
        """
        self.log.append("Transport Layer: Segmenting data")
        self.data = f"segmented({self.data})"
        self.network_layer()

    def network_layer(self):
        """
        Capa de Red: Rutea los datos en la capa de red.
        """
        self.log.append("Network Layer: Routing data")
        self.data = f"routed({self.data})"
        self.data_link_layer()

    def data_link_layer(self):
        """
        Capa de Enlace de Datos: Enmarca los datos en la capa de enlace de datos.
        """
        self.log.append("Data Link Layer: Framing data")
        self.data = f"framed({self.data})"
        self.physical_layer()

    def physical_layer(self):
        """
        Capa Física: Transmite los datos en la capa física.
        """
        self.log.append("Physical Layer: Transmitting data")
        self.data = f"transmitted({self.data})"
        self.log.append(f"Final data transmitted: {self.data}")

# Función principal para simular la transmisión de datos a través del modelo OSI
def simulate_osi_transmission(data):
    """
    Simula la transmisión de datos a través del modelo OSI e imprime el registro de procesamiento.
    """
    osi_model = OSIModel(data)
    osi_model.application_layer()

    # Imprimir el registro de procesamiento
    print("Registro de procesamiento del modelo OSI:")
    for step, log_entry in enumerate(osi_model.log, start=1):
        print(f"Paso {step}: {log_entry}")

# Ejemplo de uso
data_packet = "Hello World"
simulate_osi_transmission(data_packet)









"""Ejercicio 10: Simulación de balanceadores de carga con políticas de distribución avanzadas
Objetivo: Implementar un sistema de balanceo de carga avanzado que soporte múltiples tipos de
balanceadores (ALB, NLB, CLB) y políticas de distribución personalizadas.
Instrucciones:
• Diseña una clase base LoadBalancer con métodos genéricos para añadir y remover
servidores, y para distribuir solicitudes.
• Implementa clases derivadas ApplicationLoadBalancer, NetworkLoadBalancer, y
ClassicLoadBalancer que extiendan la clase base y añadan funcionalidades específicas.
• Crea diferentes políticas de distribución de carga (round-robin, least-connections, IP-hash) y
permite que cada tipo de balanceador pueda configurarse con cualquiera de estas políticas.
• Implementa un sistema de monitoreo que registre métricas de rendimiento y estadísticas de
distribución de carga para cada balanceador.
• Diseña un script que configure un entorno con múltiples balanceadores y servidores, genere
tráfico de red simulado, y ajuste dinámicamente las políticas de distribución para optimizar el rendimiento"""

from abc import ABC, abstractmethod
import random

# Clase base para el balanceador de carga
class LoadBalancer(ABC):
    def __init__(self):
        self.servers = []

    def add_server(self, server):
        self.servers.append(server)

    def remove_server(self, server):
        if server in self.servers:
            self.servers.remove(server)

    @abstractmethod
    def distribute_request(self, request):
        pass

# Clase para el Application Load Balancer (ALB)
class ApplicationLoadBalancer(LoadBalancer):
    def __init__(self, distribution_policy):
        super().__init__()
        self.distribution_policy = distribution_policy

    def distribute_request(self, request):
        server = self.distribution_policy.select_server(self.servers)
        server.handle_request(request)

# Clase para el Network Load Balancer (NLB)
class NetworkLoadBalancer(LoadBalancer):
    def __init__(self, distribution_policy):
        super().__init__()
        self.distribution_policy = distribution_policy

    def distribute_request(self, request):
        server = self.distribution_policy.select_server(self.servers)
        server.handle_request(request)

# Clase para el Classic Load Balancer (CLB)
class ClassicLoadBalancer(LoadBalancer):
    def __init__(self, distribution_policy):
        super().__init__()
        self.distribution_policy = distribution_policy

    def distribute_request(self, request):
        server = self.distribution_policy.select_server(self.servers)
        server.handle_request(request)

# Política de distribución: Round Robin
class RoundRobinPolicy:
    def __init__(self):
        self.index = 0

    def select_server(self, servers):
        if not servers:
            raise Exception("No servers available.")
        server = servers[self.index % len(servers)]
        self.index += 1
        return server

# Política de distribución: Least Connections
class LeastConnectionsPolicy:
    def select_server(self, servers):
        if not servers:
            raise Exception("No servers available.")
        return min(servers, key=lambda server: server.current_connections)

# Política de distribución: IP Hashing
class IPHashPolicy:
    def select_server(self, servers, ip_address):
        if not servers:
            raise Exception("No servers available.")
        hashed_index = hash(ip_address) % len(servers)
        return servers[hashed_index]

# Clase Server para representar los servidores
class Server:
    def __init__(self, name):
        self.name = name
        self.current_connections = 0

    def handle_request(self, request):
        self.current_connections += 1
        print(f"Server {self.name} handling request: {request}")
        self.current_connections -= 1

# Función para simular tráfico de red
def simulate_traffic(load_balancer, requests):
    for request in requests:
        load_balancer.distribute_request(request)

# Ejemplo de uso
server1 = Server("Server 1")
server2 = Server("Server 2")
server3 = Server("Server 3")

# Configuración de balanceadores de carga
alb = ApplicationLoadBalancer(RoundRobinPolicy())
nlb = NetworkLoadBalancer(LeastConnectionsPolicy())
clb = ClassicLoadBalancer(IPHashPolicy())

alb.add_server(server1)
alb.add_server(server2)

nlb.add_server(server1)
nlb.add_server(server2)
nlb.add_server(server3)

clb.add_server(server1)
clb.add_server(server2)
clb.add_server(server3)

# Simulación de tráfico de red
requests = ["Request 1", "Request 2", "Request 3", "Request 4"]
print("Simulación de tráfico con ALB:")
simulate_traffic(alb, requests)

print("\nSimulación de tráfico con NLB:")
simulate_traffic(nlb, requests)

print("\nSimulación de tráfico con CLB (con IP hashing):")
simulate_traffic(clb, requests)








"""Ejercicio 11: Implementación de elasticidad con Auto Scaling Groups y políticas personalizadas
Objetivo: Desarrollar un sistema de Auto Scaling Group completo con políticas de escalado
personalizadas y simulación de carga.
Instrucciones:
• Diseña una clase ServerTemplate que defina la configuración de las instancias de servidor.
• Implementa una clase AutoScalingGroup que gestione un grupo de servidores, incluyendo
métodos para añadir y remover servidores basados en plantillas.
• Define políticas de escalado personalizadas que utilicen diferentes métricas de rendimiento
(CPU, memoria, latencia de red) para decidir cuándo escalar hacia arriba o hacia abajo.
• Crea un simulador de carga que genere tráfico variable y permita observar cómo el Auto
Scaling Group ajusta su capacidad en respuesta a los cambios en la carga.
• Implementa un sistema de registro que documente todas las decisiones de escalado y el
estado del grupo de servidores en cada momento, permitiendo un análisis detallado del
comportamiento del sistema bajo diferentes condiciones de carga"""

import random
from datetime import datetime

# Clase que define la configuración de las instancias de servidor
class ServerTemplate:
    def __init__(self, cpu_capacity, memory_capacity):
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity

    def create_server(self):
        return Server(self.cpu_capacity, self.memory_capacity)

# Clase que representa un servidor
class Server:
    def __init__(self, cpu_capacity, memory_capacity):
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity
        self.current_load = 0

    def handle_request(self, request):
        # Simulación de manejo de solicitud
        self.current_load += 1

# Clase que gestiona un grupo de servidores con Auto Scaling
class AutoScalingGroup:
    def __init__(self, template, min_size, max_size, scaling_policy):
        self.template = template
        self.min_size = min_size
        self.max_size = max_size
        self.scaling_policy = scaling_policy
        self.servers = [self.template.create_server() for _ in range(min_size)]
        self.log = []

    def scale_out(self):
        if len(self.servers) < self.max_size:
            self.servers.append(self.template.create_server())
            self.log.append({
                "timestamp": datetime.now(),
                "event": "Scaled out",
                "details": f"Added a server. Current size: {len(self.servers)}"
            })

    def scale_in(self):
        if len(self.servers) > self.min_size:
            self.servers.pop()
            self.log.append({
                "timestamp": datetime.now(),
                "event": "Scaled in",
                "details": f"Removed a server. Current size: {len(self.servers)}"
            })

    def adjust_capacity(self):
        # Simulación de métricas de rendimiento (CPU, memoria, latencia de red)
        cpu_usage = random.randint(1, 100)
        memory_usage = random.randint(1, 100)
        network_latency = random.randint(1, 10)

        # Lógica de la política de escalado personalizada
        if self.scaling_policy(cpu_usage, memory_usage, network_latency):
            self.scale_out()
        else:
            self.scale_in()

    def print_log(self):
        for event in self.log:
            print(f"{event['timestamp']} - {event['event']}: {event['details']}")

# Política de escalado personalizada basada en métricas de rendimiento
def custom_scaling_policy(cpu_usage, memory_usage, network_latency):
    # Ejemplo de política de escalado: escalar hacia arriba si el uso de CPU es alto
    return cpu_usage > 70

# Simulador de carga que genera tráfico variable
def simulate_load(auto_scaling_group, num_iterations):
    for i in range(num_iterations):
        auto_scaling_group.adjust_capacity()

# Ejemplo de uso del sistema
template = ServerTemplate(cpu_capacity=4, memory_capacity=8)
asg = AutoScalingGroup(template=template, min_size=2, max_size=5, scaling_policy=custom_scaling_policy)

# Simulación de carga durante 10 iteraciones
simulate_load(asg, num_iterations=10)

# Mostrar registro de eventos de escalado
asg.print_log()








"""Ejercicio 12: Diseño de una arquitectura Multi-Región con alta disponibilidad
Objetivo: Crear una arquitectura de alta disponibilidad multi-región que incluya replicación de datos,
balanceo de carga global, y conmutación por error automática.
Instrucciones:
• Diseña una clase Region que represente una región con sus propios servidores,
balanceadores de carga, y bases de datos.
• Implementa una clase GlobalLoadBalancer que distribuya el tráfico entre regiones
basándose en políticas de enrutamiento como latencia, geolocalización, y disponibilidad.
• Define un sistema de replicación de datos que sincronice bases de datos entre diferentes
regiones, garantizando consistencia y disponibilidad de datos.
• Implementa un mecanismo de conmutación por error que redirija el tráfico a una región
secundaria en caso de falla de la región primaria, asegurando continuidad del servicio.
• Diseña un script que simule tráfico global y fallos de región, observando cómo el sistema
maneja la distribución de carga y la conmutación por error, y generando informes detallados
del rendimiento y la disponibilidad."""

from datetime import datetime
import random


# Clase que representa una región con servidores, balanceador de carga y base de datos
class Region:
    def __init__(self, name):
        self.name = name
        self.servers = []
        self.load_balancer = LoadBalancer()
        self.database = Database()

    def add_server(self, server):
        self.servers.append(server)
        self.load_balancer.add_server(server)

    def handle_request(self, request):
        self.load_balancer.distribute_request(request)


# Clase que representa un balanceador de carga
class LoadBalancer:
    def __init__(self):
        self.servers = []

    def add_server(self, server):
        self.servers.append(server)

    def distribute_request(self, request):
        server = random.choice(self.servers)
        server.handle_request(request)


# Clase que representa una base de datos
class Database:
    def __init__(self):
        self.data = {}

    def replicate(self, data, target_region):
        target_region.database.data.update(data)

    def read_data(self, key):
        return self.data.get(key, None)

    def write_data(self, key, value):
        self.data[key] = value


# Clase que representa un balanceador de carga global
class GlobalLoadBalancer:
    def __init__(self):
        self.regions = []

    def add_region(self, region):
        self.regions.append(region)

    def route_request(self, request):
        # Política de enrutamiento basada en latencia simulada
        latency = [random.randint(1, 100) for _ in range(len(self.regions))]
        best_region = self.regions[latency.index(min(latency))]
        best_region.handle_request(request)


# Función para simular fallos de región
def simulate_region_failure(regions, global_lb):
    # Simulación de fallo de una región
    failed_region = random.choice(regions)
    print(f"Simulating failure of region {failed_region.name}")
    regions.remove(failed_region)

    # Redirección del tráfico al resto de las regiones activas
    for region in regions:
        print(f"Redirecting traffic to region {region.name}")
        global_lb.route_request("Emergency request")


# Función principal de simulación
def simulate_global_traffic(regions, global_lb):
    # Simulación de tráfico global y fallos de región
    for _ in range(10):
        for region in regions:
            region.handle_request(f"Request to {region.name}")

        if random.random() < 0.2:  # Probabilidad de 20% de fallo de región
            simulate_region_failure(regions, global_lb)


# Ejemplo de uso del sistema
if __name__ == "__main__":
    # Creación de regiones y configuración inicial
    region_us_east = Region("us-east-1")
    region_us_west = Region("us-west-1")

    server1_us_east = "Server 1 (US-East)"
    server2_us_east = "Server 2 (US-East)"
    server1_us_west = "Server 1 (US-West)"

    region_us_east.add_server(server1_us_east)
    region_us_east.add_server(server2_us_east)
    region_us_west.add_server(server1_us_west)

    # Agregar regiones al balanceador de carga global
    global_lb = GlobalLoadBalancer()
    global_lb.add_region(region_us_east)
    global_lb.add_region(region_us_west)

    # Simulación de tráfico global y fallos de región
    simulate_global_traffic([region_us_east, region_us_west], global_lb)








"""Ejercicio 13: Diseño de un sistema de balanceo de carga y escalabilidad para una aplicación Web
de alto tráfico
Objetivo: Crear un sistema que combine balanceo de carga y autoescalado para manejar tráfico web
de manera eficiente.
Instrucciones:
• Diseña una clase LoadBalancer que distribuya solicitudes entre múltiples instancias de
servidor, implementando diferentes algoritmos de balanceo de carga como round-robin,
least-connections, y weighted distribution.
• Implementa una clase AutoScalingGroup que gestione un grupo de instancias de servidor,
incluyendo métodos para escalar hacia arriba y hacia abajo basado en métricas de
rendimiento como uso de CPU, memoria, y tráfico de red.
• Integra el balanceador de carga con el grupo de autoescalado para ajustar dinámicamente el
número de instancias activas según la carga del sistema.
• Desarrolla una función que monitoree el rendimiento del sistema y ajuste las políticas de
escalado para optimizar el uso de recursos.
• Implementa un script que simule un entorno de alto tráfico web, generando diferentes
patrones de carga y observando cómo el sistema maneja la distribución de solicitudes y el
ajuste de capacidad, generando informes detallados sobre el rendimiento y la utilización de recursos."""

import random
from collections import defaultdict


# Clase que representa un balanceador de carga con diferentes algoritmos
class LoadBalancer:
    def __init__(self, algorithm="round-robin"):
        self.algorithm = algorithm
        self.servers = []
        self.weights = defaultdict(int)

    def add_server(self, server, weight=1):
        self.servers.append(server)
        self.weights[server] = weight

    def distribute_request(self, request):
        if self.algorithm == "round-robin":
            server = self.servers.pop(0)
            self.servers.append(server)
        elif self.algorithm == "least-connections":
            server = min(self.servers, key=lambda s: s.current_connections)
        elif self.algorithm == "weighted-distribution":
            total_weight = sum(self.weights.values())
            rand = random.randint(1, total_weight)
            for server, weight in self.weights.items():
                rand -= weight
                if rand <= 0:
                    break
        else:
            raise ValueError("Unsupported algorithm")

        server.handle_request(request)


# Clase que representa un grupo de autoescalado
class AutoScalingGroup:
    def __init__(self, min_size, max_size, scaling_policy):
        self.min_size = min_size
        self.max_size = max_size
        self.scaling_policy = scaling_policy
        self.servers = []

    def add_server(self, server):
        self.servers.append(server)

    def scale_out(self):
        if len(self.servers) < self.max_size:
            self.servers.append(Server())
            print("Scaled out: Added a server")

    def scale_in(self):
        if len(self.servers) > self.min_size:
            self.servers.pop()
            print("Scaled in: Removed a server")

    def adjust_capacity(self, metric_values):
        if self.scaling_policy(metric_values):
            self.scale_out()
        else:
            self.scale_in()


# Clase que representa un servidor con métricas simuladas
class Server:
    def __init__(self):
        self.current_connections = 0

    def handle_request(self, request):
        self.current_connections += 1
        print(f"Server handling request: {request}")


# Función de política de escalado basada en métricas simuladas
def cpu_based_scaling_policy(metric_values):
    avg_cpu_usage = sum(metric_values) / len(metric_values)
    return avg_cpu_usage > 70


# Función para simular el entorno de alto tráfico web
def simulate_high_traffic_environment(load_balancer, auto_scaling_group):
    for _ in range(20):  # Simulación de 20 solicitudes
        request_type = random.choice(["GET", "POST", "PUT", "DELETE"])
        request = f"{request_type} /path/to/resource"
        load_balancer.distribute_request(request)

    # Simulación de métricas de uso de CPU para ajuste de capacidad
    cpu_metrics = [random.randint(0, 100) for _ in range(10)]
    auto_scaling_group.adjust_capacity(cpu_metrics)


# Ejemplo de uso del sistema
if __name__ == "__main__":
    lb = LoadBalancer(algorithm="round-robin")
    lb.add_server(Server())
    lb.add_server(Server())

    asg = AutoScalingGroup(min_size=2, max_size=5, scaling_policy=cpu_based_scaling_policy)
    asg.add_server(Server())
    asg.add_server(Server())

    simulate_high_traffic_environment(lb, asg)






'''


"""Ejercicio 14: Simulación de un sistema de monitoreo y recuperación automática para alta
disponibilidad
Objetivo: Desarrollar un sistema que monitoree la salud de los servidores y realice recuperaciones
automáticas en caso de fallos.
Instrucciones:
• Diseña una clase HealthMonitor que supervise la salud de los servidores, utilizando métricas
como tiempo de respuesta, uso de CPU, memoria, y latencia de red.
• Implementa una clase RecoveryManager que tome acciones automáticas en caso de
detección de fallos, como reiniciar servidores, lanzar nuevas instancias, y redirigir tráfico.
• Define un mecanismo para registrar y reportar eventos de monitoreo y acciones de
recuperación, proporcionando detalles sobre el estado del sistema y las medidas tomadas.
• Desarrolla un sistema de balanceo de carga que integre el monitor de salud y el gestor de
recuperación, asegurando que el tráfico se dirija siempre a servidores saludables.
• Implementa un script que simule fallos en el sistema, observando cómo el monitor de salud
detecta problemas y el gestor de recuperación toma acciones correctivas, generando
informes detallados sobre los eventos de monitoreo y las acciones de recuperación realizadas.
"""

import random
from datetime import datetime

# Clase que representa el Health Monitor
class HealthMonitor:
    def __init__(self):
        self.metrics = {}

    def check_health(self, server):
        # Simulación de métricas de salud
        response_time = random.randint(1, 100)
        cpu_usage = random.randint(1, 100)
        memory_usage = random.randint(1, 100)
        network_latency = random.randint(1, 50)

        # Registrar métricas
        self.metrics[server] = {
            "timestamp": datetime.now(),
            "response_time": response_time,
            "cpu_usage": cpu_usage,
            "memory_usage": memory_usage,
            "network_latency": network_latency,
        }

        # Determinar si el servidor está saludable
        if cpu_usage > 80 or memory_usage > 80 or network_latency > 40:
            return False
        return True

# Clase que representa el Recovery Manager
class RecoveryManager:
    def __init__(self):
        self.actions_log = []

    def take_recovery_action(self, server, action):
        # Simulación de acciones de recuperación
        if action == "restart":
            self.actions_log.append(f"{server} restarted.")
        elif action == "launch_new_instance":
            self.actions_log.append(f"Launched new instance for {server}.")
        elif action == "redirect_traffic":
            self.actions_log.append(f"Redirected traffic from {server}.")

    def report_actions(self):
        # Mostrar registro de acciones
        for action in self.actions_log:
            print(action)

# Función para simular el entorno de monitoreo y recuperación
def simulate_monitoring_and_recovery(health_monitor, recovery_manager, servers):
    for server in servers:
        if not health_monitor.check_health(server):
            recovery_manager.take_recovery_action(server, "restart")

    # Simulación de más acciones de recuperación
    for server in servers:
        if not health_monitor.check_health(server):
            recovery_manager.take_recovery_action(server, "launch_new_instance")

    # Mostrar registro de acciones tomadas
    recovery_manager.report_actions()

# Ejemplo de uso del sistema
if __name__ == "__main__":
    while True:
        servers = ["Server1", "Server2", "Server3"]
        health_monitor = HealthMonitor()
        recovery_manager = RecoveryManager()
    
        # Simulación de monitoreo y recuperación
        simulate_monitoring_and_recovery(health_monitor, recovery_manager, servers)





#extras:
def check_keywords(text, keyword1, keyword2):
    # Convertimos el texto a minúsculas para una búsqueda sin distinción de mayúsculas y minúsculas
    text_lower = text.lower()

    # Verificamos la presencia de ambas palabras clave
    if keyword1.lower() in text_lower and keyword2.lower() in text_lower:
        return True
    else:
        return False

# Ejemplo de uso:
texto = "Este es un ejemplo de texto que contiene las palabras clave Python y programación."
palabra_clave1 = "Python"
palabra_clave2 = "programación"

resultado = check_keywords(texto, palabra_clave1, palabra_clave2)
print(resultado)  # Esto imprimirá True si ambas palabras clave están presentes en el texto
