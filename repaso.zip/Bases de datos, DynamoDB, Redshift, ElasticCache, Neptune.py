"""Código
Ejercicio 1: Bases de Datos Administradas vs. No Administradas
Objetivo: Entender la diferencia entre bases de datos administradas y no administradas.
Instrucciones:
• Investiga y define bases de datos administradas y no administradas.
• Escribe un script en Python que simule la creación de una base de datos no administrada
utilizando SQLite y una base de datos administrada (simulada) utilizando una clase
personalizada que automatice tareas comunes (backup, recuperación, etc.).
"""

import sqlite3
import time

# Simulación de base de datos no administrada (SQLite)
conn = sqlite3.connect('unmanaged.db')
cursor = conn.cursor()

# Crear tabla si no existe
cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)''')

# Insertar datos
cursor.execute('''INSERT INTO users (name) VALUES ('Alice')''')

# Guardar cambios
conn.commit()

# Cerrar conexión
conn.close()


# Simulación de base de datos administrada (simulada con una clase ManagedDatabase)
class ManagedDatabase:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_backup()

    def execute_query(self, query):
        self.cursor.execute(query)
        self.conn.commit()
        self.create_backup()

    def create_backup(self):
        with open('backup.sql', 'w') as f:
            for line in self.conn.iterdump():
                f.write('%s\n' % line)
        print("Backup created at", time.ctime())


# Crear instancia de base de datos administrada
managed_db = ManagedDatabase('managed.db')

# Ejecutar consultas en la base de datos administrada
managed_db.execute_query('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)''')
managed_db.execute_query('''INSERT INTO users (name) VALUES ('Bob')''')

# Cerrar conexión de la base de datos administrada
managed_db.conn.close()








"""
Ejercicio 2: Servicios de bases de Datos para Requisitos Especializados
Objetivo: Explorar servicios de bases de datos especializados.
Instrucciones:
• Investiga tres tipos de bases de datos especializadas.
• Escribe un script en Python que simule operaciones básicas en tres bases de datos diferentes
utilizando bibliotecas de Python como tinydb para bases de datos JSON, networkx para grafos y sqlalchemy para bases de datos SQL.
"""
from tinydb import TinyDB, Query
import networkx as nx
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Base de datos JSON con TinyDB
db_json = TinyDB('db.json')
db_json.insert({'type': 'specialized', 'name': 'JSON Database'})

# Base de datos de grafos con NetworkX
G = nx.Graph()
G.add_node("Alice")
G.add_node("Bob")
G.add_edge("Alice", "Bob")
print("Graph nodes:", G.nodes)
print("Graph edges:", G.edges)

# Base de datos relacional con SQLAlchemy
engine = create_engine('sqlite:///specialized.db')
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(String)

# Crear la tabla en la base de datos
Base.metadata.create_all(engine)

# Crear una sesión para interactuar con la base de datos
Session = sessionmaker(bind=engine)
session = Session()

# Insertar datos en la tabla de usuarios
user1 = User(name='Alice')
user2 = User(name='Bob')
session.add(user1)
session.add(user2)
session.commit()

# Consultar todos los usuarios y mostrarlos
users = session.query(User).all()
print("Users in SQL Database:")
for user in users:
    print(f"User ID: {user.id}, Name: {user.name}")

# Cerrar la sesión y la conexión a la base de datos
session.close()








"""Ejercicio 3: Modelos de bases de datos
Objetivo: Comprender diferentes modelos de bases de datos
Instrucciones:
• Escribe un script en Python que cree y manipule diferentes tipos de bases de datos:
relacional (SQLite), documental (TinyDB), y de grafos (NetworkX).
# Relacional (SQLite)"""

import sqlite3
from tinydb import TinyDB
import networkx as nx

# Bases de datos relacional (SQLite)
conn = sqlite3.connect('relational.db')
cursor = conn.cursor()

# Crear tabla de usuarios
cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)''')

# Insertar datos en la tabla
cursor.execute('''INSERT INTO users (name) VALUES ('Alice')''')
cursor.execute('''INSERT INTO users (name) VALUES ('Bob')''')

# Consultar datos
cursor.execute('''SELECT * FROM users''')
print("Relational Database (SQLite):")
for row in cursor.fetchall():
    print(row)

# Commit y cerrar conexión
conn.commit()
conn.close()

# Base de datos documental (TinyDB)
db = TinyDB('documental.json')

# Insertar documento
db.insert({'name': 'Alice'})
db.insert({'name': 'Bob'})

# Consultar documentos
print("\nDocument Database (TinyDB):")
for item in db:
    print(item)

# Base de datos de grafos (NetworkX)
G = nx.Graph()

# Agregar nodos y aristas al grafo
G.add_node("Alice")
G.add_node("Bob")
G.add_edge("Alice", "Bob")

# Mostrar información del grafo
print("\nGraph Database (NetworkX):")
print("Graph nodes:", G.nodes)
print("Graph edges:", G.edges)






"""Ejercicio 4: Simulación de Amazon RDS
Objetivo: Simular una base de datos administrada.
Instrucciones:
• Crea una clase en Python que simule un servicio de base de datos administrada,
implementando características como copias de seguridad automáticas y recuperación ante fallos."""

import sqlite3
import time


class SimulatedRDS:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_backup()

    def execute_query(self, query):
        self.cursor.execute(query)
        self.conn.commit()
        self.create_backup()

    def create_backup(self):
        with open('backup.sql', 'w') as f:
            for line in self.conn.iterdump():
                f.write('%s\n' % line)
        print("Backup created at", time.ctime())

    def restore_from_backup(self):
        with open('backup.sql', 'r') as f:
            sql_script = f.read()
        self.cursor.executescript(sql_script)
        self.conn.commit()
        print("Database restored from backup")


# Ejemplo de uso
rds = SimulatedRDS('simulated_rds.db')

# Crear tabla si no existe y insertar datos
rds.execute_query('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)''')
rds.execute_query('''INSERT INTO users (name) VALUES ('Alice')''')

# Consultar datos
rds.execute_query('''INSERT INTO users (name) VALUES ('Bob')''')
rds.execute_query('''INSERT INTO users (name) VALUES ('Charlie')''')
rds.execute_query('''INSERT INTO users (name) VALUES ('David')''')

# Realizar una copia de seguridad manual
rds.create_backup()

# Simular una recuperación desde la copia de seguridad
rds.execute_query('''DROP TABLE users''')  # Eliminamos la tabla para simular un fallo
rds.restore_from_backup()

# Consultar los datos recuperados
rds.execute_query('''SELECT * FROM users''')
print("\nUsers after restore:")
for row in rds.cursor.fetchall():
    print(row)

# Cerrar la conexión a la base de datos
rds.conn.close()








"""Ejercicio 5: Simulación de Amazon DynamoDB
Objetivo: Simular operaciones de una base de datos NoSQL como DynamoDB.
Instrucciones:
• Utiliza tinydb para simular una base de datos NoSQL, realizando operaciones CRUD y
gestionando la capacidad provisionada"""

from tinydb import TinyDB, Query

# Creación de la tabla en una base de datos JSON con TinyDB
db = TinyDB('dynamodb.json')

# Inserción de datos
db.insert({'id': 1, 'name': 'Alice'})
db.insert({'id': 2, 'name': 'ZZ'})

# Consulta de datos
User = Query()
result = db.search(User.name == 'Alice')
print("Consulta de datos:", result)

# Actualización de datos
db.update({'name': 'Alice Updated'}, User.id == 1)
print("Datos actualizados:", db.get(User.id == 1))

# Eliminación de datos
db.remove(User.id == 2)
print("Datos después de eliminar:", db.all())








"""Ejercicio 6: Simulación de Amazon Redshift
Objetivo: Simular un almacén de datos y operaciones OLAP.
Instrucciones:
• Utiliza pandas y sqlite3 para simular la carga de grandes volúmenes de datos y realizar consultas analíticas."""


import pandas as pd
import sqlite3

# Creación de la base de datos SQLite
conn = sqlite3.connect('redshift.db')
cursor = conn.cursor()

# Creación de la tabla de ventas
cursor.execute('''CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY,
                    amount REAL,
                    date TEXT
                )''')
conn.commit()

# Carga de datos de ejemplo
data = [(1, 100.0, '2023-01-01'), (2, 200.0, '2023-01-02')]
cursor.executemany('INSERT INTO sales VALUES (?, ?, ?)', data)
conn.commit()

# Consulta OLAP utilizando pandas
df = pd.read_sql_query('SELECT date, SUM(amount) as total_sales FROM sales GROUP BY date', conn)
print("Consulta OLAP:")
print(df)

# Cierre de la conexión
conn.close()





"""Ejercicio 7: Simulación de ElastiCache
Objetivo: Simular un caché en memoria.
Instrucciones:
Utiliza redis-py para simular operaciones de caché en memoria."""

import redis

# Conexión a Redis (asegúrate de tener un servidor Redis ejecutándose localmente o ajusta los parámetros de conexión según tu configuración)
r = redis.Redis(host='localhost', port=6379, db=0)

# Inserción de datos en caché
r.set('user:1', 'Alice')
r.set('user:2', 'ZZ')

# Recuperación de datos del caché
print("Datos recuperados del caché:")
print(r.get('user:1').decode('utf-8'))  # Output: Alice
print(r.get('user:2').decode('utf-8'))  # Output: ZZ








"""Ejercicio 8: Simulación de Amazon Neptune
Objetivo: Simular una base de datos de grafos.
Instrucciones:
• Utiliza networkx para crear y consultar una base de datos de grafos."""
import networkx as nx
# Creación del grafo
G = nx.Graph()
G.add_node("Alice")
G.add_node("ZZ")
G.add_edge("Alice", "ZZ")
# Consultas en el grafo
print("Nodes:", G.nodes)
print("Edges:", G.edges)






"""
Ejercicio 9: Simulación de Amazon QLDB
Objetivo: Simular una base de datos de libro mayor.
Instrucciones:
• Crea una clase en Python que registre transacciones y permita consultas de estado."""


class Ledger:
    def __init__(self):
        self.transactions = []

    def record_transaction(self, transaction):
        self.transactions.append(transaction)

    def get_transactions(self):
        return self.transactions


# Ejemplo de uso
ledger = Ledger()

# Registrar transacciones
ledger.record_transaction({'id': 1, 'action': 'create', 'data': 'Alice'})
ledger.record_transaction({'id': 2, 'action': 'update', 'data': 'Alice Updated'})

# Obtener todas las transacciones registradas
transactions = ledger.get_transactions()

# Imprimir las transacciones registradas
print("Transacciones registradas en el libro mayor:")
for transaction in transactions:
    print(transaction)









"""
Ejercicio 10: Simulación de Database Migration Service (DMS)
Objetivo: Simular la migración de datos entre bases de datos.
Instrucciones:
• Escribe un script en Python que copie datos de una base de datos SQLite a otra.
import sqlite3
# Base de datos de origen"""


import sqlite3

# Base de datos de origen
src_conn = sqlite3.connect('source.db')
src_cursor = src_conn.cursor()

# Crear tabla si no existe y insertar datos de ejemplo
src_cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)''')
src_cursor.execute('''INSERT INTO users (name) VALUES ('Alice')''')
src_conn.commit()

# Base de datos de destino
dst_conn = sqlite3.connect('destination.db')
dst_cursor = dst_conn.cursor()

# Crear tabla si no existe en la base de datos de destino
dst_cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)''')
dst_conn.commit()

# Migración de datos
for row in src_cursor.execute('SELECT * FROM users'):
    dst_cursor.execute('INSERT INTO users VALUES (?, ?)', row)
dst_conn.commit()

# Verificación de datos en la base de datos de destino
print("Datos migrados correctamente a la base de datos de destino:")
for row in dst_cursor.execute('SELECT * FROM users'):
    print(row)

# Cerrar conexiones
src_conn.close()
dst_conn.close()








"""Ejercicio 11: Simulación de unsistema de gestión de bases de datos administradas y No
administradas
Objetivo: Desarrollar un sistema completo que gestione bases de datos administradas y no
administradas, permitiendo operaciones CRUD, respaldo y recuperación automática, y monitoreo
del rendimiento.
Instrucciones:
• Diseña una clase base Database que soporte operaciones CRUD.
• Implementa una clase UnmanagedDatabase que extienda Database y utilice SQLite.
• Implementa una clase ManagedDatabase que extienda Database, automatizando respaldos,
recuperación, y monitoreo de rendimiento.
• Implementa un sistema de monitoreo que registre y muestre estadísticas de rendimiento
(tiempo de respuesta, tasa de errores, etc.).
• Diseña un script que permita la creación, operación, y gestión de instancias de bases de
datos administradas y no administradas"""


#Paso 1: Diseño de Clase Base Database
#La clase Database servirá como clase base para nuestras implementaciones de bases de datos administradas y no administradas. Incluirá métodos básicos para operaciones CRUD (Create, Read, Update, Delete).
import abc


class Database(abc.ABC):
    def __init__(self, db_name):
        self.db_name = db_name

    @abc.abstractmethod
    def create(self, table_name, **kwargs):
        pass

    @abc.abstractmethod
    def read(self, table_name, condition=None):
        pass

    @abc.abstractmethod
    def update(self, table_name, condition, **kwargs):
        pass

    @abc.abstractmethod
    def delete(self, table_name, condition):
        pass


#Paso 2: Implementación de UnmanagedDatabase
#Esta clase extenderá Database y utilizará SQLite para simular una base de datos no administrada.

import sqlite3


class UnmanagedDatabase(Database):
    def __init__(self, db_name):
        super().__init__(db_name)
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()

    def create(self, table_name, **kwargs):
        columns = ', '.join(kwargs.keys())
        values = tuple(kwargs.values())
        placeholders = ', '.join(['?'] * len(kwargs))
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        self.cursor.execute(query, values)
        self.conn.commit()

    def read(self, table_name, condition=None):
        query = f"SELECT * FROM {table_name}"
        if condition:
            query += f" WHERE {condition}"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def update(self, table_name, condition, **kwargs):
        updates = ', '.join([f"{key} = ?" for key in kwargs.keys()])
        values = tuple(kwargs.values())
        query = f"UPDATE {table_name} SET {updates} WHERE {condition}"
        self.cursor.execute(query, values)
        self.conn.commit()

    def delete(self, table_name, condition):
        query = f"DELETE FROM {table_name} WHERE {condition}"
        self.cursor.execute(query)
        self.conn.commit()

#Paso 3: Implementación de ManagedDatabase
#Esta clase también extenderá Database y agregará funcionalidades adicionales como respaldo automático y monitoreo del rendimiento (simulado).

import sqlite3
import time


class ManagedDatabase(Database):
    def __init__(self, db_name):
        super().__init__(db_name)
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_backup()

    def create_backup(self):
        backup_name = f"{self.db_name}.backup.sql"
        with open(backup_name, 'w') as f:
            for line in self.conn.iterdump():
                f.write(f"{line}\n")
        print(f"Backup created for {self.db_name} at {time.ctime()}")

    def restore_backup(self, backup_file):
        with open(backup_file, 'r') as f:
            sql_script = f.read()
        self.cursor.executescript(sql_script)
        self.conn.commit()
        print(f"Database {self.db_name} restored from backup")

    def monitor_performance(self):
        # Simulación de monitoreo de rendimiento
        response_time = 0.2  # Ejemplo de tiempo de respuesta en segundos
        error_rate = 0.05  # Ejemplo de tasa de errores (5%)
        print(f"Monitoring performance of {self.db_name}:")
        print(f" - Response time: {response_time} seconds")
        print(f" - Error rate: {error_rate}%")


#Paso 4: Ejemplo de Uso
#A continuación, un ejemplo de cómo usar estas clases para crear, operar y gestionar instancias de bases de datos administradas y no administradas:

# Ejemplo de uso
if __name__ == "__main__":
    # Crear y operar base de datos no administrada
    unmanaged_db = UnmanagedDatabase('unmanaged.db')
    unmanaged_db.create('users', id=1, name='Alice')
    print("Datos de usuarios en la base de datos no administrada:")
    print(unmanaged_db.read('users'))

    # Crear y operar base de datos administrada
    managed_db = ManagedDatabase('managed.db')
    managed_db.create('users', id=1, name='Alice')
    managed_db.create_backup()
    managed_db.monitor_performance()
    print("Datos de usuarios en la base de datos administrada:")
    print(managed_db.read('users'))








"""Ejercicio 12: Implementación de un motor de bases de datos especializadas
Objetivo: Crear un sistema que soporte múltiples tipos de bases de datos especializadas y permita la
interacción entre ellas.
Instrucciones:
• Implementa una base de datos documental utilizando tinydb.
• Implementa una base de datos de grafos utilizando networkx.
• Implementa una base de datos relacional utilizando sqlalchemy.
• Diseña un sistema que permita consultas y operaciones cruzadas entre las diferentes bases de datos.
Implementa un sistema de sincronización de datos que mantenga la coherencia entre las
bases de datos especializadas."""

#Paso 1: Implementación de las Bases de Datos Especializadas
#Base de Datos Documental (TinyDB)
from tinydb import TinyDB, Query


class DocumentDatabase:
    def __init__(self, db_file):
        self.db = TinyDB(db_file)

    def insert_document(self, data):
        return self.db.insert(data)

    def get_document(self, doc_id):
        return self.db.get(doc_id=doc_id)

    def update_document(self, doc_id, data):
        return self.db.update(data, doc_ids=[doc_id])

    def delete_document(self, doc_id):
        return self.db.remove(doc_ids=[doc_id])
#Base de Datos de Grafos (NetworkX)
import networkx as nx


class GraphDatabase:
    def __init__(self):
        self.graph = nx.Graph()

    def add_node(self, node):
        self.graph.add_node(node)

    def add_edge(self, node1, node2):
        self.graph.add_edge(node1, node2)

    def get_nodes(self):
        return list(self.graph.nodes)

    def get_edges(self):
        return list(self.graph.edges)
#Base de Datos Relacional (SQLAlchemy)
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()


class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(String)

    def __repr__(self):
        return f"<User(id={self.id}, name={self.name})>"


class RelationalDatabase:
    def __init__(self, db_url):
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def add_user(self, name):
        session = self.Session()
        user = User(name=name)
        session.add(user)
        session.commit()
        session.close()

    def get_users(self):
        session = self.Session()
        users = session.query(User).all()
        session.close()
        return users
#Paso 2: Sistema de Consultas y Operaciones Cruzadas
#A continuación, integraremos estas clases en un sistema que permita consultas y operaciones cruzadas entre las bases de datos especializadas.

class DatabaseSystem:
    def __init__(self):
        self.document_db = DocumentDatabase('documental.json')
        self.graph_db = GraphDatabase()
        self.relational_db = RelationalDatabase('sqlite:///relational.db')

    # Métodos de interacción con bases de datos documental
    def insert_document(self, data):
        return self.document_db.insert_document(data)

    def get_document(self, doc_id):
        return self.document_db.get_document(doc_id)

    def update_document(self, doc_id, data):
        return self.document_db.update_document(doc_id, data)

    def delete_document(self, doc_id):
        return self.document_db.delete_document(doc_id)

    # Métodos de interacción con bases de datos de grafos
    def add_node_to_graph(self, node):
        self.graph_db.add_node(node)

    def add_edge_to_graph(self, node1, node2):
        self.graph_db.add_edge(node1, node2)

    def get_graph_nodes(self):
        return self.graph_db.get_nodes()

    def get_graph_edges(self):
        return self.graph_db.get_edges()

    # Métodos de interacción con bases de datos relacionales
    def add_user_to_relational_db(self, name):
        self.relational_db.add_user(name)

    def get_users_from_relational_db(self):
        return self.relational_db.get_users()

#Paso 3: Implementación del Sistema de Sincronización de Datos
#Para mantener la coherencia entre las bases de datos especializadas, implementaremos métodos de sincronización básicos que actualicen los datos entre ellas según sea necesario.

class DataSynchronization:
    def __init__(self, db_system):
        self.db_system = db_system

    def sync_document_to_graph(self, doc_id):
        doc = self.db_system.get_document(doc_id)
        if doc:
            self.db_system.add_node_to_graph(doc['name'])

    def sync_graph_to_document(self):
        nodes = self.db_system.get_graph_nodes()
        for node in nodes:
            self.db_system.insert_document({'name': node})

    def sync_relational_to_document(self):
        users = self.db_system.get_users_from_relational_db()
        for user in users:
            self.db_system.insert_document({'name': user.name})

    def sync_all(self):
        self.sync_graph_to_document()
        self.sync_relational_to_document()


# Ejemplo de uso
if __name__ == "__main__":
    db_system = DatabaseSystem()
    sync_manager = DataSynchronization(db_system)

    # Ejemplo de operaciones y consultas cruzadas
    db_system.add_user_to_relational_db('Alice')
    db_system.add_user_to_relational_db('Bob')
    print("Usuarios en base de datos relacional:")
    print(db_system.get_users_from_relational_db())

    db_system.insert_document({'name': 'Document1'})
    db_system.insert_document({'name': 'Document2'})
    print("Documentos en base de datos documental:")
    print(db_system.get_document(1))
    print(db_system.get_document(2))

    db_system.add_node_to_graph('Node1')
    db_system.add_node_to_graph('Node2')
    db_system.add_edge_to_graph('Node1', 'Node2')
    print("Nodos y aristas en base de datos de grafos:")
    print(db_system.get_graph_nodes())
    print(db_system.get_graph_edges())

    # Sincronización de datos entre bases de datos
    sync_manager.sync_all()
    print("Documentos actualizados después de sincronización:")
    print(db_system.get_document(3))  # Debe incluir los usuarios de la base relacional
    print(db_system.get_document(4))  # Debe incluir los nodos del grafo







"""Ejercicio 13: Simulación de un Almacén de Datos y Procesamiento OLAP
Objetivo: Crear un sistema de almacén de datos que permita la carga masiva de datos,
procesamiento OLAP, y generación de informes.
Instrucciones:
• Implementa un sistema de carga de datos que ingeste grandes volúmenes de datos desde
diferentes fuentes (archivos CSV, bases de datos relacionales, etc.).
• Diseña un sistema de almacenamiento que organice los datos en esquemas de estrella y
copo de nieve.
• Implementa un motor de consultas OLAP que soporte operaciones de agregación, filtrado y
análisis de datos.
• Diseña un sistema de generación de informes que presente los resultados de las consultas
OLAP en formatos visuales (tablas, gráficos).
• Desarrolla un script que simule diferentes escenarios de carga y consulta, evaluando el
rendimiento del sistema"""

#Paso 1: Sistema de Carga de Datos
#Implementaremos una función para cargar datos desde archivos CSV hacia una base de datos relacional SQLite.
import csv
import sqlite3


def load_data_from_csv(csv_file, db_file):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()

    with open(csv_file, 'r') as file:
        csv_reader = csv.reader(file)
        headers = next(csv_reader)

        # Crear tabla en base de datos
        create_table_sql = f"CREATE TABLE IF NOT EXISTS data ({', '.join(headers)})"
        cursor.execute(create_table_sql)

        # Ingesta de datos
        insert_sql = f"INSERT INTO data ({', '.join(headers)}) VALUES ({', '.join(['?'] * len(headers))})"
        for row in csv_reader:
            cursor.execute(insert_sql, row)

    conn.commit()
    conn.close()


# Ejemplo de uso para cargar datos de un archivo CSV a una base de datos SQLite
load_data_from_csv('data.csv', 'olap_db.sqlite')

#Paso 2: Almacenamiento en Esquemas de Estrella y Copo de Nieve
#Aunque SQLite no es ideal para esquemas de estrella o copo de nieve complejos, podemos estructurar las tablas según necesitemos para simular el concepto.

# Ejemplo simplificado de definición de tablas en SQLite
conn = sqlite3.connect('olap_db.sqlite')
cursor = conn.cursor()

# Tabla de hechos (fact table)
cursor.execute('''CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY,
                    date TEXT,
                    amount REAL,
                    product_id INTEGER,
                    customer_id INTEGER
                )''')

# Tablas de dimensiones (dimension tables)
cursor.execute('''CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    category TEXT
                )''')

cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    city TEXT
                )''')

conn.commit()
conn.close()

#Paso 3: Motor de Consultas OLAP
#Implementaremos consultas que realicen operaciones típicas de OLAP, como agregaciones y filtrados.

def olap_query(db_file):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()

    # Ejemplo de consulta OLAP para calcular ventas totales por producto
    query = '''
        SELECT p.name AS product_name, SUM(s.amount) AS total_sales
        FROM sales s
        JOIN products p ON s.product_id = p.id
        GROUP BY p.name
    '''
    cursor.execute(query)
    results = cursor.fetchall()

    conn.close()
    return results


# Ejemplo de uso de consulta OLAP
olap_results = olap_query('olap_db.sqlite')
print("Resultados de consulta OLAP:")
for result in olap_results:
    print(result)

#Paso 4: Generación de Informes
#Utilizaremos bibliotecas como pandas y matplotlib para generar informes visuales a partir de los resultados de las consultas OLAP.
import pandas as pd
import matplotlib.pyplot as plt

def generate_report(results):
    df = pd.DataFrame(results, columns=['Product Name', 'Total Sales'])
    df.plot(kind='bar', x='Product Name', y='Total Sales', legend=None)
    plt.title('Total Sales by Product')
    plt.xlabel('Product Name')
    plt.ylabel('Total Sales')
    plt.show()

# Ejemplo de generación de informe visual
generate_report(olap_results)


# Simulación de carga y consulta
load_data_from_csv('data.csv', 'olap_db.sqlite')
olap_results = olap_query('olap_db.sqlite')
generate_report(olap_results)











"""Ejercicio 14: Desarrollo de un Sistema de Caché en Memoria
Objetivo: Crear un sistema de caché en memoria que emule las funcionalidades de Amazon
ElastiCache utilizando Redis.
Instrucciones:
• Implementa una clase InMemoryCache que soporte operaciones de almacenamiento y
recuperación de datos.
• Diseña un sistema que permita la configuración y gestión del caché (políticas de expiración,
capacidad máxima, etc.).
• Implementa un mecanismo de respaldo que permita la persistencia de datos del caché en
almacenamiento secundario.
• Diseña un sistema de invalidación y actualización de caché que mantenga la coherencia de
datos con una base de datos principal.
• Desarrolla un script que simule diferentes escenarios de uso del caché y analice el impacto
en el rendimiento de la aplicación."""


#Paso 1: Implementar la Clase InMemoryCache
#Implementaremos una clase que soporte operaciones de almacenamiento y recuperación de datos utilizando redis-py.
import redis
import time

class InMemoryCache:
    def __init__(self, host='localhost', port=6379, db=0):
        self.cache = redis.Redis(host=host, port=port, db=db)

    def set(self, key, value, expiration=None):
        self.cache.set(key, value, ex=expiration)

    def get(self, key):
        return self.cache.get(key)

    def delete(self, key):
        self.cache.delete(key)

    def backup(self, backup_file='cache_backup.txt'):
        with open(backup_file, 'w') as f:
            for key in self.cache.keys('*'):
                value = self.cache.get(key)
                f.write(f'{key.decode()},{value.decode()}\n')
        print(f"Backup created at {time.ctime()}")

    def restore(self, backup_file='cache_backup.txt'):
        with open(backup_file, 'r') as f:
            for line in f:
                key, value = line.strip().split(',')
                self.set(key, value)
        print("Cache restored from backup")

# Ejemplo de uso de InMemoryCache
cache = InMemoryCache()
cache.set('user:1', 'Alice', expiration=3600)
cache.set('user:2', 'ZZ')
print(cache.get('user:1'))  # Output: b'Alice'
print(cache.get('user:2'))  # Output: b'ZZ'
cache.backup()
cache.delete('user:1')
cache.delete('user:2')
cache.restore()
print(cache.get('user:1'))  # Output: b'Alice'
print(cache.get('user:2'))  # Output: b'ZZ'

#Paso 2: Configuración y Gestión del Caché
#Añadiremos soporte para políticas de expiración y capacidad máxima.

class InMemoryCache:
    def __init__(self, host='localhost', port=6379, db=0, max_capacity=None):
        self.cache = redis.Redis(host=host, port=port, db=db)
        self.max_capacity = max_capacity

    def set(self, key, value, expiration=None):
        if self.max_capacity and len(self.cache.keys('*')) >= self.max_capacity:
            # Implementar política de eliminación (e.g., LRU, FIFO)
            self._evict()
        self.cache.set(key, value, ex=expiration)

    def get(self, key):
        return self.cache.get(key)

    def delete(self, key):
        self.cache.delete(key)

    def backup(self, backup_file='cache_backup.txt'):
        with open(backup_file, 'w') as f:
            for key in self.cache.keys('*'):
                value = self.cache.get(key)
                f.write(f'{key.decode()},{value.decode()}\n')
        print(f"Backup created at {time.ctime()}")

    def restore(self, backup_file='cache_backup.txt'):
        with open(backup_file, 'r') as f:
            for line in f:
                key, value = line.strip().split(',')
                self.set(key, value)
        print("Cache restored from backup")

    def _evict(self):
        # Implementar lógica de eliminación de elementos del caché
        keys = self.cache.keys('*')
        if keys:
            self.delete(keys[0])  # Ejemplo simple: eliminar el primer elemento

# Ejemplo de uso con capacidad máxima
cache = InMemoryCache(max_capacity=2)
cache.set('user:1', 'Alice')
cache.set('user:2', 'ZZ')
cache.set('user:3', 'Bob')  # Esto debería activar la política de eliminación
print(cache.get('user:1'))  # Output: None (dependiendo de la política de eliminación)

#Paso 3: Sistema de Invalidez y Actualización del Caché
#Implementaremos un mecanismo para mantener la coherencia de datos con una base de datos principal.

import sqlite3


class InMemoryCacheWithDB:
    def __init__(self, db_file, host='localhost', port=6379, db=0, max_capacity=None):
        self.cache = redis.Redis(host=host, port=port, db=db)
        self.max_capacity = max_capacity
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()

    def set(self, key, value, expiration=None):
        if self.max_capacity and len(self.cache.keys('*')) >= self.max_capacity:
            self._evict()
        self.cache.set(key, value, ex=expiration)
        # Actualizar la base de datos principal
        self.cursor.execute('INSERT OR REPLACE INTO cache (key, value) VALUES (?, ?)', (key, value))
        self.conn.commit()

    def get(self, key):
        value = self.cache.get(key)
        if value is None:
            # Recuperar de la base de datos principal si no está en el caché
            self.cursor.execute('SELECT value FROM cache WHERE key = ?', (key,))
            row = self.cursor.fetchone()
            if row:
                value = row[0]
                self.cache.set(key, value)
        return value

    def delete(self, key):
        self.cache.delete(key)
        self.cursor.execute('DELETE FROM cache WHERE key = ?', (key,))
        self.conn.commit()

    def backup(self, backup_file='cache_backup.txt'):
        with open(backup_file, 'w') as f:
            for key in self.cache.keys('*'):
                value = self.cache.get(key)
                f.write(f'{key.decode()},{value.decode()}\n')
        print(f"Backup created at {time.ctime()}")

    def restore(self, backup_file='cache_backup.txt'):
        with open(backup_file, 'r') as f:
            for line in f:
                key, value = line.strip().split(',')
                self.set(key, value)
        print("Cache restored from backup")

    def _evict(self):
        keys = self.cache.keys('*')
        if keys:
            self.delete(keys[0])  # Ejemplo simple: eliminar el primer elemento


# Crear tabla de caché en la base de datos principal
def create_db_table(db_file):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT)''')
    conn.commit()
    conn.close()


# Ejemplo de uso
create_db_table('main_db.sqlite')
cache_with_db = InMemoryCacheWithDB('main_db.sqlite')
cache_with_db.set('user:1', 'Alice')
cache_with_db.set('user:2', 'ZZ')
print(cache_with_db.get('user:1'))  # Output: b'Alice'
cache_with_db.backup()
cache_with_db.delete('user:1')
print(cache_with_db.get('user:1'))  # Output: Alice (recuperado de la base de datos principal)
cache_with_db.restore()

#Simulación de Escenarios de Uso del Caché
#Finalmente, desarrollaremos un script para simular diferentes escenarios de uso del caché y analizar el impacto en el rendimiento de la aplicación.

import time


def simulate_cache_usage(cache):
    start_time = time.time()

    # Insertar datos en caché
    for i in range(1000):
        cache.set(f'user:{i}', f'User{i}')

    # Recuperar datos del caché
    for i in range(1000):
        cache.get(f'user:{i}')

    # Eliminar algunos datos
    for i in range(100, 200):
        cache.delete(f'user:{i}')

    end_time = time.time()
    print(f"Tiempo total de simulación: {end_time - start_time} segundos")


# Simular el uso del caché
cache_sim = InMemoryCacheWithDB('main_db.sqlite')
simulate_cache_usage(cache_sim)









"""Ejercicio 15 [Opcional]: Implementación de un servicio completo de migración de datos
Objetivo: Desarrollar un sistema de migración de datos que soporte múltiples fuentes y destinos de
bases de datos, emulando las funcionalidades de AWS DMS.
Instrucciones:
• Implementa una clase DataSource que soporte la conexión a diferentes tipos de bases de datos (relacional, NoSQL).
• Diseña un sistema que permita la extracción, transformación y carga (ETL) de datos entre
bases de datos de diferentes tipos.
• Implementa un mecanismo de sincronización en tiempo real que mantenga los datos
consistentes entre las bases de datos origen y destino durante la migración.
• Diseña un sistema de monitoreo que registre el progreso, estado y rendimiento de la migración.
• Desarrolla un script que simule la migración de una base de datos grande, evaluando la
integridad, consistencia y rendimiento del sistema"""

#Paso 1: Implementar la Clase DataSource
#La clase DataSource soportará la conexión a diferentes tipos de bases de datos (relacional y NoSQL).

import sqlite3
from tinydb import TinyDB, Query
import redis
from sqlalchemy import create_engine, Column, Integer, String, Base
import time

class DataSource:
    def __init__(self, db_type, db_name, **kwargs):
        self.db_type = db_type
        if db_type == 'sqlite':
            # Conexión a una base de datos SQLite
            self.conn = sqlite3.connect(db_name)
            self.cursor = self.conn.cursor()
        elif db_type == 'tinydb':
            # Conexión a una base de datos TinyDB (documental)
            self.conn = TinyDB(db_name)
        elif db_type == 'redis':
            # Conexión a una base de datos Redis
            self.conn = redis.Redis(host=kwargs.get('host', 'localhost'), port=kwargs.get('port', 6379), db=kwargs.get('db', 0))
        elif db_type == 'sqlalchemy':
            # Conexión a una base de datos SQL usando SQLAlchemy
            self.engine = create_engine(db_name)
            self.conn = self.engine.connect()
            self.Base = Base

    def execute_query(self, query, params=None):
        if self.db_type == 'sqlite':
            # Ejecutar una consulta en SQLite
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            self.conn.commit()
        elif self.db_type == 'tinydb':
            # Ejecutar una inserción en TinyDB
            if query == 'insert':
                self.conn.insert(params)
        elif self.db_type == 'redis':
            # Ejecutar operaciones en Redis
            if query == 'set':
                self.conn.set(params[0], params[1])
            elif query == 'get':
                return self.conn.get(params[0])
        elif self.db_type == 'sqlalchemy':
            # Ejecutar una consulta en SQLAlchemy
            self.conn.execute(query)

    def fetch_all(self, query):
        if self.db_type == 'sqlite':
            # Obtener todos los resultados de una consulta en SQLite
            self.cursor.execute(query)
            return self.cursor.fetchall()
        elif self.db_type == 'sqlalchemy':
            # Obtener todos los resultados de una consulta en SQLAlchemy
            result = self.conn.execute(query)
            return result.fetchall()

# Ejemplo de uso
sqlite_source = DataSource(db_type='sqlite', db_name='source.db')
tinydb_source = DataSource(db_type='tinydb', db_name='tinydb.json')
redis_source = DataSource(db_type='redis', host='localhost', port=6379, db=0)

#Paso 2: Proceso ETL
#Diseñaremos un sistema que permita la extracción, transformación y carga de datos entre bases de datos de diferentes tipos.

class ETLProcess:
    def __init__(self, source, destination):
        self.source = source
        self.destination = destination

    def extract(self, query):
        # Extraer datos de la base de datos fuente
        return self.source.fetch_all(query)

    def transform(self, data):
        # Transformar los datos si es necesario
        return data

    def load(self, data):
        # Cargar datos en la base de datos destino
        if self.destination.db_type == 'sqlite' or self.destination.db_type == 'sqlalchemy':
            for row in data:
                self.destination.execute_query('INSERT INTO users (id, name) VALUES (?, ?)', row)
        elif self.destination.db_type == 'tinydb':
            for row in data:
                self.destination.execute_query('insert', {'id': row[0], 'name': row[1]})
        elif self.destination.db_type == 'redis':
            for row in data:
                self.destination.execute_query('set', (f'user:{row[0]}', row[1]))

    def run(self, query):
        # Ejecutar el proceso ETL completo
        data = self.extract(query)
        transformed_data = self.transform(data)
        self.load(transformed_data)

# Ejemplo de uso
etl = ETLProcess(source=sqlite_source, destination=tinydb_source)
sqlite_source.execute_query('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)')
sqlite_source.execute_query('INSERT INTO users (id, name) VALUES (?, ?)', (1, 'Alice'))
etl.run('SELECT * FROM users')

#Paso 3: Sincronización en Tiempo Real
#Implementaremos un mecanismo para mantener los datos consistentes entre las bases de datos origen y destino durante la migración.

import threading

class RealTimeSync:
    def __init__(self, source, destination):
        self.source = source
        self.destination = destination
        self.lock = threading.Lock()
        self.stop_event = threading.Event()

    def sync(self):
        # Sincronizar datos en tiempo real
        while not self.stop_event.is_set():
            with self.lock:
                data = self.source.fetch_all('SELECT * FROM users')
                for row in data:
                    self.destination.execute_query('INSERT OR REPLACE INTO users (id, name) VALUES (?, ?)', row)
            time.sleep(5)  # Sincronización cada 5 segundos

    def start(self):
        # Iniciar sincronización
        self.thread = threading.Thread(target=self.sync)
        self.thread.start()

    def stop(self):
        # Detener sincronización
        self.stop_event.set()
        self.thread.join()

# Ejemplo de uso
realtime_sync = RealTimeSync(source=sqlite_source, destination=tinydb_source)
realtime_sync.start()
# Para detener la sincronización
# realtime_sync.stop()

#Paso 4: Sistema de Monitoreo
#Diseñaremos un sistema que registre el progreso, estado y rendimiento de la migración.

class MigrationMonitor:
    def __init__(self):
        self.logs = []

    def log(self, message):
        # Registrar mensajes de log
        timestamp = time.ctime()
        self.logs.append(f"[{timestamp}] {message}")
        print(f"[{timestamp}] {message}")

# Ejemplo de uso
monitor = MigrationMonitor()
monitor.log("Migration started.")

#Paso 5: Simulación de la Migración de una Base de Datos Grande
#Desarrollaremos un script para simular la migración y evaluar la integridad, consistencia y rendimiento del sistema.

# Simulación de la migración
def simulate_large_db_migration():
    monitor.log("Simulating large database migration.")

    # Crear datos grandes en la base de datos de origen
    sqlite_source.execute_query('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)')
    for i in range(1, 10001):
        sqlite_source.execute_query('INSERT INTO users (id, name) VALUES (?, ?)', (i, f'User{i}'))

    # Migración de datos
    etl = ETLProcess(source=sqlite_source, destination=tinydb_source)
    etl.run('SELECT * FROM users')

    monitor.log("Data migration completed.")
    monitor.log(f"Total records migrated: {len(tinydb_source.conn.all())}")

    # Sincronización en tiempo real
    realtime_sync = RealTimeSync(source=sqlite_source, destination=tinydb_source)
    realtime_sync.start()
    time.sleep(10)  # Ejecutar sincronización por 10 segundos
    realtime_sync.stop()

    monitor.log("Real-time synchronization completed.")

simulate_large_db_migration()



