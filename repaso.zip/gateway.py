class WebApplicationFirewall:
   def __init__(self):
       self.rules = []
   def add_rule(self, rule, name=None): #Añade la regla a la lista de reglas
       if name is None:
           name = rule.__name__
       self.rules.append((rule, name))
   def apply_rules(self, request): #Examina si la consulta pasa todas las reglas
       for rule, name in self.rules:
           if not rule(request):
               print(f"Request blocked by rule: {name}")
               return False
       return True

def block_ip_rule(ip, blocked_ips): #Verifica si la ip de la consulta no pertene a la lista de ips bloqueadas
   return ip not in blocked_ips

def sql_injection_rule(query): #verifica que en las consultas no se encuentre ninguna de esas ordenes
   if any(keyword in query.lower() for keyword in ["select", "drop", "insert", "delete"]):
       return False
   return True

def xss_rule(content): #Verifica que la consulta no sea un condigo
   if "<script>" in content.lower():
       return False
   return True

# Ejemplo de servers
servers = ["Server 1", "Server 2", "Server 3"]

def load_balancer(request): # Distribucion de la carga entre cada servido
   server = servers[load_balancer.counter % len(servers)]
   load_balancer.counter += 1
   return server

load_balancer.counter = 0
blocked_ips = []
# WAF instance
waf = WebApplicationFirewall()
waf.add_rule(lambda req: block_ip_rule(req["ip"], blocked_ips), "block_ip_rule")
waf.add_rule(lambda req: sql_injection_rule(req["query"]), "sql_injection_rule")
waf.add_rule(lambda req: xss_rule(req["content"]), "xss_rule")

# Ejemplo de consultas
requests = [
   {"ip": "192.168.0.2", "query": "SELECT * FROM users", "content": "Hello World"},
   {"ip": "192.168.0.1", "query": "DROP TABLE users", "content": "Hello World"},
   {"ip": "192.168.0.3", "query": "UPDATE users SET name='admin'", "content": "Hello <script>alert('xss')</script>"},
   {"ip": "192.168.0.4", "query": "INSERT INTO users (name) VALUES ('user')", "content": "Safe content"},
   {"ip": "192.168.0.4", "query": "INTO users (name) VALUES ('user')", "content": "Safe content"}
]

# Iniciar consultas
       if waf.apply_rules(request):
       server = load_balancer(request)
       print(f"Request passed through WAF and is being handled by {server}")
   else:
       blocked_ips.append(request['ip'])
       print("Request blocked by WAF")

