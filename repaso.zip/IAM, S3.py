import random
import uuid


class ServicioIAM:
    def __init__(self):
        self.usuarios = {}
        self.grupos = {}
        self.politicas = {}
        self.roles = {}


class ConsolaIAM:
    def crear_usuario(self, servicio_iam, nombre_usuario):
        servicio_iam.usuarios[nombre_usuario] = {'politicas': [], 'mfa_habilitado': False, 'codigo_mfa': None}
        print(f"Usuario '{nombre_usuario}' creado.")

    def crear_grupo(self, servicio_iam, nombre_grupo):
        servicio_iam.grupos[nombre_grupo] = {'politicas': [], 'usuarios': []}
        print(f"Grupo '{nombre_grupo}' creado.")

def listar_usuarios(servicio_iam):
    return list(servicio_iam.usuarios.keys())


def listar_grupos(servicio_iam):
    return list(servicio_iam.grupos.keys())


def añadir_usuario_a_grupo(servicio_iam, nombre_usuario, nombre_grupo):
    if nombre_usuario in servicio_iam.usuarios and nombre_grupo in servicio_iam.grupos:
        servicio_iam.grupos[nombre_grupo]['usuarios'].append(nombre_usuario)
        print(f"Usuario '{nombre_usuario}' añadido al grupo '{nombre_grupo}'.")


def asignar_politica_a_usuario(servicio_iam, nombre_usuario, politica):
    if nombre_usuario in servicio_iam.usuarios:
        servicio_iam.usuarios[nombre_usuario]['politicas'].append(politica)
        print(f"Política '{politica.nombre}' asignada al usuario '{nombre_usuario}'.")


def asignar_politica_a_grupo(servicio_iam, nombre_grupo, politica):
    if nombre_grupo in servicio_iam.grupos:
        servicio_iam.grupos[nombre_grupo]['politicas'].append(politica)
        print(f"Política '{politica.nombre}' asignada al grupo '{nombre_grupo}'.")


class Politica:
    def __init__(self, nombre, permisos):
        self.nombre = nombre
        self.permisos = permisos


def habilitar_mfa_para_usuario(servicio_iam, nombre_usuario):
    if nombre_usuario in servicio_iam.usuarios:
        servicio_iam.usuarios[nombre_usuario]['mfa_habilitado'] = True
        print(f"MFA habilitado para el usuario '{nombre_usuario}'.")


def configurar_mfa(nombre_usuario):
    codigo = random.randint(100000, 999999)
    print(f"Configuración de MFA para el usuario '{nombre_usuario}'. Código de verificación: {codigo}")


def establecer_politica_de_contraseña(longitud_minima, requiere_simbolos, requiere_numeros):
    politica = {
        "longitud_minima": longitud_minima,
        "requiere_simbolos": requiere_simbolos,
        "requiere_numeros": requiere_numeros
    }
    print("Política de contraseña establecida:", politica)


def asignar_politica_json_a_usuario(servicio_iam, nombre_usuario, politica_json):
    if nombre_usuario in servicio_iam.usuarios:
        servicio_iam.usuarios[nombre_usuario]['politicas'].append(politica_json)
        print(f"Política JSON asignada al usuario '{nombre_usuario}'.")


def generar_credenciales_temporales():
    clave_acceso = str(uuid.uuid4())
    clave_secreta = str(uuid.uuid4())
    token_sesion = str(uuid.uuid4())
    print(
        f"Credenciales temporales generadas:\nClave de Acceso: {clave_acceso}\nClave Secreta: {clave_secreta}\nToken de Sesión: {token_sesion}")


def generar_informe_credenciales(servicio_iam):
    informe = {}
    for usuario in servicio_iam.usuarios:
        informe[usuario] = {
            "politicas": servicio_iam.usuarios[usuario]['politicas'],
            "mfa_habilitado": servicio_iam.usuarios[usuario]['mfa_habilitado']
        }
    print("Informe de Credenciales:", informe)


# Inicialización de servicios y consola
servicio_iam = ServicioIAM()
consola_iam = ConsolaIAM()

# Creación de usuarios y grupos
consola_iam.crear_usuario(servicio_iam, "alice")
consola_iam.crear_grupo(servicio_iam, "grupo-admin")

# Listar usuarios y grupos
print("Usuarios:", listar_usuarios(servicio_iam))
print("Grupos:", listar_grupos(servicio_iam))

# Adición de usuarios a grupos y asignación de políticas
añadir_usuario_a_grupo(servicio_iam, "alice", "grupo-admin")

politica_admin = Politica("PoliticaAdmin", ["s3:ListBucket", "ec2:StartInstances"])
politica_grupo_admin = Politica("PoliticaGrupoAdmin", ["s3:*", "ec2:*"])
politica_solo_lectura = Politica("PoliticaSoloLectura", ["s3:GetObject"])
politica_escritura = Politica("PoliticaEscritura", ["s3:PutObject"])

servicio_iam.politicas["PoliticaAdmin"] = politica_admin
servicio_iam.politicas["PoliticaGrupoAdmin"] = politica_grupo_admin
servicio_iam.politicas["PoliticaSoloLectura"] = politica_solo_lectura
servicio_iam.politicas["PoliticaEscritura"] = politica_escritura

asignar_politica_a_usuario(servicio_iam, "alice", politica_admin)
asignar_politica_a_grupo(servicio_iam, "grupo-admin", politica_grupo_admin)

# Habilitar MFA
habilitar_mfa_para_usuario(servicio_iam, "alice")
configurar_mfa("alice")

# Establecer políticas de contraseñas
establecer_politica_de_contraseña(8, True, True)

# Asignación de políticas basadas en identidades
asignar_politica_a_usuario(servicio_iam, "alice", politica_solo_lectura)
asignar_politica_a_grupo(servicio_iam, "grupo-admin", politica_escritura)

# Ejemplo de política IAM y asignación
politica_ejemplo = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": "s3:ListBucket",
            "Resource": "arn:aws:s3:::example_bucket"
        }
    ]
}
asignar_politica_json_a_usuario(servicio_iam, "alice", politica_ejemplo)

# Generación de credenciales temporales
generar_credenciales_temporales()

# Revisión de informes de credenciales
generar_informe_credenciales(servicio_iam)




#Pregunta 1:
#Gestión avanzada de políticas y permisos
#Tarea: Implementa una función para validar si un usuario tiene permisos específicos para realizar
#una acción en un recurso determinado. La función debe considerar las políticas asignadas
#directamente al usuario y aquellas asignadas a los grupos a los que pertenece el usuario.

def tiene_permiso(servicio_iam, nombre_usuario, accion, recurso):
    # Verificar si el usuario existe
    if nombre_usuario not in servicio_iam.usuarios:
        print("Usuario no encontrado")
        return False

    # Obtener políticas del usuario
    politicas_usuario = servicio_iam.usuarios[nombre_usuario]['politicas']

    # Obtener políticas de los grupos a los que pertenece el usuario
    for nombre_grupo, datos_grupo in servicio_iam.grupos.items():
        if nombre_usuario in datos_grupo['usuarios']:
            politicas_usuario.extend(datos_grupo['politicas'])

    # Verificar si alguna política permite la acción en el recurso
    for politica in politicas_usuario:
        if isinstance(politica, dict):  # Para políticas JSON
            for statement in politica['Statement']:
                if statement['Effect'] == "Allow" and accion in statement['Action'] and recurso in statement['Resource']:
                    return True
        elif isinstance(politica, Politica):  # Para políticas de la clase Politica
            if accion in politica.permisos:
                return True

    return False

# Ejemplo de uso
print(tiene_permiso(servicio_iam, "alice", "s3:ListBucket", "arn:aws:s3:::example_bucket"))


#Ejercicio 2: Simulación completa de MFA
#Tarea: Implementa una simulación completa de MFA que incluya la generación de un código de
#verificación y la verificación de ese código al momento de inicio de sesión del usuario.


import random

def iniciar_sesion(servicio_iam, nombre_usuario, codigo_verificacion):
    if nombre_usuario in servicio_iam.usuarios:
        usuario = servicio_iam.usuarios[nombre_usuario]
        if usuario.get('mfa_habilitado', False):
            if 'codigo_mfa' in usuario and codigo_verificacion == usuario['codigo_mfa']:
                print(f"Usuario '{nombre_usuario}' ha iniciado sesión exitosamente.")
            else:
                print("Código de verificación incorrecto.")
        else:
            print(f"Usuario '{nombre_usuario}' ha iniciado sesión sin MFA.")
    else:
        print(f"Usuario '{nombre_usuario}' no existe.")

def generar_codigo_mfa(servicio_iam, nombre_usuario):
    if nombre_usuario in servicio_iam.usuarios:
        codigo = random.randint(100000, 999999)
        servicio_iam.usuarios[nombre_usuario]['codigo_mfa'] = codigo
        print(f"Código MFA generado para el usuario '{nombre_usuario}': {codigo}")
    else:
        print(f"Usuario '{nombre_usuario}' no existe.")


generar_codigo_mfa(servicio_iam, "alice")
# Utiliza el código MFA generado para la autenticación
codigo_mfa = servicio_iam.usuarios['alice']['codigo_mfa']
iniciar_sesion(servicio_iam, "alice", 123456)  # Código incorrecto
iniciar_sesion(servicio_iam, "alice", codigo_mfa)  # Código correcto


#Ejercicio 3: Implementación de políticas basadas en condiciones
#Tarea: Extiende la funcionalidad de las políticas IAM para incluir condiciones. Implementa una
#política que permita acciones solo durante un horario específico del día y verifica que los permisos
#se apliquen correctamente.

import time


class PoliticaCondicional(Politica):
    def __init__(self, nombre, permisos, condiciones):
        super().__init__(nombre, permisos)
        self.condiciones = condiciones


def verificar_condiciones(politica, condiciones_actuales):
    for clave, valor in politica.condiciones.items():
        if clave in condiciones_actuales:
            if isinstance(valor, str) and "-" in valor:  # Verificar si es un rango de horas
                hora_inicio, hora_fin = map(int, valor.split('-'))
                hora_actual = int(time.strftime("%H", time.localtime()))
                #hora_actual = int(condiciones_actuales[clave]) #<- sin el time
                print(hora_fin)
                if not (hora_inicio <= hora_actual < hora_fin):
                    return False
            elif condiciones_actuales[clave] != valor:
                return False
    return True


def tiene_permiso_con_condiciones(servicio_iam, nombre_usuario, accion, recurso, condiciones_actuales):
    if nombre_usuario not in servicio_iam.usuarios:
        return False

    politicas_usuario = servicio_iam.usuarios[nombre_usuario]['politicas']
    for nombre_grupo in servicio_iam.grupos:
        if nombre_usuario in servicio_iam.grupos[nombre_grupo]['usuarios']:
            politicas_usuario.extend(servicio_iam.grupos[nombre_grupo]['politicas'])

    for politica in politicas_usuario:
        if isinstance(politica, PoliticaCondicional):
            if accion in politica.permisos and verificar_condiciones(politica, condiciones_actuales):
                return True
        elif isinstance(politica, dict):
            for statement in politica['Statement']:
                if statement['Effect'] == "Allow" and accion in statement['Action'] and recurso in statement[
                    'Resource']:
                    if 'Condition' in statement and not verificar_condiciones(statement['Condition'],
                                                                              condiciones_actuales):
                        continue
                    return True
        elif isinstance(politica, Politica):
            if accion in politica.permisos:
                return True

    return False


# Ejemplo de uso
politica_horario = PoliticaCondicional("PoliticaHorario", ["s3:ListBucket"], {"hora": "20-24"})
servicio_iam.usuarios["alice"]['politicas'].append(politica_horario)

print(tiene_permiso_con_condiciones(servicio_iam, "alice", "s3:ListBucket", "arn:aws:s3:::example_bucket",
                                    {"hora": "10"}))  # True
print(tiene_permiso_con_condiciones(servicio_iam, "alice", "s3:ListBucket", "arn:aws:s3:::example_bucket",
                                    {"hora": "18"}))  # False





#Ejercicio 4: Gestión de roles y asignación de credenciales temporales
#Tarea: Implementa un sistema de roles que permita a los usuarios asumir roles y recibir credenciales
#temporales con permisos específicos. Implementa la lógica para verificar los permisos basados en los
#roles asumidos.

"""import uuid
import datetime


# ServicioIAM para gestionar usuarios, roles y credenciales temporales
class ServicioIAM:
    def __init__(self):
        self.usuarios = {}
        self.grupos = {}
        self.politicas = {}
        self.roles = {}
        self.credenciales_temporales = {}

    def crear_rol(self, nombre_rol, politicas):
        self.roles[nombre_rol] = [nombre_rol, politicas]
        print(f"Rol '{nombre_rol}' creado.")

    def asumir_rol(self, nombre_usuario, nombre_rol):
        if nombre_usuario in self.usuarios and nombre_rol in self.roles:
            rol = self.roles[nombre_rol]
            credenciales = self.generar_credenciales_temporales()
            expiracion = datetime.datetime.now() + datetime.timedelta(hours=1)
            print(expiracion)
            self.credenciales_temporales[credenciales['clave_acceso']] = {
                'usuario': nombre_usuario,
                'rol': nombre_rol,
                'expiracion': expiracion,
                'politicas': rol[1]
            }
            return credenciales
        else:
            print(f"Error: Usuario '{nombre_usuario}' o rol '{nombre_rol}' no existe.")
            return None

    def generar_credenciales_temporales(self):
        return {
            'clave_acceso': str(uuid.uuid4()),
            'clave_secreta': str(uuid.uuid4()),
            'token_sesion': str(uuid.uuid4())
        }

    def verificar_permiso(self, clave_acceso, accion):
        if clave_acceso in self.credenciales_temporales:
            info_cred = self.credenciales_temporales[clave_acceso]
            if datetime.datetime.now() > info_cred['expiracion']:
                print(f"Error: Las credenciales para la clave de acceso '{clave_acceso}' han expirado.")
                return False
            for politica in info_cred['politicas']:
                if accion in politica[1]:
                    return True
        print(f"Permiso denegado para la acción '{accion}' con clave de acceso '{clave_acceso}'.")
        return False

# ConsolaIAM para gestionar usuarios y roles
class ConsolaIAM:
    def crear_usuario(self, servicio_iam, nombre_usuario):
        servicio_iam.usuarios[nombre_usuario] = {'politicas': [], 'mfa_habilitado': False}
        print(f"Usuario '{nombre_usuario}' creado.")

    def crear_rol(self, servicio_iam, nombre_rol, politicas):
        servicio_iam.crear_rol(nombre_rol, politicas)

    def asumir_rol(self, servicio_iam, nombre_usuario, nombre_rol):
        credenciales = servicio_iam.asumir_rol(nombre_usuario, nombre_rol)
        if credenciales:
            print(f"Usuario '{nombre_usuario}' asumió el rol '{nombre_rol}'. Credenciales temporales: {credenciales}")
            return credenciales

# Inicialización y pruebas
servicio_iam = ServicioIAM()
consola_iam = ConsolaIAM()

# Crear usuario, roles y políticas
consola_iam.crear_usuario(servicio_iam, "alice")
politica_admin = ["AdminPolicy", ["s3:ListBucket", "ec2:StartInstances"]]
politica_desarrollador = ["DeveloperPolicy", ["s3:PutObject", "ec2:StopInstances"]]

servicio_iam.politicas["AdminPolicy"] = politica_admin
servicio_iam.politicas["DeveloperPolicy"] = politica_desarrollador

consola_iam.crear_rol(servicio_iam, "RolAdmin", [politica_admin])
consola_iam.crear_rol(servicio_iam, "RolDesarrollador", [politica_desarrollador])

# Usuario asume rol y verifica permisos
credenciales = consola_iam.asumir_rol(servicio_iam, "alice", "RolAdmin")
if credenciales:
    clave_acceso = credenciales['clave_acceso']
    print("Verificando permisos para 's3:ListBucket':")
    servicio_iam.verificar_permiso(clave_acceso, "s3:ListBucket")
    print("Verificando permisos para 'ec2:StopInstances':")
    servicio_iam.verificar_permiso(clave_acceso, "ec2:StopInstances")"""


class Rol:
    def __init__(self, nombre, politicas):
        self.nombre = nombre
        self.politicas = politicas

def asumir_rol(servicio_iam, nombre_usuario, nombre_rol):
    if nombre_rol in servicio_iam.roles:
        servicio_iam.usuarios[nombre_usuario]['rol_actual'] = nombre_rol
        print(f"Usuario '{nombre_usuario}' ha asumido el rol '{nombre_rol}'.")
    else:
        print(f"Rol '{nombre_rol}' no existe.")

def tiene_permiso_con_rol(servicio_iam, nombre_usuario, accion, recurso):
    if nombre_usuario not in servicio_iam.usuarios:
        return False

    politicas_usuario = servicio_iam.usuarios[nombre_usuario]['politicas']
    rol_actual = servicio_iam.usuarios[nombre_usuario].get('rol_actual')

    if rol_actual:
        politicas_usuario.extend(servicio_iam.roles[rol_actual].politicas)

    for politica in politicas_usuario:
        if isinstance(politica, dict):
            for statement in politica['Statement']:
                if statement['Effect'] == "Allow" and accion in statement['Action'] and recurso in statement[
                    'Resource']:
                    return True
        elif isinstance(politica, Politica):
            if accion in politica.permisos:
                return True
    return False

def generar_credenciales_temporales_con_rol(servicio_iam, nombre_usuario):
    if 'rol_actual' in servicio_iam.usuarios[nombre_usuario]:
        generar_credenciales_temporales()
    else:
        print(f"Usuario '{nombre_usuario}' no ha asumido ningún rol.")

# Ejemplo de uso
rol_admin = Rol("RolAdmin", [Politica("PoliticaAdmin", ["s3:ListBucket", "ec2:StartInstances"])])
servicio_iam.roles["RolAdmin"] = rol_admin
asumir_rol(servicio_iam, "alice", "RolAdmin")
print(tiene_permiso_con_rol(servicio_iam, "alice", "s3:ListBucket", "arn:aws:s3:::example_bucket"))  # True
generar_credenciales_temporales_con_rol(servicio_iam, "alice")




#Ejercicio 5: Informe detallado de credenciales y seguridad
#Tarea: Implementa una función que genere un informe detallado de credenciales y seguridad para
#todos los usuarios, incluyendo información sobre políticas, estado de MFA, y roles asumidos. El
#informe debe ser exportado en formato JSON.

import json

def generar_informe_detallado(servicio_iam):
    informe = {}
    for usuario in servicio_iam.usuarios:
        informe[usuario] = {
            "politicas": [p.nombre if isinstance(p, Politica) else p for p in servicio_iam.usuarios[usuario]['politicas']],
            "mfa_habilitado": servicio_iam.usuarios[usuario]['mfa_habilitado'],
            "rol_actual": servicio_iam.usuarios[usuario].get('rol_actual')
        }
    with open('informe_credenciales.json', 'w') as archivo:
        json.dump(informe, archivo, indent=4)
    print("Informe detallado generado en 'informe_credenciales.json'.")

# Ejemplo de uso
generar_informe_detallado(servicio_iam)









#S3
# 1.1 Almacenamiento en bloque (Block Storage)
class BlockStorage:
    """
    Simula un almacenamiento en bloque con archivos binarios en Python.
    """

    def __init__(self, size):
        """
        Inicializa el almacenamiento con un tamaño dado.

        Args:
        - size (int): Tamaño del almacenamiento en bytes.
        """
        self.storage = bytearray(size)

    def write(self, data, offset):
        """
        Escribe datos en el almacenamiento en una posición dada.

        Args:
        - data (bytes): Datos a escribir.
        - offset (int): Posición de inicio para escribir los datos.
        """
        self.storage[offset:offset + len(data)] = data

    def read(self, offset, size):
        """
        Lee datos desde el almacenamiento en una posición dada.

        Args:
        - offset (int): Posición de inicio para leer los datos.
        - size (int): Cantidad de bytes a leer.

        Returns:
        - bytes: Datos leídos desde el almacenamiento.
        """
        return self.storage[offset:offset + size]


# Ejemplo de uso
block_storage = BlockStorage(1024)
block_storage.write(b"Hello", 0)
print(block_storage.read(0, 5))  # Output: b'Hello'

# 1.2 Almacenamiento de Archivos (File Storage)
import os


class FileStorage:
    """
    Simula un sistema de archivos básico con directorios y archivos.
    """

    def __init__(self, root_dir):
        """
        Inicializa el sistema de archivos en el directorio raíz especificado.

        Args:
        - root_dir (str): Directorio raíz para el almacenamiento de archivos.
        """
        self.root_dir = root_dir
        os.makedirs(root_dir, exist_ok=True)

    def write(self, path, data):
        """
        Escribe datos en un archivo dentro del sistema de archivos.

        Args:
        - path (str): Ruta del archivo dentro del sistema de archivos.
        - data (str): Datos a escribir en el archivo.
        """
        with open(os.path.join(self.root_dir, path), 'w') as f:
            f.write(data)

    def read(self, path):
        """
        Lee datos desde un archivo dentro del sistema de archivos.

        Args:
        - path (str): Ruta del archivo dentro del sistema de archivos.

        Returns:
        - str: Datos leídos desde el archivo.
        """
        with open(os.path.join(self.root_dir, path), 'r') as f:
            return f.read()


# Ejemplo de uso
file_storage = FileStorage('/tmp/filestorage')
file_storage.write('example.txt', 'Hello, File Storage!')
print(file_storage.read('example.txt'))  # Output: 'Hello, File Storage!'


# 1.3 Almacenamiento de Objetos (Object Storage)
class ObjectStorage:
    """
    Simula el almacenamiento de objetos usando un diccionario.
    """

    def __init__(self):
        """
        Inicializa el almacenamiento de objetos vacío.
        """
        self.storage = {}

    def put_object(self, key, data):
        """
        Almacena un objeto en el almacenamiento bajo una clave dada.

        Args:
        - key (str): Clave del objeto.
        - data (object): Objeto a almacenar.
        """
        self.storage[key] = data

    def get_object(self, key):
        """
        Obtiene un objeto desde el almacenamiento dado su clave.

        Args:
        - key (str): Clave del objeto.

        Returns:
        - object: Objeto almacenado bajo la clave dada, o None si no existe.
        """
        return self.storage.get(key, None)


# Ejemplo de uso
object_storage = ObjectStorage()
object_storage.put_object('file1.txt', 'Hello, Object Storage!')
print(object_storage.get_object('file1.txt'))  # Output: 'Hello, Object Storage!'


# 2.1 Introducción a Amazon S3 - Buckets y Objetos
class S3Bucket:
    """
    Simula la creación y gestión de buckets y objetos en Amazon S3.
    """

    def __init__(self):
        """
        Inicializa un sistema vacío de buckets y objetos.
        """
        self.buckets = {}

    def create_bucket(self, name):
        """
        Crea un nuevo bucket en el sistema.

        Args:
        - name (str): Nombre del nuevo bucket.
        """
        self.buckets[name] = {}

    def put_object(self, bucket, key, data):
        """
        Almacena un objeto en un bucket específico.

        Args:
        - bucket (str): Nombre del bucket donde almacenar el objeto.
        - key (str): Clave del objeto.
        - data (object): Objeto a almacenar.
        """
        if bucket in self.buckets:
            self.buckets[bucket][key] = data

    def get_object(self, bucket, key):
        """
        Obtiene un objeto desde un bucket específico.

        Args:
        - bucket (str): Nombre del bucket donde buscar el objeto.
        - key (str): Clave del objeto.

        Returns:
        - object: Objeto almacenado bajo la clave dada en el bucket, o None si no existe.
        """
        return self.buckets.get(bucket, {}).get(key, None)


# Ejemplo de uso
s3 = S3Bucket()
s3.create_bucket('mybucket')
s3.put_object('mybucket', 'file1.txt', 'Hello, S3 Bucket!')
print(s3.get_object('mybucket', 'file1.txt'))  # Output: 'Hello, S3 Bucket!'


# 3.1 Gestión de objetos en un Bucket - Permisos de acceso
class S3BucketWithPermissions(S3Bucket):
    """
    Simula la gestión de permisos de acceso a objetos en buckets de S3.
    """

    def __init__(self):
        """
        Inicializa un sistema de buckets con gestión de permisos.
        """
        super().__init__()
        self.permissions = {}

    def set_permission(self, bucket, key, permission):
        """
        Establece los permisos de acceso para un objeto en un bucket dado.

        Args:
        - bucket (str): Nombre del bucket.
        - key (str): Clave del objeto.
        - permission (str): Permiso de acceso ('read', 'write', etc.).
        """
        if bucket not in self.permissions:
            self.permissions[bucket] = {}
        self.permissions[bucket][key] = permission

    def check_permission(self, bucket, key, action):
        """
        Verifica si se tiene permiso para realizar una acción sobre un objeto en un bucket.

        Args:
        - bucket (str): Nombre del bucket.
        - key (str): Clave del objeto.
        - action (str): Acción a verificar ('read', 'write', etc.).

        Returns:
        - bool: True si se tiene permiso para la acción, False de lo contrario.
        """
        return self.permissions.get(bucket, {}).get(key) == action


# Ejemplo de uso
s3p = S3BucketWithPermissions()
s3p.create_bucket('mybucket')
s3p.put_object('mybucket', 'file1.txt', 'Hello, S3 with Permissions!')
s3p.set_permission('mybucket', 'file1.txt', 'read')
print(s3p.check_permission('mybucket', 'file1.txt', 'read'))  # Output: True


# 4.1 Versionado - Implementación de Versionado
class S3BucketWithVersioning(S3Bucket):
    """
    Simula el versionado de objetos en buckets de S3.
    """

    def __init__(self):
        """
        Inicializa un sistema de buckets con versionado de objetos.
        """
        super().__init__()
        self.versions = {}

    def put_object(self, bucket, key, data):
        """
        Almacena un objeto con versionado en un bucket específico.

        Args:
        - bucket (str): Nombre del bucket donde almacenar el objeto.
        - key (str): Clave del objeto.
        - data (object): Objeto a almacenar.
        """
        if bucket not in self.versions:
            self.versions[bucket] = {}
        if key not in self.versions[bucket]:
            self.versions[bucket][key] = []
        self.versions[bucket][key].append(data)

    def get_object(self, bucket, key, version=None):
        """
        Obtiene un objeto desde un bucket específico y versión.

        Args:
        - bucket (str): Nombre del bucket donde buscar el objeto.
        - key (str): Clave del objeto.
        - version (int): Número de versión del objeto (opcional, último por defecto).

        Returns:
        - object: Objeto almacenado bajo la clave y versión dadas en el bucket.
        """
        if version is None:
            return self.versions.get(bucket, {}).get(key, [])[-1]
        return self.versions.get(bucket, {}).get(key, [])[version]


# Ejemplo de uso
s3v = S3BucketWithVersioning()
s3v.create_bucket('mybucket')
s3v.put_object('mybucket', 'file1.txt', 'Version 1')
s3v.put_object('mybucket', 'file1.txt', 'Version 2')
print(s3v.get_object('mybucket', 'file1.txt'))  # Output: 'Version 2'
print(s3v.get_object('mybucket', 'file1.txt', 0))  # Output: 'Version 1'


# 5.1 Replicación - Replicación en Diferentes Regiones
class S3BucketWithReplication(S3Bucket):
    """
    Simula la replicación de objetos entre buckets de S3.
    """

    def replicate(self, source_bucket, target_bucket):
        """
        Replica objetos desde un bucket de origen a un bucket de destino.

        Args:
        - source_bucket (str): Nombre del bucket de origen.
        - target_bucket (str): Nombre del bucket de destino.
        """
        if source_bucket in self.buckets and target_bucket in self.buckets:
            self.buckets[target_bucket] = self.buckets[source_bucket].copy()


# Ejemplo de uso
s3r = S3BucketWithReplication()
s3r.create_bucket('source_bucket')
s3r.create_bucket('target_bucket')
s3r.put_object('source_bucket', 'file1.txt', 'Data to Replicate')
s3r.replicate('source_bucket', 'target_bucket')
print(s3r.get_object('target_bucket', 'file1.txt'))  # Output: 'Data to Replicate'

# 6.1 Encriptación - Encriptación de Objetos
from cryptography.fernet import Fernet


class S3BucketWithEncryption(S3Bucket):
    """
    Simula la encriptación de objetos almacenados en buckets de S3.
    """

    def __init__(self, key):
        """
        Inicializa un sistema de buckets con encriptación de objetos.

        Args:
        - key (bytes): Clave de encriptación para los datos.
        """
        super().__init__()
        self.cipher = Fernet(key)

    def put_object(self, bucket, key, data):
        """
        Almacena un objeto encriptado en un bucket específico.

        Args:
        - bucket (str): Nombre del bucket donde almacenar el objeto.
        - key (str): Clave del objeto.
        - data (str): Datos a encriptar y almacenar.
        """
        encrypted_data = self.cipher.encrypt(data.encode())
        super().put_object(bucket, key, encrypted_data)

    def get_object(self, bucket, key):
        """
        Obtiene y desencripta un objeto desde un bucket específico.

        Args:
        - bucket (str): Nombre del bucket donde buscar el objeto.
        - key (str): Clave del objeto.

        Returns:
        - str: Datos desencriptados del objeto almacenado.
        """
        encrypted_data = super().get_object(bucket, key)
        if encrypted_data:
            return self.cipher.decrypt(encrypted_data).decode()
        return None


# Ejemplo de uso
key = Fernet.generate_key()
s3e = S3BucketWithEncryption(key)
s3e.create_bucket('mybucket')
s3e.put_object('mybucket', 'file1.txt', 'Encrypted Data')
print(s3e.get_object('mybucket', 'file1.txt'))  # Output: 'Encrypted Data'





#Ejercicio 1: Simulación completa de almacenamiento en Bloque con gestión de espacio
#Objetivo: Implementar una clase AdvancedBlockStorage que gestione bloques de almacenamiento
#con funciones para asignar y liberar bloques de forma dinámica, incluyendo fragmentación y desfragmentación.
#Requisitos:
#Implementar una clase AdvancedBlockStorage que permita:
#• Crear un espacio de almacenamiento dividido en bloques de tamaño fijo.
#• Asignar y liberar bloques.
#• Manejar la fragmentación y ofrecer una función para desfragmentar el almacenamiento.
#Incluir métodos para:
#• allocate(size) que asigne bloques contiguos suficientes para almacenar el tamaño especificado.
#• free(block_id) que libere los bloques asignados.
#• defragment() que reorganice los bloques para reducir la fragmentación
class AdvancedBlockStorage:
    def __init__(self, total_size, block_size):
        self.total_size = total_size
        self.block_size = block_size
        self.num_blocks = total_size // block_size
        self.storage = bytearray(total_size)
        self.free_blocks = set(range(self.num_blocks))
        self.allocated_blocks = {}
        print(f"Initialized storage with {self.num_blocks} blocks of size {self.block_size} bytes each.")

    def allocate(self, size):
        try:
            num_blocks_needed = (size + self.block_size - 1) // self.block_size
            if num_blocks_needed > len(self.free_blocks):
                raise ValueError("No hay espacio en el almacenamiento")

            allocated_block_indices = []
            contiguous_free_blocks = sorted(self.free_blocks)

            # Find contiguous blocks
            for i in range(len(contiguous_free_blocks) - num_blocks_needed + 1):
                if contiguous_free_blocks[i + num_blocks_needed - 1] - contiguous_free_blocks[i] == num_blocks_needed - 1:
                    allocated_block_indices = contiguous_free_blocks[i:i + num_blocks_needed]
                    break

            if not allocated_block_indices:
                raise ValueError("No contiguous space available")

            for block_index in allocated_block_indices:
                self.free_blocks.remove(block_index)

            block_id = id(allocated_block_indices)
            self.allocated_blocks[block_id] = allocated_block_indices

            print(f"Allocated {num_blocks_needed} blocks: {allocated_block_indices}")
            return block_id
        except Exception as e:
            print(f"¡Error! Ocurrió un error al intentar agregar el contenido: {e}")

    def free(self, block_id):
        if block_id not in self.allocated_blocks:
            raise ValueError("Invalid block ID")

        for block_index in self.allocated_blocks[block_id]:
            self.free_blocks.add(block_index)

        print(f"Freed blocks: {self.allocated_blocks[block_id]}")
        del self.allocated_blocks[block_id]

    def defragment(self):
        all_blocks = sorted(self.free_blocks) + [block for blocks in self.allocated_blocks.values() for block in blocks]
        new_free_blocks = set()
        new_allocated_blocks = {}
        new_index = 0

        for block_id, blocks in sorted(self.allocated_blocks.items(), key=lambda x: x[1][0]):
            new_blocks = []
            for _ in blocks:
                new_blocks.append(new_index)
                new_index += 1
            new_allocated_blocks[block_id] = new_blocks

        for i in range(new_index, self.num_blocks):
            new_free_blocks.add(i)

        self.free_blocks = new_free_blocks
        self.allocated_blocks = new_allocated_blocks

        print("Defragmented storage.")

    def print_blocks(self):
        print(f"Free blocks: {sorted(self.free_blocks)}")
        print(f"Allocated blocks: {self.allocated_blocks}")

# Ejemplo de uso
abs = AdvancedBlockStorage(1024, 64)
abs.print_blocks()

block_id1 = abs.allocate(128)  # Debe asignar 2 bloques
abs.print_blocks()

block_id2 = abs.allocate(192)  # Debe asignar 3 bloques
abs.print_blocks()

abs.free(block_id1)  # Libera 2 bloques
abs.print_blocks()

block_id3 = abs.allocate(1024)  # Debe asignar 8 bloques
abs.print_blocks()

abs.defragment()  # Desfragmenta el almacenamiento
abs.print_blocks()






#Ejercicio 2: Sistema de Archivos con gestión de permisos y versionado
#Objetivo: Crear una clase VersionedFileStorage que extienda FileStorage para incluir permisos de acceso y versionado de archivos.
#Requisitos:
#Implementar una clase VersionedFileStorage que:
#• Gestione archivos con permisos de lectura/escritura.
#• Mantenga versiones de cada archivo.
#Incluir métodos para:
#• set_permission(path, permission) para establecer permisos (lectura/escritura).
#• write_versioned(path, data) para escribir datos y mantener versiones.
#• read_version(path, version) para leer una versión específica del archivo.

import os
from collections import defaultdict

class FileStorage:
    def __init__(self, root_dir):
        self.root_dir = root_dir
        os.makedirs(root_dir, exist_ok=True)

    def write(self, path, data):
        with open(os.path.join(self.root_dir, path), 'w') as f:
            f.write(data)

    def read(self, path):
        with open(os.path.join(self.root_dir, path), 'r') as f:
            return f.read()

class VersionedFileStorage(FileStorage):
    def __init__(self, root_dir):
        super().__init__(root_dir)
        self.permissions = {}
        self.versions = defaultdict(list)

    def set_permission(self, path, permission):
        if permission not in ["read", "write"]:
            raise ValueError("Invalid permission. Use 'read' or 'write'.")
        self.permissions[path] = permission
        print(f"Set permission for {path} to {permission}.")

    def check_permission(self, path, action):
        if path not in self.permissions:
            return False
        return self.permissions[path] == action

    def write_versioned(self, path, data):
        try:
            if not self.check_permission(path, "write"):
                raise PermissionError(f"Write permission denied for {path}.")

            version_path = f"{path}_v{len(self.versions[path])}"
            super().write(version_path, data)
            self.versions[path].append(version_path)
            print(f"Wrote version {len(self.versions[path])-1} for {path}.")
        except Exception as e:
            print(f"¡Error!: {e}")

    def read_version(self, path, version):
        try:
            if not self.check_permission(path, "read"):
                raise PermissionError(f"Read permission denied for {path}.")

            if version >= len(self.versions[path]) or version < 0:
                raise IndexError(f"Version {version} does not exist for {path}.")

            version_path = self.versions[path][version]
            data = super().read(version_path)
            print(f"Read version {version} for {path}.")
            return data
        except Exception as e:
            print(f"¡Error!: {e}")


    def print_versions(self, path):
        if path in self.versions:
            print(f"Versions for {path}: {self.versions[path]}")
        else:
            print(f"No versions found for {path}.")

# Ejemplo de uso
vfs = VersionedFileStorage('./tmp/versionedfilestorage')

# Set permissions
vfs.set_permission('example.txt', 'write')

# Write versions
vfs.write_versioned('example.txt', 'Hello, version 1')
vfs.write_versioned('example.txt', 'Hello, version 2')
vfs.write_versioned('example.txt', 'Hello, version 3')

# Print versions
vfs.print_versions('example.txt')
vfs.set_permission('example.txt', 'read')
# Read versions
print(vfs.read_version('example.txt', 0))  # Output: 'Hello, version 1'
print(vfs.read_version('example.txt', 1))  # Output: 'Hello, version 2'
print(vfs.read_version('example.txt', 2))  # Output: 'Hello, version 3'








#Ejercicio 3: Sistema de almacenamiento de Objetos con encriptación y replicación
#Objetivo: Crear una clase EncryptedReplicatedObjectStorage que combine encriptación y replicación de objetos.
#Requisitos:
#Implementar una clase EncryptedReplicatedObjectStorage que:
#• Encripte objetos antes de almacenarlos.
#• Replicación automática de objetos en múltiples ubicaciones.
#Incluir métodos para:
#• put_object(bucket, key, data) para almacenar y encriptar datos.
#• get_object(bucket, key) para recuperar y desencriptar datos.
#• replicate(source_bucket, target_bucket) para replicar objetos.

from cryptography.fernet import Fernet


class AlmacenamientoObjetos:
    def __init__(self):
        self.almacenamiento = {}

    def guardar_objeto(self, cubeta, clave, datos):
        if cubeta not in self.almacenamiento:
            self.almacenamiento[cubeta] = {}
        self.almacenamiento[cubeta][clave] = datos

    def obtener_objeto(self, cubeta, clave):
        return self.almacenamiento.get(cubeta, {}).get(clave, None)


class AlmacenamientoObjetoCifradoReplicado(AlmacenamientoObjetos):
    def __init__(self, llave):
        super().__init__()
        self.cifrado = Fernet(llave)

    def guardar_objeto(self, cubeta, clave, datos):
        # Cifrar los datos antes de almacenarlos
        datos_cifrados = self.cifrado.encrypt(datos.encode())
        super().guardar_objeto(cubeta, clave, datos_cifrados)
        print(f"Objeto cifrado almacenado en la cubeta '{cubeta}' con clave '{clave}'.")

    def obtener_objeto(self, cubeta, clave):
        # Obtener los datos cifrados
        datos_cifrados = super().obtener_objeto(cubeta, clave)
        if datos_cifrados is None:
            print(f"Objeto con clave '{clave}' no encontrado en la cubeta '{cubeta}'.")
            return None
        # Descifrar los datos
        datos_descifrados = self.cifrado.decrypt(datos_cifrados).decode()
        print(f"Objeto descifrado recuperado de la cubeta '{cubeta}' con clave '{clave}'.")
        return datos_descifrados

    def replicar(self, cubeta_origen, cubeta_destino):
        if cubeta_origen not in self.almacenamiento:
            raise ValueError(f"La cubeta origen '{cubeta_origen}' no existe.")
        if cubeta_destino not in self.almacenamiento:
            self.almacenamiento[cubeta_destino] = {}

        # Replicar los datos de la cubeta origen a la cubeta destino
        self.almacenamiento[cubeta_destino] = self.almacenamiento[cubeta_origen].copy()
        print(f"Objetos replicados de la cubeta '{cubeta_origen}' a la cubeta '{cubeta_destino}'.")


# Generar una clave para encriptación
llave = Fernet.generate_key()

# Crear instancia de AlmacenamientoObjetoCifradoReplicado
almacenamiento_cifrado_replicado = AlmacenamientoObjetoCifradoReplicado(llave)

# Almacenar objetos cifrados
almacenamiento_cifrado_replicado.guardar_objeto('cubeta1', 'archivo1.txt', '¡Hola, este es un mensaje secreto!')
almacenamiento_cifrado_replicado.guardar_objeto('cubeta1', 'archivo2.txt', 'Otro mensaje secreto.')

# Recuperar y descifrar objetos
print(almacenamiento_cifrado_replicado.obtener_objeto('cubeta1', 'archivo1.txt'))  # Output: '¡Hola, este es un mensaje secreto!'
print(almacenamiento_cifrado_replicado.obtener_objeto('cubeta1', 'archivo2.txt'))  # Output: 'Otro mensaje secreto.'

# Replicar objetos entre cubetas
almacenamiento_cifrado_replicado.replicar('cubeta1', 'cubeta2')

# Verificar replicación
print(almacenamiento_cifrado_replicado.obtener_objeto('cubeta2', 'archivo1.txt'))  # Output: '¡Hola, este es un mensaje secreto!'
print(almacenamiento_cifrado_replicado.obtener_objeto('cubeta2', 'archivo2.txt'))  # Output: 'Otro mensaje secreto.'








#Ejercicio 4: Gestión de versiones y replicación de archivos
#Objetivo: Implementar un sistema de almacenamiento que gestione versiones de archivos y permita la replicación entre diferentes regiones simuladas.
#Requisitos:
#Implementar una clase VersionedReplicatedFileStorage que:
#• Gestione versiones de archivos.
#• Permita la replicación entre regiones simuladas.
#Incluir métodos para:
#• add_version(path, data) para añadir una nueva versión de un archivo.
#• get_version(path, version) para obtener una versión específica de un archivo.
#• replicate_region(region_from, region_to) para replicar todos los archivos de una región a otra.


import os
from collections import defaultdict


class FileStorage:
    def __init__(self, root_dir):
        self.root_dir = root_dir
        os.makedirs(root_dir, exist_ok=True)

    def write(self, path, data):
        with open(os.path.join(self.root_dir, path), 'w') as f:
            f.write(data)

    def read(self, path):
        with open(os.path.join(self.root_dir, path), 'r') as f:
            return f.read()


class VersionedReplicatedFileStorage:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.regiones = defaultdict(lambda: defaultdict(list))
        os.makedirs(base_dir, exist_ok=True)

    def _get_region_dir(self, region):
        return os.path.join(self.base_dir, region)

    def add_version(self, region, path, data):
        region_dir = self._get_region_dir(region)
        os.makedirs(region_dir, exist_ok=True)

        # Generar el nombre del archivo de versión
        version_number = len(self.regiones[region][path])
        version_path = f"{path}_v{version_number}"

        # Guardar la nueva versión del archivo
        full_path = os.path.join(region_dir, version_path)
        with open(full_path, 'w') as f:
            f.write(data)

        self.regiones[region][path].append(version_path)
        print(f"Agregada la versión {version_number} para '{path}' en la región '{region}'.")

    def get_version(self, region, path, version):
        if path not in self.regiones[region]:
            raise FileNotFoundError(f"El archivo '{path}' no existe en la región '{region}'.")

        if version >= len(self.regiones[region][path]) or version < 0:
            raise IndexError(f"La versión {version} no existe para '{path}' en la región '{region}'.")

        version_path = self.regiones[region][path][version]
        region_dir = self._get_region_dir(region)
        full_path = os.path.join(region_dir, version_path)

        with open(full_path, 'r') as f:
            data = f.read()

        print(f"Recuperada la versión {version} para '{path}' de la región '{region}'.")
        return data

    def replicate_region(self, region_from, region_to):
        if region_from not in self.regiones:
            raise ValueError(f"La región origen '{region_from}' no existe.")

        region_from_dir = self._get_region_dir(region_from)
        region_to_dir = self._get_region_dir(region_to)
        os.makedirs(region_to_dir, exist_ok=True)

        for path, versions in self.regiones[region_from].items():
            for version_path in versions:
                from_path = os.path.join(region_from_dir, version_path)
                to_path = os.path.join(region_to_dir, version_path)

                with open(from_path, 'r') as f:
                    data = f.read()

                with open(to_path, 'w') as f:
                    f.write(data)

        self.regiones[region_to] = self.regiones[region_from].copy()
        print(f"Replicados todos los archivos de la región '{region_from}' a la región '{region_to}'.")


# Ejemplo de uso
base_dir = './tmp/versionedreplicatedfilestorage'
vrs = VersionedReplicatedFileStorage(base_dir)

# Añadir versiones de archivos
vrs.add_version('region1', 'archivo.txt', 'Contenido de la versión 1')
vrs.add_version('region1', 'archivo.txt', 'Contenido de la versión 2')
vrs.add_version('region1', 'otro_archivo.txt', 'Contenido inicial')

# Recuperar versiones específicas de archivos
print(vrs.get_version('region1', 'archivo.txt', 0))  # Output: 'Contenido de la versión 1'
print(vrs.get_version('region1', 'archivo.txt', 1))  # Output: 'Contenido de la versión 2'

# Replicar archivos entre regiones
vrs.replicate_region('region1', 'region2')

# Verificar replicación
print(vrs.get_version('region2', 'archivo.txt', 0))  # Output: 'Contenido de la versión 1'
print(vrs.get_version('region2', 'archivo.txt', 1))  # Output: 'Contenido de la versión 2'
print(vrs.get_version('region2', 'otro_archivo.txt', 0))  # Output: 'Contenido inicial'









#Ejercicio 5: Sistema de almacenamiento de Objetos con soporte para políticas de acceso
#Objetivo: Crear una clase ObjectStorageWithPolicies que gestione objetos y aplique políticas de acceso basadas en roles.
#Requisitos:
#Implementar una clase ObjectStorageWithPolicies que:
#• Gestione objetos con políticas de acceso basadas en roles.
#• Permita la definición y aplicación de políticas de acceso.
#Incluir métodos para:
#• put_object(bucket, key, data, role) para almacenar datos y asignar roles.
#• get_object(bucket, key, role) para recuperar datos si el rol tiene acceso.
#• define_policy(role, action, resource) para definir políticas de acceso.

class ObjectStorageWithPolicies:
    def __init__(self):
        """
        Constructor de la clase ObjectStorageWithPolicies.
        Inicializa el almacenamiento de objetos y las políticas de acceso.
        """
        self.storage = {}  # Diccionario para almacenar los objetos
        self.policies = {}  # Diccionario para almacenar las políticas de acceso

    def put_object(self, cubeta, clave, datos, rol):
        """
        Almacena un objeto en la cubeta especificada y asigna un rol.

        Args:
        - cubeta (str): Nombre de la cubeta donde se almacenará el objeto.
        - clave (str): Clave única del objeto dentro de la cubeta.
        - datos (any): Datos del objeto a almacenar.
        - rol (str): Rol asignado al objeto para controlar el acceso.

        """
        if cubeta not in self.storage:
            self.storage[cubeta] = {}
        self.storage[cubeta][clave] = (datos, rol)
        print(f"Objeto almacenado en la cubeta '{cubeta}' con clave '{clave}' y asignado al rol '{rol}'.")

    def get_object(self, cubeta, clave, rol):
        """
        Recupera un objeto de la cubeta si el rol tiene permisos de acceso.

        Args:
        - cubeta (str): Nombre de la cubeta donde se encuentra el objeto.
        - clave (str): Clave única del objeto dentro de la cubeta.
        - rol (str): Rol que intenta acceder al objeto.

        Returns:
        - datos (any): Datos del objeto si el rol tiene permisos; None si no tiene permisos o el objeto no existe.

        """
        if cubeta in self.storage and clave in self.storage[cubeta]:
            datos, objeto_rol = self.storage[cubeta][clave]
            # Verificar si el rol tiene permisos según las políticas definidas
            if rol in self.policies and (objeto_rol, 'read', f'{cubeta}/{clave}') in self.policies[rol]:
                print(f"Objeto recuperado de la cubeta '{cubeta}' con clave '{clave}' para el rol '{rol}'.")
                return datos
            else:
                print(f"El rol '{rol}' no tiene permisos para acceder al objeto en la cubeta '{cubeta}'.")
                return None
        else:
            print(f"No se encontró el objeto con clave '{clave}' en la cubeta '{cubeta}'.")
            return None

    def define_policy(self, rol, accion, recurso):
        """
        Define una política de acceso para un rol específico.

        Args:
        - rol (str): Rol al que se aplica la política.
        - accion (str): Acción permitida ('read', 'write', etc.).
        - recurso (str): Recurso al que se aplica la política (cubeta y objeto).

        """
        if rol not in self.policies:
            self.policies[rol] = []
        self.policies[rol].append((rol, accion, recurso))
        print(f"Política definida para el rol '{rol}': {accion} {recurso}")

# Ejemplo de uso
obj_storage = ObjectStorageWithPolicies()

# Almacenar objetos con roles
obj_storage.put_object('mi_cubeta', 'archivo1.txt', 'Contenido del archivo 1', 'admin')
obj_storage.put_object('mi_cubeta', 'archivo2.txt', 'Contenido del archivo 2', 'user')

# Definir políticas de acceso
obj_storage.define_policy('admin', 'read', 'mi_cubeta/archivo1.txt')
obj_storage.define_policy('user', 'read', 'mi_cubeta/archivo2.txt')

# Recuperar objetos con diferentes roles
print(obj_storage.get_object('mi_cubeta', 'archivo1.txt', 'admin'))  # Output: 'Contenido del archivo 1'
print(obj_storage.get_object('mi_cubeta', 'archivo2.txt', 'user'))   # Output: 'Contenido del archivo 2'
print(obj_storage.get_object('mi_cubeta', 'archivo2.txt', 'admin'))  # Output: El rol 'admin' no tiene permisos...

# Intentar acceder a un objeto sin permisos
print(obj_storage.get_object('mi_cubeta', 'archivo1.txt', 'user'))   # Output: El rol 'user' no tiene permisos...





