"""Ejercicio 1: Simulación completa de Amazon EC2 y gestión de AMIs
Objetivo: Diseñar y simular un sistema completo para la creación, gestión y despliegue de instancias
EC2 utilizando AMIs. Este sistema debe permitir a los usuarios crear AMIs a partir de instancias
existentes, listar todas las AMIs disponibles y lanzar nuevas instancias a partir de una AMI
seleccionada.
Instrucciones:
Diseñar clases para AMI y EC2Instance:
• Crea clases que representen una AMI y una instancia EC2.
• Implementa métodos para gestionar el estado de la instancia (start, stop, terminate).
Gestión de AMIs:
• Implementa funciones para crear una AMI a partir de una instancia EC2.
• Lista todas las AMIs disponibles y permitir la selección de una AMI para lanzar nuevas
instancias.
Despliegue de Instancias:
• Implementa funciones para lanzar nuevas instancias EC2 utilizando una AMI seleccionada.
• Mantiene un registro de todas las instancias lanzadas, con sus estados y AMIs asociadas.
Simulación de Uso:
• Diseña una interfaz de usuario (CLI o interfaz gráfica) que permita a los usuarios interactuar
con el sistema.
• Permite la creación de AMIs, el despliegue de instancias, la gestión de estados de las
instancias y la visualización del estado actual del sistema"""

class AMI:
    def __init__(self, ami_id, instance_id):
        """
        Constructor de la clase AMI.

        Args:
        - ami_id (str): ID único de la AMI.
        - instance_id (str): ID de la instancia EC2 asociada a la AMI.
        """
        self.ami_id = ami_id
        self.instance_id = instance_id

    def __str__(self):
        """
        Método para representar la AMI como una cadena de texto.

        Returns:
        - str: Representación de la AMI en formato legible.
        """
        return f"AMI ID: {self.ami_id}, Instance ID: {self.instance_id}"


class EC2Instance:
    def __init__(self, instance_id, ami_id):
        """
        Constructor de la clase EC2Instance.

        Args:
        - instance_id (str): ID único de la instancia EC2.
        - ami_id (str): ID de la AMI utilizada para lanzar la instancia.
        """
        self.instance_id = instance_id
        self.ami_id = ami_id
        self.state = 'stopped'  # Estado inicial de la instancia

    def start(self):
        """
        Método para iniciar la instancia EC2.

        Cambia el estado de la instancia a 'running' si está actualmente 'stopped'.
        """
        if self.state == 'stopped':
            print(f"Starting instance {self.instance_id}...")
            self.state = 'running'
        else:
            print(f"Instance {self.instance_id} is already running.")

    def stop(self):
        """
        Método para detener la instancia EC2.

        Cambia el estado de la instancia a 'stopped' si está actualmente 'running'.
        """
        if self.state == 'running':
            print(f"Stopping instance {self.instance_id}...")
            self.state = 'stopped'
        else:
            print(f"Instance {self.instance_id} is already stopped.")

    def terminate(self):
        """
        Método para terminar la instancia EC2.

        Cambia el estado de la instancia a 'terminated'.
        """
        print(f"Terminating instance {self.instance_id}...")
        self.state = 'terminated'

    def __str__(self):
        """
        Método para representar la instancia EC2 como una cadena de texto.

        Returns:
        - str: Representación de la instancia EC2 en formato legible.
        """
        return f"Instance ID: {self.instance_id}, AMI ID: {self.ami_id}, State: {self.state}"

class EC2Management:
    def __init__(self):
        """
        Constructor de la clase EC2Management.

        Inicializa listas vacías para almacenar instancias EC2 y AMIs.
        """
        self.instances = []
        self.amis = []

    def create_ami(self, instance_id):
        """
        Método para crear una nueva AMI a partir de una instancia EC2 existente.

        Args:
        - instance_id (str): ID de la instancia EC2 desde la cual se creará la AMI.

        Returns:
        - AMI: Objeto AMI creado y almacenado.
        """
        ami_id = f"ami-{len(self.amis) + 1}"
        ami = AMI(ami_id, instance_id)
        self.amis.append(ami)
        print(f"Created AMI: {ami}")
        return ami

    def list_amis(self):
        """
        Método para listar todas las AMIs disponibles.
        """
        print("Available AMIs:")
        for ami in self.amis:
            print(ami)

    def launch_instance(self, ami_id):
        """
        Método para lanzar una nueva instancia EC2 utilizando una AMI existente.

        Args:
        - ami_id (str): ID de la AMI utilizada para lanzar la nueva instancia.

        Returns:
        - EC2Instance: Objeto EC2Instance de la instancia lanzada y almacenada.
        """
        instance_id = f"i-{len(self.instances) + 1}"
        instance = EC2Instance(instance_id, ami_id)
        self.instances.append(instance)
        print(f"Launched new instance: {instance}")
        return instance

'''
# Ejemplo de uso básico
ec2_manager = EC2Management()

# Crear una instancia EC2
instance1 = ec2_manager.launch_instance('ami-1')

# Crear una AMI a partir de la instancia EC2
ami1 = ec2_manager.create_ami(instance1.instance_id)

# Listar todas las AMIs disponibles
ec2_manager.list_amis()

# Lanzar una nueva instancia utilizando una AMI seleccionada
instance2 = ec2_manager.launch_instance(ami1.ami_id)

# Mostrar estado de las instancias
print(instance1)
print(instance2)


def main():
    ec2_manager = EC2Management()

    while True:
        print("\nSelect an operation:")
        print("1. Launch new instance")
        print("2. Create AMI from instance")
        print("3. List AMIs")
        print("4. Start instance")
        print("5. Stop instance")
        print("6. Terminate instance")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            instance_id = input("Enter instance ID to launch from: ")
            ec2_manager.launch_instance(instance_id)
        elif choice == '2':
            instance_id = input("Enter instance ID to create AMI from: ")
            ec2_manager.create_ami(instance_id)
        elif choice == '3':
            ec2_manager.list_amis()
        elif choice == '4':
            instance_id = input("Enter instance ID to start: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.start()
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '5':
            instance_id = input("Enter instance ID to stop: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.stop()
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '6':
            instance_id = input("Enter instance ID to terminate: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.terminate()
                ec2_manager.instances.remove(instance)
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '7':
            break
        else:
            print("Invalid choice. Please enter a valid option.")


if __name__ == "__main__":
    main()



'''





"""Ejercicio 2: Implementación y gestión de almacenamiento EBS y volúmenes de instancia
Objetivo: Crear un sistema para gestionar volúmenes de almacenamiento EBS y volúmenes de
instancia, simulando la creación, adjunción y gestión de estos volúmenes en instancias EC2.
Instrucciones:
Diseñar clases para EBSVolume y InstanceStoreVolume:
• Crea clases que representen un volumen EBS y un volumen de almacenamiento de instancia.
• Implementa métodos para adjuntar y desadjuntar volúmenes a instancias EC2.
Gestión de volúmenes:
• Implementa funciones para crear y eliminar volúmenes EBS.
• Simula el almacenamiento de datos en volúmenes y gestionar la integridad de los datos
durante las operaciones de adjunción y desadjunción.
Integración con instancias EC2:
• Crea funciones que permitan adjuntar volúmenes a instancias EC2 y gestionar su estado.
• Mantiene un registro de todos los volúmenes creados, sus estados y las instancias a las que están adjuntos.
Simulación de escenarios:
• Diseña una interfaz de usuario que permita a los usuarios crear, gestionar y monitorizar
volúmenes EBS y volúmenes de instancia.
• Implementa una funcionalidad para simular fallos en volúmenes y evaluar la recuperación de datos"""

class EBSVolume:
    def __init__(self, volume_id, size_gb):
        """
        Constructor de la clase EBSVolume.

        Args:
        - volume_id (str): ID único del volumen EBS.
        - size_gb (int): Tamaño del volumen en GB.
        """
        self.volume_id = volume_id
        self.size_gb = size_gb
        self.state = 'available'  # Estado inicial del volumen

    def attach_to_instance(self, instance_id):
        """
        Método para adjuntar el volumen EBS a una instancia EC2.

        Args:
        - instance_id (str): ID de la instancia EC2 a la que se adjunta el volumen.
        """
        if self.state == 'available':
            print(f"Attaching EBS volume {self.volume_id} to instance {instance_id}...")
            self.state = 'attached'
            self.instance_id = instance_id
        else:
            print(f"Volume {self.volume_id} is already attached to an instance.")

    def detach_from_instance(self):
        """
        Método para desadjuntar el volumen EBS de la instancia EC2 a la que está adjunto.
        """
        if self.state == 'attached':
            print(f"Detaching EBS volume {self.volume_id} from instance {self.instance_id}...")
            self.state = 'available'
            del self.instance_id
        else:
            print(f"Volume {self.volume_id} is not attached to any instance.")

    def store_data(self, data):
        """
        Método para simular el almacenamiento de datos en el volumen EBS.

        Args:
        - data (str): Datos a almacenar en el volumen.
        """
        print(f"Storing data '{data}' in EBS volume {self.volume_id}.")

    def __str__(self):
        """
        Método para representar el volumen EBS como una cadena de texto.

        Returns:
        - str: Representación del volumen EBS en formato legible.
        """
        return f"EBS Volume ID: {self.volume_id}, Size: {self.size_gb}GB, State: {self.state}"

class InstanceStoreVolume:
    def __init__(self, volume_id, size_gb):
        """
        Constructor de la clase InstanceStoreVolume.

        Args:
        - volume_id (str): ID único del volumen de almacenamiento de instancia.
        - size_gb (int): Tamaño del volumen en GB.
        """
        self.volume_id = volume_id
        self.size_gb = size_gb
        self.state = 'available'  # Estado inicial del volumen

    def attach_to_instance(self, instance_id):
        """
        Método para adjuntar el volumen de almacenamiento de instancia a una instancia EC2.

        Args:
        - instance_id (str): ID de la instancia EC2 a la que se adjunta el volumen.
        """
        if self.state == 'available':
            print(f"Attaching instance store volume {self.volume_id} to instance {instance_id}...")
            self.state = 'attached'
            self.instance_id = instance_id
        else:
            print(f"Volume {self.volume_id} is already attached to an instance.")

    def detach_from_instance(self):
        """
        Método para desadjuntar el volumen de almacenamiento de instancia de la instancia EC2.
        """
        if self.state == 'attached':
            print(f"Detaching instance store volume {self.volume_id} from instance {self.instance_id}...")
            self.state = 'available'
            del self.instance_id
        else:
            print(f"Volume {self.volume_id} is not attached to any instance.")

    def store_data(self, data):
        """
        Método para simular el almacenamiento de datos en el volumen de almacenamiento de instancia.

        Args:
        - data (str): Datos a almacenar en el volumen.
        """
        print(f"Storing data '{data}' in instance store volume {self.volume_id}.")

    def __str__(self):
        """
        Método para representar el volumen de almacenamiento de instancia como una cadena de texto.

        Returns:
        - str: Representación del volumen de almacenamiento de instancia en formato legible.
        """
        return f"Instance Store Volume ID: {self.volume_id}, Size: {self.size_gb}GB, State: {self.state}"


class EC2Instance:
    def __init__(self, instance_id, ami_id):
        """
        Constructor de la clase EC2Instance.

        Args:
        - instance_id (str): ID único de la instancia EC2.
        - ami_id (str): ID de la AMI utilizada para lanzar la instancia.
        """
        self.instance_id = instance_id
        self.ami_id = ami_id
        self.state = 'stopped'  # Estado inicial de la instancia
        self.volumes = []

    def start(self):
        """
        Método para iniciar la instancia EC2.

        Cambia el estado de la instancia a 'running' si está actualmente 'stopped'.
        """
        if self.state == 'stopped':
            print(f"Starting instance {self.instance_id}...")
            self.state = 'running'
        else:
            print(f"Instance {self.instance_id} is already running.")

    def stop(self):
        """
        Método para detener la instancia EC2.

        Cambia el estado de la instancia a 'stopped' si está actualmente 'running'.
        """
        if self.state == 'running':
            print(f"Stopping instance {self.instance_id}...")
            self.state = 'stopped'
        else:
            print(f"Instance {self.instance_id} is already stopped.")

    def terminate(self):
        """
        Método para terminar la instancia EC2.

        Cambia el estado de la instancia a 'terminated' y desadjunta todos los volúmenes.
        """
        print(f"Terminating instance {self.instance_id}...")
        self.state = 'terminated'
        for volume in self.volumes:
            volume.detach_from_instance()
        self.volumes = []

    def attach_volume(self, volume):
        """
        Método para adjuntar un volumen a la instancia EC2.

        Args:
        - volume (EBSVolume or InstanceStoreVolume): Volumen a adjuntar.
        """
        if self.state == 'running':
            volume.attach_to_instance(self.instance_id)
            self.volumes.append(volume)
        else:
            print(f"Cannot attach volume {volume.volume_id}. Instance {self.instance_id} is not running.")

    def detach_volume(self, volume_id):
        """
        Método para desadjuntar un volumen de la instancia EC2.

        Args:
        - volume_id (str): ID del volumen a desadjuntar.
        """
        for volume in self.volumes:
            if volume.volume_id == volume_id:
                volume.detach_from_instance()
                self.volumes.remove(volume)
                break
        else:
            print(f"Volume {volume_id} is not attached to instance {self.instance_id}.")

    def __str__(self):
        """
        Método para representar la instancia EC2 como una cadena de texto.

        Returns:
        - str: Representación de la instancia EC2 en formato legible.
        """
        return f"Instance ID: {self.instance_id}, AMI ID: {self.ami_id}, State: {self.state}, Volumes: {len(self.volumes)}"

"""
def main():
    ec2_manager = EC2Management()

    while True:
        print("\nSelect an operation:")
        print("1. Launch new instance")
        print("2. Create AMI from instance")
        print("3. List AMIs")
        print("4. Start instance")
        print("5. Stop instance")
        print("6. Terminate instance")
        print("7. Attach volume to instance")
        print("8. Detach volume from instance")
        print("9. List volumes attached to instance")
        print("10. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            instance_id = input("Enter instance ID to launch from: ")
            ec2_manager.launch_instance(instance_id)
        elif choice == '2':
            instance_id = input("Enter instance ID to create AMI from: ")
            ec2_manager.create_ami(instance_id)
        elif choice == '3':
            ec2_manager.list_amis()
        elif choice == '4':
            instance_id = input("Enter instance ID to start: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.start()
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '5':
            instance_id = input("Enter instance ID to stop: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.stop()
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '6':
            instance_id = input("Enter instance ID to terminate: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.terminate()
                ec2_manager.instances.remove(instance)
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '7':
            instance_id = input("Enter instance ID to attach volume to: ")
            volume_id = input("Enter volume ID to attach: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                volume = next((vol for vol in ec2_manager.volumes if vol.volume_id == volume_id), None)
                if volume:
                    instance.attach_volume(volume)
                else:
                    print(f"Volume {volume_id} not found.")
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '8':
            instance_id = input("Enter instance ID to detach volume from: ")
            volume_id = input("Enter volume ID to detach: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                instance.detach_volume(volume_id)
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '9':
            instance_id = input("Enter instance ID to list volumes: ")
            instance = next((inst for inst in ec2_manager.instances if inst.instance_id == instance_id), None)
            if instance:
                print(f"Volumes attached to instance {instance_id}:")
                for volume in instance.volumes:
                    print(volume)
            else:
                print(f"Instance {instance_id} not found.")
        elif choice == '10':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()"""









"""Ejercicio 3: Simulación de opciones de precios de EC2 con análisis de costos
Objetivo: Diseña un simulador que calcule los costos de diferentes opciones de precios de instancias
EC2 (On-Demand, Reserved, Spot) y permita a los usuarios comparar los costos y beneficios de cada
opción para diferentes escenarios de uso.
Instrucciones:
Diseña clases para EC2Instance y PricingOption:
• Crea clases que representen una instancia EC2 y una opción de precios (On-Demand, Reserved, Spot).
• Implementa métodos para calcular costos basados en horas de uso y tipo de instancia.
Simulación de costos:
• Implementa funciones para simular el costo de ejecutar instancias EC2 utilizando diferentes opciones de precios.
• Incluye variaciones en el uso de CPU, almacenamiento y tiempo de ejecución para obtener un análisis detallado de los costos.
Comparación de opciones de precios:
Crea funciones que permitan a los usuarios comparar los costos de diferentes opciones de precios para un periodo determinado.
• Implementa gráficos y tablas para visualizar los resultados de la comparación de costos.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios ingresar datos de uso y seleccionar
diferentes opciones de precios para ver los costos estimados.
• Implementa casos de estudio que simulen escenarios de uso real y muestren cómo se
afectan los costos con diferentes opciones de precios
"""

class EC2Instance:
    def __init__(self, instance_type, usage_hours_per_day, cpu_utilization=0.0, storage_gb=0):
        """
        Constructor de la clase EC2Instance.

        Args:
        - instance_type (str): Tipo de instancia (e.g., 't2.micro', 'm5.large').
        - usage_hours_per_day (float): Horas de uso diario de la instancia.
        - cpu_utilization (float, optional): Utilización promedio de CPU (%). Default es 0.0.
        - storage_gb (int, optional): Almacenamiento adicional utilizado en GB. Default es 0.
        """
        self.instance_type = instance_type
        self.usage_hours_per_day = usage_hours_per_day
        self.cpu_utilization = cpu_utilization
        self.storage_gb = storage_gb

    def calculate_daily_cost(self, pricing_option):
        """
        Calcula el costo diario de la instancia EC2 basado en la opción de precios.

        Args:
        - pricing_option (PricingOption): Opción de precios (OnDemand, Reserved, Spot).

        Returns:
        - float: Costo diario estimado en USD.
        """
        instance_cost_per_hour = pricing_option.get_cost_per_hour(self.instance_type)
        total_hours_per_day = self.usage_hours_per_day
        if pricing_option.name == 'Spot':
            total_hours_per_day *= pricing_option.spot_price_multiplier

        cost_per_day = instance_cost_per_hour * total_hours_per_day
        return cost_per_day

    def __str__(self):
        """
        Método para representar la instancia EC2 como una cadena de texto.

        Returns:
        - str: Representación de la instancia EC2 en formato legible.
        """
        return f"Instance Type: {self.instance_type}, Usage Hours per Day: {self.usage_hours_per_day}, CPU Utilization: {self.cpu_utilization}%, Storage: {self.storage_gb}GB"

class PricingOption:
    def __init__(self, name, cost_per_hour, spot_price_multiplier=1.0):
        """
        Constructor de la clase PricingOption.

        Args:
        - name (str): Nombre de la opción de precios (e.g., 'OnDemand', 'Reserved', 'Spot').
        - cost_per_hour (float): Costo por hora de la instancia EC2 en USD.
        - spot_price_multiplier (float, optional): Multiplicador de precio de Spot. Default es 1.0.
        """
        self.name = name
        self.cost_per_hour = cost_per_hour
        self.spot_price_multiplier = spot_price_multiplier

    def get_cost_per_hour(self, instance_type):
        """
        Obtiene el costo por hora para un tipo de instancia específico.

        Args:
        - instance_type (str): Tipo de instancia EC2.

        Returns:
        - float: Costo por hora de la instancia EC2 en USD.
        """
        # Aquí se podrían agregar lógicas adicionales según el tipo de instancia o región, si es necesario
        return self.cost_per_hour

    def __str__(self):
        """
        Método para representar la opción de precios como una cadena de texto.

        Returns:
        - str: Representación de la opción de precios en formato legible.
        """
        return f"Pricing Option: {self.name}, Cost per Hour: ${self.cost_per_hour}"

def simulate_costs(instance, pricing_options):
    """
    Simula y compara los costos de ejecutar una instancia EC2 con diferentes opciones de precios.

    Args:
    - instance (EC2Instance): Instancia EC2 a simular.
    - pricing_options (list of PricingOption): Lista de opciones de precios a comparar.

    Returns:
    - dict: Diccionario con los costos diarios estimados para cada opción de precios.
    """
    costs = {}
    for option in pricing_options:
        daily_cost = instance.calculate_daily_cost(option)
        costs[option.name] = daily_cost
        print(f"Estimated daily cost using {option.name}: ${daily_cost:.2f}")
    return costs

"""# Ejemplo de uso
if __name__ == "__main__":
    instance = EC2Instance(instance_type='t2.micro', usage_hours_per_day=12, cpu_utilization=50.0)
    on_demand = PricingOption(name='OnDemand', cost_per_hour=0.0116)
    reserved = PricingOption(name='Reserved', cost_per_hour=0.008)
    spot = PricingOption(name='Spot', cost_per_hour=0.005, spot_price_multiplier=0.7)

    pricing_options = [on_demand, reserved, spot]

    costs = simulate_costs(instance, pricing_options)"""




"""Ejercicio 4: Implementación de almacenamiento compartido con Amazon EFS
Objetivo: Crear un sistema de archivos compartido similar a Amazon EFS y simular su montaje en
varias instancias EC2, asegurando la consistencia y disponibilidad de los datos.
Instrucciones:
Diseña clases para EFS y EC2Instance:
• Crea una clase que represente un sistema de archivos EFS.
• Implementa métodos para montar y desmontar el sistema de archivos en instancias EC2.
Gestión de datos en EFS:
• Implementa funciones para crear, leer, escribir y eliminar archivos en el sistema de archivos EFS.
• Asegura la consistencia y disponibilidad de los datos en todas las instancias montadas.
Integración con instancias EC2:
• Crea funciones que permitan montar y desmontar el sistema de archivos EFS en varias instancias EC2.
• Implementa una funcionalidad para verificar la consistencia de los datos entre todas las instancias montadas.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios gestionar el sistema de archivos EFS y monitorizar su estado.
• Implementa escenarios que simulen el uso de EFS en aplicaciones reales y evalúen su rendimiento y disponibilidad."""


class EFS:
    def __init__(self, name, capacity_gb):
        """
        Constructor de la clase EFS.

        Args:
        - name (str): Nombre del sistema de archivos EFS.
        - capacity_gb (int): Capacidad del sistema de archivos en GB.
        """
        self.name = name
        self.capacity_gb = capacity_gb
        self.files = {}  # Diccionario para almacenar archivos

    def create_file(self, filename, content):
        """
        Crea un archivo en el sistema de archivos EFS.

        Args:
        - filename (str): Nombre del archivo.
        - content (str): Contenido del archivo.

        Returns:
        - bool: True si se crea el archivo correctamente, False si ya existe.
        """
        if filename in self.files:
            print(f"Error: El archivo {filename} ya existe en el sistema de archivos.")
            return False
        else:
            self.files[filename] = content
            print(f"Archivo {filename} creado en {self.name}.")
            return True

    def read_file(self, filename):
        """
        Lee un archivo del sistema de archivos EFS.

        Args:
        - filename (str): Nombre del archivo a leer.

        Returns:
        - str: Contenido del archivo si existe, None si no se encuentra.
        """
        return self.files.get(filename, None)

    def write_file(self, filename, content):
        """
        Escribe o sobrescribe el contenido de un archivo en el sistema de archivos EFS.

        Args:
        - filename (str): Nombre del archivo.
        - content (str): Nuevo contenido del archivo.

        Returns:
        - bool: True si se escribe correctamente, False si el archivo no existe.
        """
        if filename in self.files:
            self.files[filename] = content
            print(f"Archivo {filename} actualizado en {self.name}.")
            return True
        else:
            print(f"Error: El archivo {filename} no existe en el sistema de archivos.")
            return False

    def delete_file(self, filename):
        """
        Elimina un archivo del sistema de archivos EFS.

        Args:
        - filename (str): Nombre del archivo a eliminar.

        Returns:
        - bool: True si se elimina correctamente, False si el archivo no existe.
        """
        if filename in self.files:
            del self.files[filename]
            print(f"Archivo {filename} eliminado de {self.name}.")
            return True
        else:
            print(f"Error: El archivo {filename} no existe en el sistema de archivos.")
            return False

    def __str__(self):
        """
        Método para representar el sistema de archivos EFS como una cadena de texto.

        Returns:
        - str: Representación del sistema de archivos EFS en formato legible.
        """
        return f"EFS Name: {self.name}, Capacity: {self.capacity_gb}GB, Files: {list(self.files.keys())}"

class EC2Instance:
    def __init__(self, instance_id, instance_type):
        """
        Constructor de la clase EC2Instance.

        Args:
        - instance_id (str): ID único de la instancia EC2.
        - instance_type (str): Tipo de instancia (e.g., 't2.micro', 'm5.large').
        """
        self.instance_id = instance_id
        self.instance_type = instance_type
        self.mounted_filesystems = []

    def mount_filesystem(self, efs):
        """
        Monta un sistema de archivos EFS en la instancia EC2.

        Args:
        - efs (EFS): Objeto del sistema de archivos EFS a montar.

        Returns:
        - bool: True si se monta correctamente, False si ya está montado.
        """
        if efs in self.mounted_filesystems:
            print(f"El sistema de archivos {efs.name} ya está montado en la instancia {self.instance_id}.")
            return False
        else:
            self.mounted_filesystems.append(efs)
            print(f"Sistema de archivos {efs.name} montado en la instancia {self.instance_id}.")
            return True

    def unmount_filesystem(self, efs):
        """
        Desmonta un sistema de archivos EFS de la instancia EC2.

        Args:
        - efs (EFS): Objeto del sistema de archivos EFS a desmontar.

        Returns:
        - bool: True si se desmonta correctamente, False si no está montado.
        """
        if efs in self.mounted_filesystems:
            self.mounted_filesystems.remove(efs)
            print(f"Sistema de archivos {efs.name} desmontado de la instancia {self.instance_id}.")
            return True
        else:
            print(f"El sistema de archivos {efs.name} no está montado en la instancia {self.instance_id}.")
            return False

    def simulate_operations(self, efs):
        if efs in self.mounted_filesystems:
            print(f"Instancia EC2 {self.instance_id} realizando operaciones en EFS '{efs.name}'")
            efs.create_file("archivo1.txt", "contenido 1")
            efs.create_file("archivo2.txt", "contenido 1")
            efs.write_file("archivo1.txt", "Contenido desde EC2 A\n")
            efs.write_file("archivo2.txt", "Contenido desde EC2 B\n")
        else:
            print(f"Error: El sistema de archivos '{efs.name}' no está montado en EC2 {self.instance_id}")

# Configuración inicial
efs_system = EFS("efs-sistema", 13)
instance_ec2_a = EC2Instance("i-12345", 'toipo')
instance_ec2_b = EC2Instance("i-67890", 'tipo')

# Simulación del escenario
instance_ec2_a.mount_filesystem(efs_system)
instance_ec2_b.mount_filesystem(efs_system)

instance_ec2_a.simulate_operations(efs_system)
instance_ec2_b.simulate_operations(efs_system)

# Desmontaje del EFS de la instancia EC2 A
instance_ec2_a.mounted_filesystems.remove(efs_system)
print(f"Sistema de archivos '{efs_system.name}' desmontado de EC2 {instance_ec2_a.instance_id}")

# Evaluación de rendimiento y consistencia
print(f"Contenido de archivo1.txt: {efs_system.read_file('archivo1.txt')}")
print(f"Contenido de archivo2.txt: {efs_system.read_file('archivo2.txt')}")









"""Ejercicio 5: Simulación de orquestación de contenedores con Amazon ECS y Kubernetes
Objetivo: Diseñar y simular un sistema de orquestación de contenedores utilizando Amazon ECS y
Kubernetes, permitiendo a los usuarios desplegar, escalar y gestionar aplicaciones en contenedores.
Instrucciones:
Diseñar clases para ECS y Kubernetes:
• Crea clases que representen un clúster de Amazon ECS y un clúster de Kubernetes.
• Implementa métodos para definir tareas, servicios y políticas de escalado automático.
Gestión de contenedores:
• Implementa funciones para desplegar, escalar y eliminar contenedores en los clústeres de
ECS y Kubernetes.
• Simular la gestión de recursos y la distribución de carga en los clústeres.
Integración con instancias EC2:
• Crea funciones que permitan gestionar la infraestructura subyacente para los clústeres de
ECS y Kubernetes, incluyendo la creación y eliminación de instancias EC2.
• Implementa una funcionalidad para monitorizar el estado y el rendimiento de los clústeres.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios interactuar con los clústeres de
ECS y Kubernetes y gestionar aplicaciones en contenedores.
• Implementa casos de estudio que simulen el despliegue de aplicaciones reales y evalúen el
rendimiento y la escalabilidad de los clústeres."""

# Clase base para representar un clúster de contenedores
class ContainerCluster:
    def __init__(self, nombre):
        self.nombre = nombre
        self.contenedores = {}

    def desplegar_contenedor(self, nombre_contenedor, imagen):
        self.contenedores[nombre_contenedor] = imagen
        print(f"Contenedor '{nombre_contenedor}' desplegado en el clúster '{self.nombre}' con imagen '{imagen}'")

    def escalar_contenedor(self, nombre_contenedor, cantidad_replicas):
        if nombre_contenedor in self.contenedores:
            print(f"Escalando contenedor '{nombre_contenedor}' a {cantidad_replicas} réplicas en el clúster '{self.nombre}'")
        else:
            print(f"Contenedor '{nombre_contenedor}' no encontrado en el clúster '{self.nombre}'")

    def eliminar_contenedor(self, nombre_contenedor):
        if nombre_contenedor in self.contenedores:
            del self.contenedores[nombre_contenedor]
            print(f"Contenedor '{nombre_contenedor}' eliminado del clúster '{self.nombre}'")
        else:
            print(f"Contenedor '{nombre_contenedor}' no encontrado en el clúster '{self.nombre}'")

# Clase para representar un clúster de Amazon ECS
class ECSCluster(ContainerCluster):
    def __init__(self, nombre):
        super().__init__(nombre)

    def definir_politica_autoscalado(self, nombre_contenedor, min_instancias, max_instancias):
        print(f"Política de autoscalado definida para el contenedor '{nombre_contenedor}' en el clúster ECS '{self.nombre}'")

# Clase para representar un clúster de Kubernetes
class KubernetesCluster(ContainerCluster):
    def __init__(self, nombre):
        super().__init__(nombre)

    def actualizar_despliegue(self, nombre_despliegue, imagen):
        print(f"Actualizando despliegue '{nombre_despliegue}' en el clúster Kubernetes '{self.nombre}' con imagen '{imagen}'")

# Ejemplo de uso
def main():
    ecs_cluster = ECSCluster("mi-cluster-ecs")
    kubernetes_cluster = KubernetesCluster("mi-cluster-kubernetes")

    # Simulación de operaciones
    ecs_cluster.desplegar_contenedor("web-app", "nginx:latest")
    ecs_cluster.escalar_contenedor("web-app", 3)
    ecs_cluster.definir_politica_autoscalado("web-app", 2, 5)
    ecs_cluster.eliminar_contenedor("web-app")

    kubernetes_cluster.desplegar_contenedor("api-service", "mi-repo/api-service:latest")
    kubernetes_cluster.actualizar_despliegue("api-service", "mi-repo/api-service:v2")
    kubernetes_cluster.escalar_contenedor("api-service", 5)
    kubernetes_cluster.eliminar_contenedor("api-service")

if __name__ == "__main__":
    main()






"""Gestión de funciones Lambda:
• Implementa funciones para crear, actualizar y eliminar funciones Lambda.
• Simula la ejecución de funciones Lambda en respuesta a diferentes tipos de eventos (por
ejemplo, eventos de S3, eventos de DynamoDB).
Integración con eventos:
• Crea funciones que permitan asociar funciones Lambda con diferentes tipos de eventos y
gestionar sus desencadenadores.
• Implementa una funcionalidad para monitorizar y registrar la ejecución de funciones
Lambda.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios definir, desplegar y gestionar
funciones Lambda.
• Implementa escenarios que simulen el uso de funciones Lambda en aplicaciones reales y
evalúen su rendimiento y escalabilidad"""

import time

# Clase para representar una función Lambda
class LambdaFunction:
    def __init__(self, nombre):
        self.nombre = nombre

    def definir_funcion(self, codigo):
        print(f"Definiendo función Lambda '{self.nombre}'")
        self.codigo = codigo

    def ejecutar(self, evento):
        print(f"Ejecutando función Lambda '{self.nombre}' en respuesta al evento:")
        print(evento)
        # Simulación de ejecución
        time.sleep(2)  # Simular tiempo de ejecución
        return f"Resultado de la ejecución de '{self.nombre}'"

# Clase para representar un evento que desencadena una función Lambda
class Event:
    def __init__(self, tipo):
        self.tipo = tipo
        self.datos = {}

    def agregar_datos(self, datos):
        self.datos.update(datos)

    def __str__(self):
        return f"Evento '{self.tipo}' con datos: {self.datos}"

# Ejemplo de uso
def main():
    # Crear una función Lambda
    funcion_lambda = LambdaFunction("mi-funcion-lambda")
    codigo_funcion = """
    def handler(event, context):
        return f"Hello, {event['name']}!"
    """
    funcion_lambda.definir_funcion(codigo_funcion)

    # Crear un evento que desencadena la función Lambda
    evento_s3 = Event("s3_event")
    evento_s3.agregar_datos({"bucket": "mi-bucket", "name": "world"})

    # Ejecutar la función Lambda en respuesta al evento
    resultado = funcion_lambda.ejecutar(evento_s3)
    print(f"Resultado de la ejecución: {resultado}")

if __name__ == "__main__":
    main()










"""
Ejercicio 7: Simulación de procesamiento por lotes con AWS Batch
Objetivo: Crear un sistema de procesamiento por lotes similar a AWS Batch, que permita a los
usuarios definir y ejecutar trabajos en un entorno gestionado.
Instrucciones:
Diseñar clases para BatchJob y JobQueue:
• Crea una clase que represente un trabajo por lotes, con métodos para definir y ejecutar el trabajo.
• Crea una clase que represente una cola de trabajos, que gestione la ejecución de trabajos en orden.
Gestión de trabajos por lotes:
• Implementa funciones para crear, actualizar y eliminar trabajos por lotes.
• Simula la gestión de recursos y la distribución de carga para la ejecución de trabajos.
Integración con instancias EC2:
• Crea funciones que permitan gestionar la infraestructura subyacente para la ejecución de
trabajos por lotes, incluyendo la creación y eliminación de instancias EC2.
• Implementa una funcionalidad para monitorizar el estado y el rendimiento de los trabajos.
Simulación de escenarios reales
Diseña una interfaz de usuario que permita a los usuarios definir, desplegar y gestionar trabajos por lotes.
• Implementa casos de estudio que simulen el procesamiento por lotes en aplicaciones reales
y evalúen su rendimiento y escalabilidad."""

import time
import random

# Clase para representar un trabajo por lotes
class BatchJob:
    def __init__(self, job_id, job_name):
        self.job_id = job_id
        self.job_name = job_name
        self.status = "PENDING"  # Estados posibles: PENDING, RUNNING, COMPLETED, FAILED

    def definir_job(self):
        print(f"Definiendo trabajo por lotes '{self.job_name}'")
        # Simulación de definición de trabajo

    def ejecutar_job(self):
        print(f"Ejecutando trabajo por lotes '{self.job_name}'")
        self.status = "RUNNING"
        time.sleep(random.randint(1, 5))  # Simular tiempo de ejecución
        self.status = "COMPLETED"
        print(f"Trabajo '{self.job_name}' completado")

    def __str__(self):
        return f"Job ID: {self.job_id}, Name: {self.job_name}, Status: {self.status}"

# Clase para representar una cola de trabajos
class JobQueue:
    def __init__(self, queue_name):
        self.queue_name = queue_name
        self.jobs = []

    def agregar_job(self, job):
        self.jobs.append(job)

    def ejecutar_jobs(self):
        print(f"Ejecutando todos los trabajos en la cola '{self.queue_name}'")
        for job in self.jobs:
            job.ejecutar_job()

    def __str__(self):
        return f"Queue Name: {self.queue_name}, Jobs: {len(self.jobs)}"

# Funciones para simulación de escenarios reales
def simular_procesamiento_por_lotes():
    # Crear una cola de trabajos
    job_queue = JobQueue("mi-cola-de-trabajos")

    # Agregar trabajos a la cola
    job1 = BatchJob(1, "procesamiento1")
    job2 = BatchJob(2, "procesamiento2")
    job_queue.agregar_job(job1)
    job_queue.agregar_job(job2)

    # Ejecutar todos los trabajos en la cola
    job_queue.ejecutar_jobs()

# Interfaz de usuario básica (CLI)
def interfaz_usuario():
    while True:
        print("\n=== Sistema de Procesamiento por Lotes ===")
        print("1. Agregar trabajo por lotes")
        print("2. Ejecutar trabajos en la cola")
        print("3. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            nombre_trabajo = input("Ingrese el nombre del trabajo por lotes: ")
            job = BatchJob(len(job_queue.jobs) + 1, nombre_trabajo)
            job_queue.agregar_job(job)
            print(f"Trabajo '{nombre_trabajo}' agregado a la cola '{job_queue.queue_name}'")
        elif opcion == '2':
            if job_queue.jobs:
                job_queue.ejecutar_jobs()
            else:
                print("No hay trabajos en la cola.")
        elif opcion == '3':
            print("Saliendo del programa...")
            break
        else:
            print("Opción inválida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    # Iniciar simulación de procesamiento por lotes
    simular_procesamiento_por_lotes()

    # Iniciar interfaz de usuario
    interfaz_usuario()









"""Ejercicio 8: Simulación de amazon Lightsail para VPS
Objetivo: Crear una simulación de VPS utilizando Amazon Lightsail, que permita a los usuarios crear,
gestionar y monitorizar instancias de VPS.
Instrucciones:
Diseñar clases para LightsailInstance y LightsailSnapshot:
• Crea una clase que represente una instancia de Lightsail, con métodos para iniciar, detener y eliminar la instancia.
• Crea una clase que represente una instantánea de Lightsail, que permita la restauración de instancias a partir de instantáneas.
Gestión de instancias de Lightsail:
• Implementa funciones para crear, actualizar y eliminar instancias de Lightsail.
• Simula la gestión de recursos y la asignación de IPs estáticas.
Gestión de instantáneas:
• Crea funciones que permitan crear, listar y restaurar instantáneas de Lightsail.
• Implementa una funcionalidad para gestionar la recuperación de instancias a partir de instantáneas.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios gestionar instancias y instantáneas de Lightsail.
• Implementa escenarios que simulen el uso de Lightsail en aplicaciones reales y evalúen su
rendimiento y disponibilidad"""

import time
import random

# Clase para representar una instancia de Lightsail (VPS)
class LightsailInstance:
    def __init__(self, instance_id, instance_name, ip_address=None):
        self.instance_id = instance_id
        self.instance_name = instance_name
        self.ip_address = ip_address
        self.state = "stopped"  # Estados posibles: stopped, pending, running

    def start_instance(self):
        print(f"Iniciando instancia de Lightsail '{self.instance_name}'")
        self.state = "pending"
        time.sleep(random.randint(1, 3))  # Simular tiempo de inicio
        self.state = "running"
        self.ip_address = self.allocate_static_ip()
        print(f"Instancia '{self.instance_name}' iniciada")

    def stop_instance(self):
        print(f"Deteniendo instancia de Lightsail '{self.instance_name}'")
        self.state = "pending"
        time.sleep(random.randint(1, 3))  # Simular tiempo de detención
        self.state = "stopped"
        self.release_static_ip()
        print(f"Instancia '{self.instance_name}' detenida")

    def delete_instance(self):
        print(f"Eliminando instancia de Lightsail '{self.instance_name}'")
        self.state = "pending"
        time.sleep(random.randint(1, 3))  # Simular tiempo de eliminación
        self.state = "stopped"
        self.release_static_ip()
        print(f"Instancia '{self.instance_name}' eliminada")

    def allocate_static_ip(self):
        # Simular asignación de IP estática
        return f"192.168.1.{random.randint(1, 254)}"

    def release_static_ip(self):
        # Simular liberación de IP estática
        self.ip_address = None

    def __str__(self):
        return f"Instance ID: {self.instance_id}, Name: {self.instance_name}, State: {self.state}, IP: {self.ip_address}"

# Clase para representar una instantánea de Lightsail
class LightsailSnapshot:
    def __init__(self, snapshot_id, snapshot_name):
        self.snapshot_id = snapshot_id
        self.snapshot_name = snapshot_name

    def create_snapshot(self):
        print(f"Creando instantánea de Lightsail '{self.snapshot_name}'")
        time.sleep(random.randint(1, 3))  # Simular tiempo de creación de snapshot
        print(f"Instantánea '{self.snapshot_name}' creada")

    def restore_instance(self, instance):
        print(f"Restaurando instancia de Lightsail desde instantánea '{self.snapshot_name}'")
        time.sleep(random.randint(1, 3))  # Simular tiempo de restauración desde snapshot
        print(f"Instancia restaurada desde '{self.snapshot_name}'")

    def __str__(self):
        return f"Snapshot ID: {self.snapshot_id}, Name: {self.snapshot_name}"

# Funciones para simular escenarios reales
def simular_lightsail():
    # Crear una instancia de Lightsail
    instance = LightsailInstance(1, "mi-instancia-lightsail")

    # Iniciar la instancia
    instance.start_instance()
    print(instance)

    # Detener la instancia
    instance.stop_instance()
    print(instance)

    # Crear una instantánea de la instancia
    snapshot = LightsailSnapshot(1, "snapshot-instancia1")
    snapshot.create_snapshot()
    print(snapshot)

    # Restaurar la instancia desde la instantánea
    snapshot.restore_instance(instance)
    print(instance)

# Interfaz de usuario básica (CLI)
def interfaz_usuario():
    instance = None
    while True:
        print("\n=== Simulación de Lightsail para VPS ===")
        print("1. Crear instancia de Lightsail")
        print("2. Iniciar instancia")
        print("3. Detener instancia")
        print("4. Eliminar instancia")
        print("5. Crear snapshot de instancia")
        print("6. Restaurar instancia desde snapshot")
        print("7. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            nombre_instancia = input("Ingrese el nombre de la instancia: ")
            instance = LightsailInstance(1, nombre_instancia)
            print(f"Instancia '{nombre_instancia}' creada")
        elif opcion == '2':
            if instance:
                instance.start_instance()
                print(instance)
            else:
                print("Primero debe crear una instancia.")
        elif opcion == '3':
            if instance:
                instance.stop_instance()
                print(instance)
            else:
                print("Primero debe crear una instancia.")
        elif opcion == '4':
            if instance:
                instance.delete_instance()
                instance = None
            else:
                print("No hay instancia para eliminar.")
        elif opcion == '5':
            if instance:
                snapshot_name = input("Ingrese el nombre del snapshot: ")
                snapshot = LightsailSnapshot(1, snapshot_name)
                snapshot.create_snapshot()
                print(snapshot)
            else:
                print("Primero debe crear y iniciar una instancia.")
        elif opcion == '6':
            if instance:
                snapshot.restore_instance(instance)
                print(instance)
            else:
                print("Primero debe crear y iniciar una instancia.")
        elif opcion == '7':
            print("Saliendo del programa...")
            break
        else:
            print("Opción inválida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    # Iniciar simulación de Lightsail
    simular_lightsail()

    # Iniciar interfaz de usuario
    interfaz_usuario()







"""
Ejercicio 9: Implementación de Amazon FSx para Windows y Lustre
Objetivo: Diseñar y simular sistemas de archivos de alto rendimiento similares a Amazon FSx for
Windows y FSx for Lustre, que permitan a los usuarios gestionar almacenamiento de archivos y
optimizar el rendimiento para diferentes cargas de trabajo.
Instrucciones:
Diseñar clases para FSxForWindows y FSxForLustre:
• Crea clases que representen sistemas de archivos FSx for Windows y FSx for Lustre, con
métodos para gestionar archivos y carpetas.
• Implementa métodos para optimizar el rendimiento del sistema de archivos para diferentes
tipos de cargas de trabajo.
Gestión de archivos y carpetas:
• Implementa funciones para crear, leer, escribir y eliminar archivos y carpetas en los sistemas
de archivos.
• Simula la replicación y la recuperación de datos en caso de fallos.
Integración con Instancias EC2:
• Crea funciones que permitan montar y desmontar los sistemas de archivos en instancias
EC2.
• Implementa una funcionalidad para monitorizar el estado y el rendimiento de los sistemas
de archivos.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios gestionar sistemas de archivos FSx
for Windows y FSx for Lustre.
• Implementa casos de estudio que simulen el uso de sistemas de archivos de alto
rendimiento en aplicaciones reales y evalúen su rendimiento y disponibilidad
"""

import time
import random

# Clase base para representar un sistema de archivos FSx
class FSxFileSystem:
    def __init__(self, fs_id, fs_type):
        self.fs_id = fs_id
        self.fs_type = fs_type
        self.state = "unmounted"  # Estados posibles: unmounted, mounting, mounted

    def mount(self):
        print(f"Montando sistema de archivos {self.fs_type} (ID: {self.fs_id})")
        self.state = "mounting"
        time.sleep(random.randint(1, 3))  # Simular tiempo de montaje
        self.state = "mounted"
        print(f"Sistema de archivos {self.fs_type} montado")

    def unmount(self):
        print(f"Desmontando sistema de archivos {self.fs_type} (ID: {self.fs_id})")
        self.state = "unmounting"
        time.sleep(random.randint(1, 3))  # Simular tiempo de desmontaje
        self.state = "unmounted"
        print(f"Sistema de archivos {self.fs_type} desmontado")

    def optimize_performance(self, workload_type):
        print(f"Optimizando rendimiento para carga de trabajo '{workload_type}' en {self.fs_type} (ID: {self.fs_id})")
        # Simular optimización de rendimiento según el tipo de carga de trabajo
        time.sleep(random.randint(1, 3))
        print("Rendimiento optimizado")

    def __str__(self):
        return f"FileSystem ID: {self.fs_id}, Type: {self.fs_type}, State: {self.state}"

# Clase para FSx for Windows
class FSxForWindows(FSxFileSystem):
    def __init__(self, fs_id, size_gb):
        super().__init__(fs_id, "FSx for Windows")
        self.size_gb = size_gb

    def create_file(self, file_name, file_size):
        print(f"Creando archivo '{file_name}' de tamaño {file_size} GB en FSx for Windows (ID: {self.fs_id})")
        # Simular creación de archivo
        time.sleep(random.randint(1, 3))
        print(f"Archivo '{file_name}' creado")

    def delete_file(self, file_name):
        print(f"Eliminando archivo '{file_name}' de FSx for Windows (ID: {self.fs_id})")
        # Simular eliminación de archivo
        time.sleep(random.randint(1, 3))
        print(f"Archivo '{file_name}' eliminado")

# Clase para FSx for Lustre
class FSxForLustre(FSxFileSystem):
    def __init__(self, fs_id, storage_capacity_tb):
        super().__init__(fs_id, "FSx for Lustre")
        self.storage_capacity_tb = storage_capacity_tb

    def create_directory(self, directory_name):
        print(f"Creando directorio '{directory_name}' en FSx for Lustre (ID: {self.fs_id})")
        # Simular creación de directorio
        time.sleep(random.randint(1, 3))
        print(f"Directorio '{directory_name}' creado")

    def delete_directory(self, directory_name):
        print(f"Eliminando directorio '{directory_name}' de FSx for Lustre (ID: {self.fs_id})")
        # Simular eliminación de directorio
        time.sleep(random.randint(1, 3))
        print(f"Directorio '{directory_name}' eliminado")

# Funciones para simular escenarios reales
def simular_fsx():
    # Crear y montar FSx for Windows
    fs_windows = FSxForWindows("fs-win-001", size_gb=100)
    fs_windows.mount()
    print(fs_windows)

    # Crear archivo en FSx for Windows
    fs_windows.create_file("documento.txt", 2)
    print(fs_windows)

    # Desmontar FSx for Windows
    fs_windows.unmount()
    print(fs_windows)

    # Crear y montar FSx for Lustre
    fs_lustre = FSxForLustre("fs-lustre-001", storage_capacity_tb=500)
    fs_lustre.mount()
    print(fs_lustre)

    # Crear directorio en FSx for Lustre
    fs_lustre.create_directory("proyectos")
    print(fs_lustre)

    # Desmontar FSx for Lustre
    fs_lustre.unmount()
    print(fs_lustre)

# Interfaz de usuario básica (CLI)
def interfaz_usuario_fsx():
    while True:
        print("\n=== Simulación de Amazon FSx for Windows y Lustre ===")
        print("1. Montar FSx for Windows")
        print("2. Desmontar FSx for Windows")
        print("3. Crear archivo en FSx for Windows")
        print("4. Montar FSx for Lustre")
        print("5. Desmontar FSx for Lustre")
        print("6. Crear directorio en FSx for Lustre")
        print("7. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            fs_windows.mount()
            print(fs_windows)
        elif opcion == '2':
            fs_windows.unmount()
            print(fs_windows)
        elif opcion == '3':
            if fs_windows.state == "mounted":
                nombre_archivo = input("Ingrese el nombre del archivo: ")
                tamano_archivo = int(input("Ingrese el tamaño del archivo en GB: "))
                fs_windows.create_file(nombre_archivo, tamano_archivo)
                print(fs_windows)
            else:
                print("FSx for Windows no está montado.")
        elif opcion == '4':
            fs_lustre.mount()
            print(fs_lustre)
        elif opcion == '5':
            fs_lustre.unmount()
            print(fs_lustre)
        elif opcion == '6':
            if fs_lustre.state == "mounted":
                nombre_directorio = input("Ingrese el nombre del directorio: ")
                fs_lustre.create_directory(nombre_directorio)
                print(fs_lustre)
            else:
                print("FSx for Lustre no está montado.")
        elif opcion == '7':
            print("Saliendo del programa...")
            break
        else:
            print("Opción inválida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    # Iniciar simulación de FSx
    simular_fsx()

    # Iniciar interfaz de usuario
    interfaz_usuario_fsx()







"""Ejercicio 10: Simulación de Amazon Outposts
Objetivo: Crear una simulación de Amazon Outposts, que permita a los usuarios gestionar
infraestructura local de AWS y extender servicios de AWS a entornos on-premises.
Instrucciones:
Diseñar clases para Outpost y OutpostService:
• Crea una clase que represente un Outpost, con métodos para gestionar la infraestructura y
los servicios desplegados.
• Crea una clase que represente un servicio desplegado en el Outpost, con métodos para
gestionar el estado y el rendimiento del servicio.
Gestión de infraestructura local:
• Implementa funciones para desplegar, actualizar y eliminar infraestructura en el Outpost.
• Simula la gestión de recursos y la integración con servicios de AWS.
Gestión de servicios desplegados:
• Crea funciones que permitan gestionar servicios desplegados en el Outpost, incluyendo la
monitorización y la recuperación en caso de fallos.
• Implementa una funcionalidad para escalar servicios automáticamente en respuesta a
cambios en la carga de trabajo.
Simulación de escenarios reales:
• Diseña una interfaz de usuario que permita a los usuarios gestionar infraestructura y
servicios en un Outpost.
• Implementa casos de estudio que simulen el uso de Amazon Outposts en entornos on-
premises y evalúen su rendimiento y disponibilidad."""


import time
import random

# Clase base para representar un Outpost de Amazon
class Outpost:
    def __init__(self, outpost_id, location):
        self.outpost_id = outpost_id
        self.location = location
        self.services = []

    def deploy_infrastructure(self):
        print(f"Desplegando infraestructura en el Outpost {self.outpost_id} en {self.location}")
        # Simular despliegue de infraestructura
        time.sleep(random.randint(1, 3))
        print("Infraestructura desplegada")

    def update_infrastructure(self):
        print(f"Actualizando infraestructura en el Outpost {self.outpost_id}")
        # Simular actualización de infraestructura
        time.sleep(random.randint(1, 3))
        print("Infraestructura actualizada")

    def delete_infrastructure(self):
        print(f"Eliminando infraestructura del Outpost {self.outpost_id}")
        # Simular eliminación de infraestructura
        time.sleep(random.randint(1, 3))
        print("Infraestructura eliminada")

    def deploy_service(self, service_name, service_type):
        service = OutpostService(service_name, service_type)
        self.services.append(service)
        print(f"Servicio '{service_name}' desplegado en el Outpost {self.outpost_id}")
        # Simular despliegue de servicio
        time.sleep(random.randint(1, 3))
        print(f"Servicio '{service_name}' listo para operar")

    def scale_service(self, service_name, instances):
        service = next((s for s in self.services if s.service_name == service_name), None)
        if service:
            service.scale(instances)
            print(f"Escalando servicio '{service_name}' a {instances} instancias")
        else:
            print(f"El servicio '{service_name}' no está desplegado en el Outpost {self.outpost_id}")

    def __str__(self):
        return f"Outpost ID: {self.outpost_id}, Location: {self.location}, Services: {len(self.services)}"

# Clase para representar un servicio desplegado en el Outpost
class OutpostService:
    def __init__(self, service_name, service_type):
        self.service_name = service_name
        self.service_type = service_type
        self.status = "running"
        self.instances = 1

    def monitor(self):
        print(f"Monitoreando servicio '{self.service_name}' ({self.service_type})")
        # Simular monitoreo del servicio
        time.sleep(random.randint(1, 3))
        print(f"Estado actual: {self.status}, Instancias: {self.instances}")

    def scale(self, instances):
        print(f"Escalando servicio '{self.service_name}' a {instances} instancias")
        # Simular escalado del servicio
        self.instances = instances
        time.sleep(random.randint(1, 3))
        print(f"Servicio escalado a {self.instances} instancias")

# Función para simular escenarios reales
def simular_outpost():
    outpost = Outpost("outpost-001", "Localización A")

    # Desplegar infraestructura
    outpost.deploy_infrastructure()

    # Desplegar servicios
    outpost.deploy_service("EC2", "compute")
    outpost.deploy_service("RDS", "database")

    # Escalar servicios
    outpost.scale_service("EC2", 5)
    outpost.scale_service("RDS", 2)

    # Monitorear servicios
    for service in outpost.services:
        service.monitor()

    # Actualizar infraestructura
    outpost.update_infrastructure()

    # Eliminar infraestructura
    outpost.delete_infrastructure()

# Interfaz de usuario básica (CLI)
def interfaz_usuario_outpost():
    outpost = Outpost("outpost-001", "Localización A")

    while True:
        print("\n=== Simulación de Amazon Outposts ===")
        print("1. Desplegar infraestructura")
        print("2. Desplegar servicio")
        print("3. Escalar servicio")
        print("4. Monitorear servicios")
        print("5. Actualizar infraestructura")
        print("6. Eliminar infraestructura")
        print("7. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            outpost.deploy_infrastructure()
            print(outpost)
        elif opcion == '2':
            service_name = input("Ingrese el nombre del servicio: ")
            service_type = input("Ingrese el tipo del servicio: ")
            outpost.deploy_service(service_name, service_type)
            print(outpost)
        elif opcion == '3':
            service_name = input("Ingrese el nombre del servicio a escalar: ")
            instances = int(input("Ingrese el número de instancias a escalar: "))
            outpost.scale_service(service_name, instances)
        elif opcion == '4':
            for service in outpost.services:
                service.monitor()
        elif opcion == '5':
            outpost.update_infrastructure()
        elif opcion == '6':
            outpost.delete_infrastructure()
            print("Infraestructura eliminada")
            break
        elif opcion == '7':
            print("Saliendo del programa...")
            break
        else:
            print("Opción inválida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    # Iniciar simulación de Amazon Outposts
    simular_outpost()

    # Iniciar interfaz de usuario
    interfaz_usuario_outpost()










